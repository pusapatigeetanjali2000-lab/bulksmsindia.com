<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Microsoft Teams Direct Routing | Unified Voice | BulkSMSIndia";
?>

<style>
    :root {
        --teams-purple: #6264A7;
        --teams-blue: #0D2B8E;
        --teams-red: #DB1212;
        --teams-glass: rgba(255, 255, 255, 0.04);
    }

    .teams-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.93), rgba(5, 10, 21, 0.97)), 
                    url('https://images.unsplash.com/photo-1611605698335-8b1c429557f2?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
        color: #fff;
    }

    .hero-teams {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .teams-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 8px 20px;
        background: rgba(98, 100, 167, 0.15);
        border: 1px solid var(--teams-purple);
        border-radius: 50px;
        color: #fff;
        font-size: 0.8rem;
        font-weight: 700;
        margin-bottom: 25px;
        letter-spacing: 1px;
    }

    .teams-card {
        background: var(--teams-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        text-align: left;
    }

    .teams-card:hover {
        border-color: var(--teams-purple);
        background: rgba(98, 100, 167, 0.05);
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(98, 100, 167, 0.15);
    }

    .status-dot {
        width: 10px;
        height: 10px;
        background: #46D314; /* Teams Online Green */
        border-radius: 50%;
        display: inline-block;
        margin-right: 8px;
        box-shadow: 0 0 10px #46D314;
    }
</style>

<div class="teams-bg">
    <section class="hero-teams">
        <div class="teams-badge">
            <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 14.5v-9l6 4.5-6 4.5z"/></svg>
            POWERED BY DIRECT ROUTING
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1.1;">
            Teams is now your <br><span style="color: var(--teams-purple);">Global Phone System.</span>
        </h1>
        <p style="max-width: 850px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Connect your Microsoft Teams environment to the public telephone network. 
            Keep your existing numbers, save on calling plans, and manage everything in one app.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="teams-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">📞 Native Experience</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">No new software to learn. Use the familiar Teams dial pad on desktop, mobile, or desk phones.</p>
            </div>
            <div class="teams-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">💰 Cost Efficiency</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Eliminate expensive Microsoft Calling Plans. Use our wholesale SIP rates and pay only for what you use.</p>
            </div>
            <div class="teams-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🌍 Global Reach</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Get local phone numbers in 100+ countries and connect your global workforce instantly.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1573164773510-1863f6831f24?auto=format&fit=crop&w=800&q=80" alt="Remote Collaboration" style="width: 100%; border-radius: 40px; border: 1px solid var(--teams-purple); box-shadow: 0 0 50px rgba(98, 100, 167, 0.4);">
                <div style="position: absolute; bottom: 30px; left: 30px; background: rgba(0,0,0,0.6); backdrop-filter: blur(10px); padding: 15px 25px; border-radius: 15px; border: 1px solid var(--teams-purple);">
                    <span class="status-dot"></span> <span style="font-size: 0.85rem; font-weight: 700;">Voice Active</span>
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Industries <span>Scaling</span> with Teams</h2>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div style="padding: 20px; background: var(--teams-glass); border-radius: 15px; border-left: 4px solid var(--teams-purple);">
                        <h4 style="color: var(--teams-purple);">Professional Services</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Law firms and consultants can take client calls on their business line while working from home.</p>
                    </div>
                    <div style="padding: 20px; background: var(--teams-glass); border-radius: 15px; border-left: 4px solid var(--teams-purple);">
                        <h4 style="color: var(--teams-purple);">Education & Tech</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Centralize all internal and external communication for administrative staff and remote educators.</p>
                    </div>
                    <div style="padding: 20px; background: var(--teams-glass); border-radius: 15px; border-left: 4px solid var(--teams-purple);">
                        <h4 style="color: var(--teams-purple);">Healthcare</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Secure, HIPAA-compliant voice routing for telehealth and patient coordination.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">4 Steps to <span>Unity</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 30px;">
            <div class="teams-card" style="text-align: center;">
                <h1 style="color: var(--teams-purple); opacity: 0.3;">01</h1>
                <h4>Requirement</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Ensure you have MS 365 E1/E3/E5 licenses with Phone System add-on.</p>
            </div>
            <div class="teams-card" style="text-align: center;">
                <h1 style="color: var(--teams-purple); opacity: 0.3;">02</h1>
                <h4>Trunk Link</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">We connect our SBCs (Session Border Controllers) to your Teams tenant.</p>
            </div>
            <div class="teams-card" style="text-align: center;">
                <h1 style="color: var(--teams-purple); opacity: 0.3;">03</h1>
                <h4>Config</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">We set up the PowerShell commands and routing policies for your users.</p>
            </div>
            <div class="teams-card" style="text-align: center;">
                <h1 style="color: var(--teams-purple); opacity: 0.3;">04</h1>
                <h4>Go Live</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Your dial pad appears in Teams. Start making global calls instantly.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(98, 100, 167, 0.1), transparent); border: 1px solid var(--teams-purple);">
            <h2 style="margin-bottom: 20px;">Bridge the Gap. Connect Teams.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Get a free assessment for your business voice transition today.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary" style="background: var(--teams-purple); border: none;">Start Free Trial</a>
                <a href="contact.php" class="btn-nav-ghost">Consult an Expert</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>