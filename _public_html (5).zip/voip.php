<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Business VOIP Solutions | Global Cloud Telephony | BulkSMSIndia";
?>

<style>
    :root {
        --voip-blue: #0D2B8E;
        --voip-red: #DB1212;
        --voip-glow: rgba(13, 43, 142, 0.3);
    }

    .voip-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-voip {
        padding: 180px 4% 100px;
        text-align: center;
    }

    .status-pill {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 20px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid var(--voip-blue);
        border-radius: 50px;
        color: #fff;
        font-size: 0.85rem;
        margin-bottom: 30px;
    }

    .pulse {
        width: 8px;
        height: 8px;
        background: #00ff88;
        border-radius: 50%;
        box-shadow: 0 0 10px #00ff88;
        animation: pulse-green 2s infinite;
    }

    @keyframes pulse-green {
        0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0.7); }
        70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(0, 255, 136, 0); }
        100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(0, 255, 136, 0); }
    }

    .voip-card {
        background: rgba(255, 255, 255, 0.02);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s ease;
    }

    .voip-card:hover {
        background: var(--voip-glow);
        border-color: var(--voip-red);
        transform: translateY(-10px);
    }

    .industry-tag {
        display: inline-block;
        padding: 5px 12px;
        background: rgba(219, 18, 18, 0.1);
        color: var(--voip-red);
        border-radius: 6px;
        font-size: 0.75rem;
        font-weight: 700;
        margin-bottom: 10px;
    }
</style>

<div class="voip-bg">
    <section class="hero-voip">
        <div class="status-pill">
            <div class="pulse"></div> 160-Series TRAI Compliant Routes Active
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1;">
            Voice Without <br><span style="color: var(--voip-red);">Boundaries.</span>
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Replace legacy copper lines with high-definition Cloud VOIP. Connect your remote teams, 
            reduce international costs by 70%, and integrate voice directly into your CRM.
        </p>
        <div style="margin-top: 40px;">
            <a href="signup.php" class="btn-nav-primary">Switch to Cloud Voice</a>
        </div>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 30px;">
            <div class="voip-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">💰 Massive Cost Savings</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Eliminate expensive PBX hardware and slash international calling bills. Pay only for what you use with flexible cloud pricing.</p>
            </div>
            <div class="voip-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🌍 Work from Anywhere</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Your business number follows you. Make and receive calls on your laptop, smartphone, or IP desk phone seamlessly.</p>
            </div>
            <div class="voip-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">📈 Instant Scalability</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Add 10 or 100 new lines in minutes without waiting for a technician. Perfect for fast-growing startups.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Engineered for <br><span style="color: var(--red);">Modern Industry</span></h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div class="voip-card" style="padding: 25px;">
                        <span class="industry-tag">BPO & CALL CENTERS</span>
                        <p style="font-size: 0.85rem; color: var(--text-300);">High-volume outbound dialing with real-time analytics.</p>
                    </div>
                    <div class="voip-card" style="padding: 25px;">
                        <span class="industry-tag">E-COMMERCE</span>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Unified support across local and international toll-free numbers.</p>
                    </div>
                    <div class="voip-card" style="padding: 25px;">
                        <span class="industry-tag">HEALTHCARE</span>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Telehealth coordination and secure patient communication.</p>
                    </div>
                    <div class="voip-card" style="padding: 25px;">
                        <span class="industry-tag">RETAIL</span>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Connect multiple store locations to a single voice network.</p>
                    </div>
                </div>
            </div>
            <div style="position: relative;">
                <div style="position: relative;">
    <img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=800&q=80" 
         alt="Global Cloud Network" 
         style="width: 100%; border-radius: 40px; border: 1px solid var(--voip-blue); box-shadow: 0 0 50px rgba(13, 43, 142, 0.3); filter: brightness(0.8) contrast(1.2);">
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">3 Steps to <span>Modernize</span></h2>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 40px;">
            <div class="voip-card" style="flex: 1; min-width: 280px; text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 20px;">🌐</div>
                <h4>1. Network Audit</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">We check your internet stability to ensure crystal-clear HD voice quality.</p>
            </div>
            <div class="voip-card" style="flex: 1; min-width: 280px; text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 20px;">📲</div>
                <h4>2. Select Numbers</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Choose local, national, or international 160-series compliant numbers.</p>
            </div>
            <div class="voip-card" style="flex: 1; min-width: 280px; text-align: center;">
                <div style="font-size: 3rem; margin-bottom: 20px;">🚀</div>
                <h4>3. Go Live</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Login to your softphone or connect your IP phones and start calling.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(13, 43, 142, 0.2), transparent); border: 1px solid var(--voip-blue);">
            <h2 style="margin-bottom: 20px;">Cut Your Phone Bill Today.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Join 1000+ businesses using BulkSMSIndia for reliable, compliant VOIP services.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary">Get a Free Quote</a>
                <a href="contact.php" class="btn-nav-ghost">Consult an Expert</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>