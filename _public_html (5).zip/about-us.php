<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | BulkSMSIndia</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #050a12;
            --card-bg: #0d141f;
            --accent-red: #d11a1a;
            --text-main: #ffffff;
            --text-muted: #a0a6b1;
            --border: rgba(255, 255, 255, 0.1);
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            line-height: 1.6;
        }

        .container { max-width: 1200px; margin: 80px auto; padding: 0 20px; }

        /* Story Header */
        .about-header { text-align: left; margin-bottom: 60px; max-width: 800px; }
        .about-header h1 { font-size: 4rem; font-weight: 800; margin-bottom: 20px; letter-spacing: -2px; line-height: 1.1; }
        .about-header h1 span { color: var(--accent-red); }
        .about-header p { font-size: 1.25rem; color: var(--text-muted); line-height: 1.8; }

        /* Info Cards */
        .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-bottom: 50px; }
        .info-card { 
            background: var(--card-bg); 
            padding: 40px; 
            border-radius: 24px; 
            border: 1px solid var(--border); 
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .info-card h3 { color: var(--accent-red); margin-top: 0; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 2px; margin-bottom: 15px; }
        .info-card p { color: var(--text-muted); font-size: 1.1rem; margin: 5px 0; }
        
        .contact-number { 
            font-size: 2.2rem; 
            font-weight: 800; 
            color: white; 
            text-decoration: none; 
            margin: 15px 0;
            display: inline-block;
        }
        .contact-number:hover { color: var(--accent-red); }

        /* Maps Section */
        .map-section { margin-top: 40px; }
        .map-section h2 { margin-bottom: 20px; font-weight: 700; }
        .map-container { 
            width: 100%; 
            border-radius: 30px; 
            overflow: hidden; 
            border: 1px solid var(--border);
            height: 400px;
            filter: grayscale(1) invert(0.92) contrast(1.2); /* Aesthetic Dark Map */
        }

        @media (max-width: 992px) {
            .info-grid { grid-template-columns: 1fr; }
            .about-header h1 { font-size: 2.8rem; }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="about-header">
            <h1>Our <span>Presence</span> & Headquarters</h1>
            <p>BulkSMSIndia is strategically located in the technology hub of Hyderabad. We combine local expertise with global messaging infrastructure to provide seamless communication for 230+ countries.</p>
        </div>

        <div class="info-grid">
            <div class="info-card">
                <h3>Corporate Headquarters</h3>
                <p><strong>BulkSMSIndia (Prashanti Ram Towers)</strong></p>
                <p>Flat No.204, 2nd Floor, Ameerpet,</p>
                <p>Hyderabad, Telangana – 500073</p>
                <p style="margin-top: 15px; font-size: 0.9rem; opacity: 0.7;">Working Hours: Mon-Sat (9am - 7pm)</p>
            </div>
            
            <div class="info-card">
                <h3>Direct Support Line</h3>
                <p>Connect with our engineering and sales teams instantly.</p>
                <a href="tel:+919000937601" class="contact-number">+91 90009 37601</a>
                <p>Support Email: <a href="mailto:info@bulksmsindia.com" style="color: var(--accent-red); text-decoration: none;">info@bulksmsindia.com</a></p>
            </div>
        </div>

        <div class="map-section">
            <div class="map-container">
                <iframe 
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3806.5936302568636!2d78.4452184!3d17.4312847!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bcb90cf61347071%3A0x633d26618490a6e4!2sPrashanti%20Ram%20Towers!5e0!3m2!1sen!2sin!4v1713094000000!5m2!1sen!2sin" 
                    width="100%" 
                    height="100%" 
                    style="border:0;" 
                    allowfullscreen="" 
                    loading="lazy">
                </iframe>
            </div>
        </div>
    </div>

</body>
</html>
<?php include 'includes/footer.php'; ?>