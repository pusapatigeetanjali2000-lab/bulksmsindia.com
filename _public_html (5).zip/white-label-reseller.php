<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "White-Label Reseller Program | Your Brand, Our Power | BulkSMSIndia";
?>

<style>
    :root {
        --wl-navy: #0D2B8E;
        --wl-red: #DB1212;
        --wl-yellow: #FFD700;
        --wl-glass: rgba(255, 255, 255, 0.03);
    }

    .wl-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
        color: #fff;
    }

    .hero-wl {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .wl-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 25px;
        background: rgba(219, 18, 18, 0.1);
        border: 1px solid var(--wl-red);
        border-radius: 50px;
        color: #fff;
        font-size: 0.8rem;
        font-weight: 700;
        margin-bottom: 25px;
        letter-spacing: 1px;
    }

    .wl-card {
        background: var(--wl-glass);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        position: relative;
    }

    .wl-card:hover {
        transform: translateY(-12px);
        border-color: var(--wl-red);
        background: rgba(219, 18, 18, 0.05);
        box-shadow: 0 20px 50px rgba(219, 18, 18, 0.1);
    }

    .icon-box {
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, var(--wl-navy), var(--wl-red));
        border-radius: 15px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.8rem;
        margin-bottom: 25px;
    }

    .profit-tag {
        position: absolute;
        top: 20px;
        right: 20px;
        background: var(--wl-yellow);
        color: #000;
        padding: 4px 12px;
        border-radius: 50px;
        font-size: 0.7rem;
        font-weight: 800;
    }

    .step-number {
        font-size: 3rem;
        font-weight: 900;
        color: var(--wl-red);
        opacity: 0.3;
        margin-bottom: 10px;
    }
</style>

<div class="wl-bg">
    <section class="hero-wl">
        <div class="wl-badge">
            🚀 100% REBRANDABLE PLATFORM
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1.1;">
            Your Brand. <br><span style="color: var(--wl-yellow);">Our Infrastructure.</span>
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Launch your own Messaging & AI business in minutes. We provide the technology, 
            the routes, and the support—you provide the brand and keep the profit.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="wl-card">
                <span class="profit-tag">HIGH MARGIN</span>
                <div class="icon-box">🏷️</div>
                <h3 style="color: var(--wl-yellow); margin-bottom: 15px;">Full Custom Branding</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Upload your logo and point your domain. Your customers experience your brand, start to finish.</p>
            </div>
            <div class="wl-card">
                <span class="profit-tag">EASY SETUP</span>
                <div class="icon-box">💰</div>
                <h3 style="color: var(--wl-yellow); margin-bottom: 15px;">Custom Pricing</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Buy at wholesale and sell at your own rates. You have total control over your revenue.</p>
            </div>
            <div class="wl-card">
                <span class="profit-tag">RELIABLE</span>
                <div class="icon-box">⚡</div>
                <h3 style="color: var(--wl-yellow); margin-bottom: 15px;">Robust API & Panel</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Access our enterprise-grade dashboard, fully white-labeled for your end users.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&w=800&q=80" alt="Business Partnership" style="width: 100%; border-radius: 40px; border: 1px solid var(--wl-navy); box-shadow: 0 0 50px rgba(13, 43, 142, 0.3);">
                <div style="position: absolute; bottom: -20px; right: 20px; background: var(--wl-red); padding: 20px; border-radius: 20px; border: 5px solid #050a15;">
                    <h4 style="margin:0; font-size: 1.5rem;">0%</h4>
                    <p style="margin:0; font-size: 0.7rem; opacity: 0.8;">Dev Cost</p>
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Perfect for <br><span style="color: var(--wl-red);">Modern Agencies</span></h2>
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <div style="padding: 20px; background: var(--wl-glass); border-radius: 15px; border-left: 4px solid var(--wl-red);">
                        <h4 style="color: var(--wl-yellow);">Digital Marketing</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Bundle SMS and AI services into your packages for recurring revenue.</p>
                    </div>
                    <div style="padding: 20px; background: var(--wl-glass); border-radius: 15px; border-left: 4px solid var(--wl-red);">
                        <h4 style="color: var(--wl-yellow);">SaaS Startups</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Add communication features to your app without months of development.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <h2 style="margin-bottom: 70px;">Start Your <span>Empire</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 30px;">
            <div class="wl-card">
                <div class="step-number">01</div>
                <h4>Sign Up</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Join our program and access your admin hub.</p>
            </div>
            <div class="wl-card">
                <div class="step-number">02</div>
                <h4>Brand It</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Upload your logo and set your domain.</p>
            </div>
            <div class="wl-card">
                <div class="step-number">03</div>
                <h4>Set Rates</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Decide your pricing and profit margins.</p>
            </div>
            <div class="wl-card">
                <div class="step-number">04</div>
                <h4>Launch</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Start onboarding clients under your brand.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(13, 43, 142, 0.2), transparent); border: 1px solid var(--wl-red);">
            <h2 style="margin-bottom: 20px;">Don't Build. Rebrand.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Focus on sales and let us handle the tech.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary" style="background: var(--wl-red); border: none;">Get Started</a>
                <a href="contact.php" class="btn-nav-ghost">Request Demo</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>