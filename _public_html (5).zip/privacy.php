<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Privacy Policy | BulkSMSIndia</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #050a12;
            --card-bg: #0d141f;
            --accent-red: #d11a1a;
            --text-main: #ffffff;
            --text-muted: #a0a6b1;
            --border: rgba(255, 255, 255, 0.08);
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            line-height: 1.8;
        }

        .container {
            max-width: 1200px;
            margin: 60px auto;
            padding: 0 40px;
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 60px;
        }

        /* Sidebar Navigation */
        .sidebar {
            position: sticky;
            top: 100px;
            height: fit-content;
        }

        .sidebar h4 {
            color: var(--accent-red);
            text-transform: uppercase;
            letter-spacing: 1px;
            font-size: 0.8rem;
            margin-bottom: 20px;
        }

        .sidebar ul {
            list-style: none;
            padding: 0;
        }

        .sidebar ul li {
            margin-bottom: 15px;
        }

        .sidebar ul li a {
            color: var(--text-muted);
            text-decoration: none;
            font-size: 0.95rem;
            transition: 0.3s;
        }

        .sidebar ul li a:hover {
            color: var(--text-main);
            padding-left: 5px;
        }

        /* Content Area */
        .content-header {
            margin-bottom: 40px;
            border-bottom: 1px solid var(--border);
            padding-bottom: 30px;
        }

        .content-header h1 {
            font-size: 3rem;
            font-weight: 800;
            margin-bottom: 10px;
        }

        .last-updated {
            color: var(--accent-red);
            font-weight: 600;
            font-size: 0.9rem;
        }

        .content-section {
            margin-bottom: 50px;
        }

        .content-section h2 {
            font-size: 1.8rem;
            color: var(--text-main);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }

        .content-section h2::before {
            content: "";
            width: 4px;
            height: 24px;
            background: var(--accent-red);
            margin-right: 15px;
            display: inline-block;
            border-radius: 2px;
        }

        .content-section p {
            color: var(--text-muted);
            margin-bottom: 20px;
        }

        .policy-list {
            list-style: none;
            padding: 0;
        }

        .policy-list li {
            position: relative;
            padding-left: 25px;
            color: var(--text-muted);
            margin-bottom: 12px;
        }

        .policy-list li::before {
            content: "→";
            position: absolute;
            left: 0;
            color: var(--accent-red);
            font-weight: bold;
        }

        @media (max-width: 992px) {
            .container { grid-template-columns: 1fr; }
            .sidebar { display: none; }
            .content-header h1 { font-size: 2.2rem; }
        }
    </style>
</head>
<body>

    <div class="container">
        <aside class="sidebar">
            <h4>Table of Contents</h4>
            <ul>
                <li><a href="#collection">1. Data Collection</a></li>
                <li><a href="#usage">2. How We Use Data</a></li>
                <li><a href="#protection">3. Data Protection</a></li>
                <li><a href="#cookies">4. Cookies Policy</a></li>
                <li><a href="#contact">5. Contact Support</a></li>
            </ul>
        </aside>

        <main class="content">
            <header class="content-header">
                <p class="last-updated">Effective Date: April 14, 2026</p>
                <h1>Privacy Policy</h1>
                <p style="color: var(--text-muted);">At BulkSMSIndia, we value your trust. This policy explains how we handle your business and personal information.</p>
            </header>

            <section class="content-section" id="collection">
                <h2>Information We Collect</h2>
                <p>To provide our AI-powered messaging services, we collect information that helps us verify your business and optimize your routing.</p>
                <ul class="policy-list">
                    <li>Registration details including Company Name and GST.</li>
                    <li>Contact information (Email, Phone Number).</li>
                    <li>Messaging data required for TRAI DLT compliance.</li>
                    <li>Technical logs for security and performance monitoring.</li>
                </ul>
            </section>

            <section class="content-section" id="usage">
                <h2>How We Use Your Data</h2>
                <p>Your data is used strictly for the purpose of delivering messages and improving platform performance.</p>
                <ul class="policy-list">
                    <li>To facilitate SMS, WhatsApp, and Voice interactions.</li>
                    <li>To verify DLT headers and content templates.</li>
                    <li>To provide real-time AI-based routing analytics.</li>
                    <li>To prevent fraudulent activities on our network.</li>
                </ul>
            </section>

            <section class="content-section" id="protection">
                <h2>Data Protection & Security</h2>
                <p>We implement enterprise-grade security protocols to ensure your data remains confidential and secure from unauthorized access.</p>
                <p>All messaging traffic is encrypted, and our servers are hosted in high-security Tier-3 data centers with restricted access.</p>
            </section>

            <section class="content-section" id="contact">
                <h2>Contact Our Data Team</h2>
                <p>If you have any questions regarding your data privacy, please reach out to our legal department.</p>
                <div style="background: var(--card-bg); padding: 25px; border-radius: 12px; border: 1px solid var(--border);">
                    <p style="margin: 0; color: white;"><strong>Email:</strong> privacy@bulksmsindia.com</p>
                    <p style="margin: 5px 0 0; color: white;"><strong>Response Time:</strong> 24-48 Business Hours</p>
                </div>
            </section>
        </main>
    </div>
<?php include 'includes/footer.php'; ?>
</body>
</html>