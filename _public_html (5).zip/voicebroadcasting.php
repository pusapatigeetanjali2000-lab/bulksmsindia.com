<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Automated Voice Broadcasting Services | BulkSMSIndia";
?>

<style>
    :root {
        --audio-red: #DB1212;
        --audio-wave: rgba(219, 18, 18, 0.3);
    }

    .voice-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.85), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1590602847861-f357a9332bbc?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-voice {
        padding: 180px 4% 100px;
        text-align: center;
    }

    .wave-container {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 5px;
        height: 40px;
        margin-bottom: 25px;
    }

    .wave-bar {
        width: 4px;
        background: var(--audio-red);
        border-radius: 10px;
        animation: sound-wave 1s ease-in-out infinite;
    }

    @keyframes sound-wave {
        0%, 100% { height: 10px; }
        50% { height: 40px; }
    }

    .voice-card {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s ease;
    }

    .voice-card:hover {
        border-color: var(--audio-red);
        background: rgba(219, 18, 18, 0.05);
        transform: translateY(-5px);
    }

    .voice-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 60px 4%;
    }

    .use-case-box {
        background: rgba(13, 43, 142, 0.2);
        padding: 20px;
        border-radius: 15px;
        margin-bottom: 15px;
        border-left: 4px solid var(--yellow);
    }
</style>

<div class="voice-bg">
    <section class="hero-voice">
        <div class="wave-container">
            <div class="wave-bar" style="animation-delay: 0.1s"></div>
            <div class="wave-bar" style="animation-delay: 0.3s"></div>
            <div class="wave-bar" style="animation-delay: 0.5s"></div>
            <div class="wave-bar" style="animation-delay: 0.2s"></div>
            <div class="wave-bar" style="animation-delay: 0.4s"></div>
        </div>
        <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 900; line-height: 1.1;">
            Let Your Brand <span style="color: var(--audio-red);">Speak Volume</span>
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.15rem;">
            Deliver personalized, automated voice messages to thousands of customers simultaneously. 
            Perfect for alerts, reminders, and election campaigns with 100% human-like clarity.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div class="voice-grid">
            <div class="voice-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🎙️ Personal Touch</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Voice carries emotion. Reach users who prefer listening over reading with high-quality recorded audio.</p>
            </div>
            <div class="voice-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">📞 Retry Logic</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Didn't pick up? Our system automatically retries busy or unanswered numbers to ensure delivery.</p>
            </div>
            <div class="voice-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">📊 Call Reports</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Track exactly how many seconds each user listened and who pressed a key to talk to an agent.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div>
                <h2 style="font-size: 2.5rem; margin-bottom: 35px;">Versatile <span>Applications</span></h2>
                <div class="use-case-box">
                    <strong>🗳️ Political Campaigns:</strong> Reach voters in their local language with personalized messages from leaders.
                </div>
                <div class="use-case-box">
                    <strong>🔔 Appointment Alerts:</strong> Remind patients or clients about schedules to reduce "no-show" rates.
                </div>
                <div class="use-case-box">
                    <strong>💸 Payment Reminders:</strong> Gently remind customers about pending bills or subscription renewals.
                </div>
            </div>
            <div>
                <img src="https://images.unsplash.com/photo-1478737270239-2f02b77fc618?auto=format&fit=crop&w=800&q=80" alt="Podcast Microphone" style="width: 100%; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.5); filter: contrast(1.1);">
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 60px;">4 Steps to <span>Broadcast</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 25px;">
            <div class="voice-card">
                <div style="font-size: 0.8rem; color: var(--audio-red); font-weight: 800; margin-bottom: 10px;">STEP 01</div>
                <h4>Upload Audio</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Upload your MP3/WAV file or use our Text-to-Speech tool.</p>
            </div>
            <div class="voice-card">
                <div style="font-size: 0.8rem; color: var(--audio-red); font-weight: 800; margin-bottom: 10px;">STEP 02</div>
                <h4>Import List</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Upload your contact database via Excel or CSV with one click.</p>
            </div>
            <div class="voice-card">
                <div style="font-size: 0.8rem; color: var(--audio-red); font-weight: 800; margin-bottom: 10px;">STEP 03</div>
                <h4>Schedule</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Choose to send now or schedule for a specific date and time.</p>
            </div>
            <div class="voice-card">
                <div style="font-size: 0.8rem; color: var(--audio-red); font-weight: 800; margin-bottom: 10px;">STEP 04</div>
                <h4>Monitor</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Get detailed insights on answered calls and listen duration.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="padding: 60px; border-radius: 40px; border: 1px solid var(--audio-red); background: rgba(219, 18, 18, 0.05);">
            <h3 style="font-size: 2.2rem; margin-bottom: 20px;">Ready to be heard?</h3>
            <p style="margin-bottom: 35px; color: var(--text-300);">Start your first voice broadcasting campaign in minutes.</p>
            <a href="signup.php" class="btn-nav-primary">Launch Voice Campaign</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>