<?php
// 1. Detect if the user is on a mobile device
$userAgent = $_SERVER['HTTP_USER_AGENT'];
$isMobile = preg_match('/(android|iphone|ipad|iemobile|opera mini)/i', $userAgent);

// 2. Load the correct version based on the device
if ($isMobile) {
    // This will load the mobile-specific code you shared in the prompt
    include('signup-mobile.php'); 
} else {
    // This will load your desktop-specific "web" version
    include('signup-web.php'); 
}
?>
