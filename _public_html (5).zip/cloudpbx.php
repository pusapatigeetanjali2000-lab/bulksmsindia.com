<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Cloud PBX | Smart Virtual Phone System | BulkSMSIndia";
?>

<style>
    :root {
        --pbx-navy: #0D2B8E;
        --pbx-red: #DB1212;
        --pbx-yellow: #FFD700;
        --pbx-glass: rgba(255, 255, 255, 0.03);
    }

    .pbx-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.94), rgba(5, 10, 21, 0.97)), 
                    url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
        color: #fff;
    }

    .hero-pbx {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .pbx-chip {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background: rgba(255, 215, 0, 0.1);
        border: 1px solid var(--pbx-yellow);
        border-radius: 50px;
        color: var(--pbx-yellow);
        font-size: 0.75rem;
        font-weight: 800;
        margin-bottom: 30px;
        letter-spacing: 2px;
    }

    .pbx-card {
        background: var(--pbx-glass);
        backdrop-filter: blur(25px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 30px;
        padding: 40px;
        transition: all 0.5s cubic-bezier(0.2, 0.8, 0.2, 1);
        position: relative;
    }

    .pbx-card:hover {
        border-color: var(--pbx-red);
        background: rgba(219, 18, 18, 0.05);
        transform: scale(1.02);
        box-shadow: 0 20px 60px rgba(219, 18, 18, 0.15);
    }

    .pbx-icon {
        font-size: 2.5rem;
        margin-bottom: 25px;
        display: block;
    }

    .cloud-pulse {
        width: 12px;
        height: 12px;
        background: var(--pbx-red);
        border-radius: 50%;
        display: inline-block;
        box-shadow: 0 0 15px var(--pbx-red);
        animation: pulse-red 2s infinite;
        margin-right: 10px;
    }

    @keyframes pulse-red {
        0% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(219, 18, 18, 0.7); }
        70% { transform: scale(1); box-shadow: 0 0 0 10px rgba(219, 18, 18, 0); }
        100% { transform: scale(0.95); box-shadow: 0 0 0 0 rgba(219, 18, 18, 0); }
    }
</style>

<div class="pbx-bg">
    <section class="hero-pbx">
        <div class="pbx-chip">
            <span class="cloud-pulse"></span> VIRTUAL TELEPHONY
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1.1;">
            Your Office Phone, <br><span style="color: var(--pbx-yellow);">Everywhere.</span>
        </h1>
        <p style="max-width: 850px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Upgrade to a scalable, enterprise-grade Cloud PBX system. Manage calls, extensions, 
            and IVRs from a single dashboard—no hardware required.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="pbx-card">
                <span class="pbx-icon">☁️</span>
                <h3 style="color: #fff; margin-bottom: 15px;">Zero Hardware</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Save on maintenance and setup costs. Everything is hosted in our secure, high-uptime cloud environment.</p>
            </div>
            <div class="pbx-card">
                <span class="pbx-icon">🔄</span>
                <h3 style="color: #fff; margin-bottom: 15px;">Infinite Scaling</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Add extensions or new global offices in seconds. Our system grows as fast as your business does.</p>
            </div>
            <div class="pbx-card">
                <span class="pbx-icon">🎛️</span>
                <h3 style="color: #fff; margin-bottom: 15px;">Smart Features</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Get advanced tools like Auto-Attendant, Call Recording, and Voicemail-to-Email right out of the box.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.4);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=800&q=80" alt="Remote Business Call" style="width: 100%; border-radius: 40px; border: 1px solid var(--pbx-navy); box-shadow: 0 0 50px rgba(13, 43, 142, 0.3);">
                <div style="position: absolute; -bottom: 20px; -left: 20px; background: var(--pbx-yellow); color: #000; padding: 20px 30px; border-radius: 20px; font-weight: 800;">
                    24/7 Global Access
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Perfect for <span>Modern Business</span></h2>
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <div style="padding: 25px; background: var(--pbx-glass); border-radius: 20px; border-left: 5px solid var(--pbx-red);">
                        <h4 style="color: var(--pbx-yellow);">Corporate Offices</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Connect multiple branches under one unified extension system for seamless internal calls.</p>
                    </div>
                    <div style="padding: 25px; background: var(--pbx-glass); border-radius: 20px; border-left: 5px solid var(--pbx-red);">
                        <h4 style="color: var(--pbx-yellow);">Customer Support Centers</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Deploy advanced IVRs and call queues to handle high volumes of customer inquiries efficiently.</p>
                    </div>
                    <div style="padding: 25px; background: var(--pbx-glass); border-radius: 20px; border-left: 5px solid var(--pbx-red);">
                        <h4 style="color: var(--pbx-yellow);">Remote Startups</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Give your remote team a professional landline presence on their personal smartphones.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <h2 style="margin-bottom: 70px;">Start Talking in <span>Minutes</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 30px;">
            <div class="pbx-card">
                <h1 style="color: var(--pbx-red); opacity: 0.2; font-size: 4rem; margin-bottom: 10px;">01</h1>
                <h4>Select Number</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Choose from local, national, or toll-free numbers in 60+ countries.</p>
            </div>
            <div class="pbx-card">
                <h1 style="color: var(--pbx-red); opacity: 0.2; font-size: 4rem; margin-bottom: 10px;">02</h1>
                <h4>Set IVR</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Design your call flow—"Press 1 for Sales, 2 for Support"—in minutes.</p>
            </div>
            <div class="pbx-card">
                <h1 style="color: var(--pbx-red); opacity: 0.2; font-size: 4rem; margin-bottom: 10px;">03</h1>
                <h4>Add Users</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Create extensions for your team and assign them to specific departments.</p>
            </div>
            <div class="pbx-card">
                <h1 style="color: var(--pbx-red); opacity: 0.2; font-size: 4rem; margin-bottom: 10px;">04</h1>
                <h4>Connect</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Use IP phones, desktop apps, or mobile apps to start making calls.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(219, 18, 18, 0.1), transparent); border: 1px solid var(--pbx-yellow);">
            <h2 style="margin-bottom: 20px;">Move your dial pad to the Cloud.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Reliable, crystal-clear voice communication for the modern world.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary" style="background: var(--pbx-red); border: none;">Get Started</a>
                <a href="contact.php" class="btn-nav-ghost">Book a Demo</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>

