<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "RCS Business Messaging | Rich SMS 2.0 | BulkSMSIndia";
?>

<style>
    :root {
        --rcs-blue: #4285F4;
        --rcs-red: #EA4335;
        --rcs-yellow: #FBBC05;
        --rcs-green: #34A853;
        --glass-rcs: rgba(66, 133, 244, 0.05);
    }

    .rcs-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.85), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-rcs {
        padding: 180px 4% 100px;
        text-align: center;
    }

    .google-badge {
        display: inline-flex;
        align-items: center;
        gap: 12px;
        padding: 10px 25px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 50px;
        margin-bottom: 30px;
        backdrop-filter: blur(10px);
    }

    .rcs-card {
        background: var(--glass-rcs);
        border: 1px solid rgba(66, 133, 244, 0.2);
        padding: 40px;
        border-radius: 24px;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        position: relative;
    }

    .rcs-card:hover {
        background: rgba(66, 133, 244, 0.1);
        border-color: var(--rcs-blue);
        transform: translateY(-8px);
        box-shadow: 0 20px 40px rgba(66, 133, 244, 0.15);
    }

    .carousel-mockup {
        background: #000;
        border: 8px solid #1a1a1a;
        border-radius: 40px;
        width: 300px;
        height: 550px;
        margin: 0 auto;
        padding: 20px;
        position: relative;
        box-shadow: 0 50px 100px rgba(0,0,0,0.5);
    }

    .rich-card {
        background: #fff;
        border-radius: 15px;
        overflow: hidden;
        margin-top: 50px;
    }

    .rich-card img { width: 100%; height: 120px; object-fit: cover; }
    .rich-card-content { padding: 15px; color: #333; }
    .rich-btn {
        background: #f1f3f4;
        border: 1px solid #dadce0;
        padding: 8px;
        border-radius: 20px;
        text-align: center;
        font-size: 0.8rem;
        margin-top: 10px;
        color: var(--rcs-blue);
        font-weight: 600;
    }
</style>

<div class="rcs-bg">
    <section class="hero-rcs">
        <div class="google-badge">
            <img src="https://upload.wikimedia.org/wikipedia/commons/c/c1/Google_Messaging_Icon.svg" width="24" alt="Google">
            <span style="font-size: 0.9rem; font-weight: 600; letter-spacing: 0.5px;">Powered by Google Jibe Cloud</span>
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1;">
            The Future of <br><span style="color: var(--rcs-blue);">SMS is Here.</span>
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Upgrade from plain text to rich experiences. RCS brings app-like functionality—including high-res images, carousels, and suggested actions—directly into the native message app.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="rcs-card">
                <h3 style="color: var(--rcs-blue); margin-bottom: 15px;">✨ Branding Without Limits</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Show your logo, brand name, and verified checkmark. No more mysterious 6-digit sender IDs.</p>
            </div>
            <div class="rcs-card">
                <h3 style="color: var(--rcs-red); margin-bottom: 15px;">📊 Rich Analytics</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Track not just delivery, but open rates, button clicks, and session engagement in real-time.</p>
            </div>
            <div class="rcs-card">
                <h3 style="color: var(--rcs-green); margin-bottom: 15px;">🛒 Conversational Commerce</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Let customers browse products, select sizes, and book appointments inside the chat bubble.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(13, 43, 142, 0.1);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div class="carousel-mockup">
                <div style="text-align: center; color: #fff; font-size: 0.7rem; margin-bottom: 10px;">Brand Name Verified ✓</div>
                <div class="rich-card">
                    <img src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=400&q=80" alt="Shoes">
                    <div class="rich-card-content">
                        <h5 style="margin:0">Summer Collection</h5>
                        <p style="font-size: 0.7rem; margin: 5px 0;">Get 30% off on all sneakers today!</p>
                        <div class="rich-btn">Shop Now</div>
                        <div class="rich-btn">View Catalog</div>
                    </div>
                </div>
                <div style="position: absolute; bottom: 30px; width: 85%; height: 35px; border-radius: 20px; background: #333; left: 7.5%;"></div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Native Engagement, <br><span style="color: var(--rcs-yellow);">No App Required</span></h2>
                <p style="color: var(--text-300); margin-bottom: 30px;">RCS works on the default Android Messages app, meaning your customers don't need to download anything new to interact with your brand.</p>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div style="display: flex; gap: 15px; align-items: center;">
                        <span style="color: var(--rcs-blue); font-weight: bold;">01</span>
                        <span>High-Resolution Images & Videos</span>
                    </div>
                    <div style="display: flex; gap: 15px; align-items: center;">
                        <span style="color: var(--rcs-red); font-weight: bold;">02</span>
                        <span>Horizontal Product Carousels</span>
                    </div>
                    <div style="display: flex; gap: 15px; align-items: center;">
                        <span style="color: var(--rcs-green); font-weight: bold;">03</span>
                        <span>Suggested Replies & Quick Actions</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Start Your <span style="color: var(--rcs-blue);">RCS Journey</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 25px;">
            <div class="rcs-card" style="padding: 30px;">
                <h4 style="color: var(--rcs-blue);">Register Agent</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Submit your brand profile for Google Business verification.</p>
            </div>
            <div class="rcs-card" style="padding: 30px;">
                <h4 style="color: var(--rcs-red);">Design Experience</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Create rich cards and carousel templates for your campaign.</p>
            </div>
            <div class="rcs-card" style="padding: 30px;">
                <h4 style="color: var(--rcs-yellow);">Integration</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Connect our API to trigger RCS messages via your CRM.</p>
            </div>
            <div class="rcs-card" style="padding: 30px;">
                <h4 style="color: var(--rcs-green);">Analyze Growth</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Monitor read receipts and button interaction metrics.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(66, 133, 244, 0.1), transparent); border: 1px solid var(--rcs-blue);">
            <h3 style="font-size: 2.2rem; margin-bottom: 20px;">Ready to send the next generation of SMS?</h3>
            <p style="margin-bottom: 35px; color: var(--text-300);">Join the elite brands already using RCS for higher conversion rates.</p>
            <a href="signup.php" class="btn-nav-primary" style="background: var(--rcs-blue); border: none;">Get RCS API Access</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>