<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Global DID Numbers | Virtual Local Presence | BulkSMSIndia";
?>

<style>
    :root {
        --did-blue: #0D2B8E;
        --did-red: #DB1212;
        --did-glass: rgba(255, 255, 255, 0.03);
    }

    .did-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1526772662000-3f88f10405ff?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-did {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .location-tag {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 10px 20px;
        background: rgba(219, 18, 18, 0.1);
        border: 1px solid var(--did-red);
        border-radius: 50px;
        color: #fff;
        font-size: 0.85rem;
        font-weight: 600;
        margin-bottom: 25px;
        backdrop-filter: blur(10px);
    }

    .did-card {
        background: var(--did-glass);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
    }

    .did-card:hover {
        border-color: var(--did-red);
        background: rgba(13, 43, 142, 0.1);
        transform: translateY(-10px);
    }

    .did-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 60px 4%;
    }

    .number-preview {
        font-family: 'Courier New', monospace;
        background: rgba(0,0,0,0.3);
        padding: 15px;
        border-radius: 12px;
        color: var(--yellow);
        font-size: 1.2rem;
        display: inline-block;
        margin-bottom: 20px;
        border: 1px dashed rgba(255,255,255,0.2);
    }

    .step-pill {
        width: 35px;
        height: 35px;
        background: var(--did-red);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        margin-bottom: 20px;
    }
</style>

<div class="did-bg">
    <section class="hero-did">
        <div class="location-tag">
            🌎 Available in 100+ Countries
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1;">
            Local Numbers. <br><span style="color: var(--did-red);">Global Reach.</span>
        </h1>
        <p style="max-width: 850px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Give your business a local identity in any city or country. With DID (Direct Inward Dialing), 
            your customers can call a local number, and you can answer it anywhere in the world via the cloud.
        </p>
    </section>

    <section class="did-grid">
        <div class="did-card">
            <h3 style="color: var(--yellow); margin-bottom: 15px;">📍 Establish Local Trust</h3>
            <p style="color: var(--text-300); font-size: 0.95rem;">Customers are 4x more likely to answer a call from a local area code than an international or toll-free number.</p>
        </div>
        <div class="did-card">
            <h3 style="color: var(--yellow); margin-bottom: 15px;">♾️ Unlimited Channels</h3>
            <p style="color: var(--text-300); font-size: 0.95rem;">Handle hundreds of concurrent calls on a single DID number without a busy signal, perfect for marketing campaigns.</p>
        </div>
        <div class="did-card">
            <h3 style="color: var(--yellow); margin-bottom: 15px;">📲 Instant Provisioning</h3>
            <p style="color: var(--text-300); font-size: 0.95rem;">Browse our inventory and activate your new virtual number in minutes. No physical lines required.</p>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.2);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1534536281715-e28d76689b4d?auto=format&fit=crop&w=800&q=80" alt="Global Communication" style="width: 100%; border-radius: 40px; border: 1px solid var(--did-blue); box-shadow: 0 0 50px rgba(13, 43, 142, 0.3);">
                <div style="position: absolute; top: -20px; left: -20px; background: var(--did-red); padding: 15px 25px; border-radius: 15px; font-weight: bold;">
                    London +44
                </div>
                <div style="position: absolute; bottom: 20px; right: -20px; background: var(--did-blue); padding: 15px 25px; border-radius: 15px; font-weight: bold;">
                    New York +1
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Grow Beyond <br><span style="color: var(--red);">Borders</span></h2>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div style="padding: 20px; background: rgba(255,255,255,0.03); border-radius: 15px; border-left: 4px solid var(--did-red);">
                        <h4 style="color: var(--yellow);">Virtual Offices</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Look like a local company in Tokyo, Paris, or Dubai while operating from your home office.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(255,255,255,0.03); border-radius: 15px; border-left: 4px solid var(--did-red);">
                        <h4 style="color: var(--yellow);">Marketing Tracking</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Assign unique DID numbers to different ads to track which campaign is driving the most calls.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(255,255,255,0.03); border-radius: 15px; border-left: 4px solid var(--did-red);">
                        <h4 style="color: var(--yellow);">Two-Way Privacy</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Keep your personal mobile number private by using a professional DID for all business incoming calls.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Get Your Number in <span>3 Easy Steps</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 40px;">
            <div class="did-card">
                <div class="step-pill">1</div>
                <h4>Choose Country</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Select from over 100 countries and 5,000+ local area codes.</p>
            </div>
            <div class="did-card">
                <div class="step-pill">2</div>
                <h4>Configure Routing</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Point your DID to a mobile, landline, or an IP address (SIP Trunk).</p>
            </div>
            <div class="did-card">
                <div class="step-pill">3</div>
                <h4>Start Receiving</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Go live instantly and track your call logs in our real-time dashboard.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(13, 43, 142, 0.2), transparent); border: 1px solid var(--did-red);">
            <h2 style="margin-bottom: 20px;">Ready to go local?</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Secure your custom DID number today and start growing your global footprint.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary" style="background: var(--did-red); border: none;">Search Available Numbers</a>
                <a href="contact.php" class="btn-nav-ghost">Bulk Pricing Inquiry</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>