<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Smart AI Toolkit | Productivity & Automation | BulkSMSIndia";
?>

<style>
    :root {
        --brand-navy: #0D2B8E;
        --brand-red: #DB1212;
        --brand-yellow: #FFD700;
        --light-bg: #FFFFFF;
        --soft-gray: #f8f9fa;
    }

    body {
        background-color: var(--light-bg);
        color: #333;
    }

    .tools-hero {
        padding: 160px 4% 80px;
        background: linear-gradient(135deg, var(--brand-navy) 0%, #061a5e 100%);
        color: white;
        text-align: center;
        clip-path: ellipse(150% 100% at 50% 0%);
    }

    .tool-card {
        background: white;
        border-radius: 20px;
        padding: 30px;
        box-shadow: 0 10px 30px rgba(0,0,0,0.05);
        border: 1px solid #eee;
        transition: all 0.3s ease;
        text-align: left;
        position: relative;
        overflow: hidden;
    }

    .tool-card:hover {
        transform: translateY(-10px);
        border-color: var(--brand-red);
        box-shadow: 0 15px 35px rgba(219, 18, 18, 0.1);
    }

    .tool-icon {
        width: 50px;
        height: 50px;
        background: var(--soft-gray);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
        margin-bottom: 20px;
        color: var(--brand-navy);
    }

    .btn-red {
        background: var(--brand-red);
        color: white;
        padding: 12px 25px;
        border-radius: 8px;
        text-decoration: none;
        font-weight: 600;
        display: inline-block;
        transition: 0.3s;
        border: none;
    }

    .btn-red:hover {
        background: #b30e0e;
        box-shadow: 0 5px 15px rgba(219, 18, 18, 0.3);
    }

    .section-tag {
        color: var(--brand-red);
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 2px;
        font-size: 0.8rem;
        display: block;
        margin-bottom: 10px;
    }
</style>

<div class="main-wrapper">
    <section class="tools-hero">
        <div style="max-width: 900px; margin: 0 auto;">
            <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 800; margin-bottom: 20px;">
                Work Smarter with <span style="color: var(--brand-yellow);">AI Tools</span>
            </h1>
            <p style="font-size: 1.1rem; opacity: 0.9; line-height: 1.7;">
                Boost your workflow with our suite of specialized AI utilities. From content generation 
                to deep data insights, we provide the tools you need to stay ahead.
            </p>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <span class="section-tag" style="text-align: center;">THE ESSENTIAL TOOLKIT</span>
        <h2 style="text-align: center; font-size: 2.5rem; margin-bottom: 60px; color: var(--brand-navy);">Powering Your Daily Tasks</h2>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px;">
            <div class="tool-card">
                <div class="tool-icon">📝</div>
                <h4 style="margin-bottom: 10px;">Smart Copywriter</h4>
                <p style="font-size: 0.9rem; color: #666; margin-bottom: 20px;">Generate high-converting SMS, Email, and Social media copy in seconds.</p>
                <a href="#" class="btn-red" style="font-size: 0.8rem;">Try Tool</a>
            </div>
            <div class="tool-card">
                <div class="tool-icon">📊</div>
                <h4 style="margin-bottom: 10px;">Lead Scorer</h4>
                <p style="font-size: 0.9rem; color: #666; margin-bottom: 20px;">AI-driven analysis to identify your most valuable prospects instantly.</p>
                <a href="#" class="btn-red" style="font-size: 0.8rem;">Try Tool</a>
            </div>
            <div class="tool-card">
                <div class="tool-icon">🎙️</div>
                <h4 style="margin-bottom: 10px;">Voice-to-Text</h4>
                <p style="font-size: 0.9rem; color: #666; margin-bottom: 20px;">Highly accurate transcription for meetings, calls, and voice notes.</p>
                <a href="#" class="btn-red" style="font-size: 0.8rem;">Try Tool</a>
            </div>
            <div class="tool-card">
                <div class="tool-icon">🔍</div>
                <h4 style="margin-bottom: 10px;">Sentiment Analysis</h4>
                <p style="font-size: 0.9rem; color: #666; margin-bottom: 20px;">Understand the emotional tone of customer feedback at scale.</p>
                <a href="#" class="btn-red" style="font-size: 0.8rem;">Try Tool</a>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: var(--soft-gray);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1664575602554-2087b04935a5?auto=format&fit=crop&w=800&q=80" 
                     alt="AI Productivity" 
                     style="width: 100%; border-radius: 30px; box-shadow: 0 20px 40px rgba(0,0,0,0.1);">
                <div style="position: absolute; top: -20px; right: -20px; background: var(--brand-yellow); padding: 15px; border-radius: 15px; font-weight: bold; color: var(--brand-navy);">
                    ⚡ 10x Faster
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.5rem; color: var(--brand-navy); margin-bottom: 25px;">Built for <span>Growth</span></h2>
                <p style="color: #666; margin-bottom: 30px; line-height: 1.8;">Our tools are integrated into industries ranging from <strong>E-commerce</strong> to <strong>Real Estate</strong>, helping teams automate repetitive tasks and focus on creative strategy.</p>
                
                <ul style="list-style: none; padding: 0; display: flex; flex-direction: column; gap: 15px;">
                    <li style="display: flex; gap: 10px; align-items: center; color: var(--brand-navy); font-weight: 600;">
                        <span style="color: var(--brand-red);">✔</span> One-click integrations
                    </li>
                    <li style="display: flex; gap: 10px; align-items: center; color: var(--brand-navy); font-weight: 600;">
                        <span style="color: var(--brand-red);">✔</span> Real-time data processing
                    </li>
                    <li style="display: flex; gap: 10px; align-items: center; color: var(--brand-navy); font-weight: 600;">
                        <span style="color: var(--brand-red);">✔</span> Secure & Compliant
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <span class="section-tag">GET STARTED</span>
        <h2 style="font-size: 2.5rem; color: var(--brand-navy); margin-bottom: 60px;">Using AI Tools is Easy</h2>
        
        <div style="display: flex; justify-content: center; gap: 40px; flex-wrap: wrap;">
            <div style="max-width: 250px;">
                <div style="font-size: 2rem; font-weight: 900; color: #eee; margin-bottom: 10px;">01</div>
                <h4 style="color: var(--brand-navy);">Select Tool</h4>
                <p style="font-size: 0.85rem; color: #777;">Browse our catalog and pick the tool that fits your current task.</p>
            </div>
            <div style="max-width: 250px;">
                <div style="font-size: 2rem; font-weight: 900; color: #eee; margin-bottom: 10px;">02</div>
                <h4 style="color: var(--brand-navy);">Input Data</h4>
                <p style="font-size: 0.85rem; color: #777;">Paste your text, upload your file, or connect your data source.</p>
            </div>
            <div style="max-width: 250px;">
                <div style="font-size: 2rem; font-weight: 900; color: #eee; margin-bottom: 10px;">03</div>
                <h4 style="color: var(--brand-navy);">Get Results</h4>
                <p style="font-size: 0.85rem; color: #777;">Receive AI-generated insights or content instantly.</p>
            </div>
        </div>
    </section>

    <section style="padding: 80px 4%; text-align: center; background: #fafafa;">
        <div style="max-width: 800px; margin: 0 auto; padding: 60px; border-radius: 40px; background: white; border: 1px solid #eee;">
            <h2 style="color: var(--brand-navy); margin-bottom: 20px;">Ready to unlock the future?</h2>
            <p style="color: #666; margin-bottom: 40px;">Join thousands of professionals using BulkSMSIndia AI Tools to supercharge their productivity.</p>
            <a href="signup.php" class="btn-red" style="padding: 18px 50px;">Create Free Account</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>