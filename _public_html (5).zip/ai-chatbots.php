<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Smart AI Chatbots | 24/7 Automated Conversations | BulkSMSIndia";
?>

<style>
    :root {
        --bot-navy: #0D2B8E;
        --bot-red: #DB1212;
        --bot-glass: rgba(255, 255, 255, 0.04);
    }

    .bot-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.97)), 
                    url('https://images.unsplash.com/photo-1531746790731-6c087fecd05a?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-bot {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .typing-indicator {
        display: inline-flex;
        gap: 4px;
        padding: 12px 20px;
        background: var(--bot-glass);
        border-radius: 30px;
        border: 1px solid rgba(255,255,255,0.1);
        margin-bottom: 25px;
    }

    .dot {
        width: 6px;
        height: 6px;
        background: var(--bot-red);
        border-radius: 50%;
        animation: blink 1.4s infinite both;
    }

    .dot:nth-child(2) { animation-delay: 0.2s; }
    .dot:nth-child(3) { animation-delay: 0.4s; }

    @keyframes blink {
        0%, 80%, 100% { opacity: 0.2; }
        40% { opacity: 1; }
    }

    .chat-card {
        background: var(--bot-glass);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        padding: 35px;
        transition: all 0.3s ease;
        position: relative;
    }

    .chat-card:hover {
        border-color: var(--bot-red);
        transform: translateY(-5px);
        box-shadow: 0 10px 30px rgba(219, 18, 18, 0.1);
    }

    .bubble-tip {
        position: absolute;
        bottom: -10px;
        left: 30px;
        width: 20px;
        height: 20px;
        background: var(--bot-glass);
        clip-path: polygon(0 0, 100% 0, 0 100%);
        border-left: 1px solid rgba(255, 255, 255, 0.1);
    }
</style>

<div class="bot-bg">
    <section class="hero-bot">
        <div class="typing-indicator">
            <div class="dot"></div>
            <div class="dot"></div>
            <div class="dot"></div>
            <span style="font-size: 0.75rem; color: #fff; margin-left: 10px; font-weight: 600;">AI is typing...</span>
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1.1;">
            Talk to Your Customers <br><span style="color: var(--bot-red);">Everywhere, Instantly.</span>
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.15rem; line-height: 1.8;">
            Deploy smart, multilingual AI Chatbots on WhatsApp, Website, and Social Media. 
            Automate 80% of support queries and let your team focus on what matters most.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="chat-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🕒 24/7 Availability</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Your business never sleeps. AI Chatbots provide instant answers at 2 AM or 2 PM without any extra cost.</p>
                <div class="bubble-tip"></div>
            </div>
            <div class="chat-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🗣️ Multilingual Support</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Speak to your customers in their preferred language. Our bots support English, Hindi, and 50+ global languages.</p>
                <div class="bubble-tip"></div>
            </div>
            <div class="chat-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🔗 Omni-channel</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Build once, deploy everywhere. Keep the conversation seamless across WhatsApp, Web, and Facebook Messenger.</p>
                <div class="bubble-tip"></div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1596524430615-b46475ddff6e?auto=format&fit=crop&w=800&q=80" alt="Customer Support Agent" style="width: 100%; border-radius: 30px; box-shadow: 0 20px 50px rgba(0,0,0,0.5);">
                <div style="position: absolute; bottom: -20px; left: 20px; background: var(--bot-red); padding: 20px; border-radius: 15px; border: 1px solid rgba(255,255,255,0.1);">
                    <p style="margin:0; font-weight: 800; font-size: 1.5rem;">80%</p>
                    <p style="margin:0; font-size: 0.7rem; opacity: 0.8;">Routine Tasks Automated</p>
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Perfect for <span>Every Industry</span></h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                    <div style="padding: 20px; background: rgba(13, 43, 142, 0.2); border-radius: 15px;">
                        <h4 style="color: var(--yellow); margin-bottom: 8px;">E-commerce</h4>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Track orders and handle refund requests instantly.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(13, 43, 142, 0.2); border-radius: 15px;">
                        <h4 style="color: var(--yellow); margin-bottom: 8px;">Education</h4>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Answer admission queries and share course materials.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(13, 43, 142, 0.2); border-radius: 15px;">
                        <h4 style="color: var(--yellow); margin-bottom: 8px;">Real Estate</h4>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Capture leads and share property catalogs 24/7.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(13, 43, 142, 0.2); border-radius: 15px;">
                        <h4 style="color: var(--yellow); margin-bottom: 8px;">Travel</h4>
                        <p style="font-size: 0.85rem; color: var(--text-300);">Manage bookings and provide travel guidelines.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Start Chatting in <span>3 Steps</span></h2>
        <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 40px;">
            <div class="chat-card" style="flex: 1; min-width: 280px; text-align: center;">
                <div style="font-size: 2.5rem; margin-bottom: 15px;">🎨</div>
                <h4>1. Design Flow</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Use our drag-and-drop builder to create your conversation logic.</p>
            </div>
            <div class="chat-card" style="flex: 1; min-width: 280px; text-align: center;">
                <div style="font-size: 2.5rem; margin-bottom: 15px;">⚙️</div>
                <h4>2. Integration</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Connect your bot to WhatsApp, Website, or App via simple APIs.</p>
            </div>
            <div class="chat-card" style="flex: 1; min-width: 280px; text-align: center;">
                <div style="font-size: 2.5rem; margin-bottom: 15px;">🚀</div>
                <h4>3. Launch & Learn</h4>
                <p style="font-size: 0.9rem; color: var(--text-300); margin-top: 10px;">Go live and use AI insights to continuously improve responses.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 800px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(219, 18, 18, 0.1), transparent); border: 1px solid var(--bot-red);">
            <h2 style="margin-bottom: 20px;">Ready to automate your growth?</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Get started with BulkSMSIndia's AI Chatbots and transform your customer experience.</p>
            <a href="signup.php" class="btn-nav-primary">Build Your Bot Now</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>