<?php include('includes/header.php'); ?>

<style>
/* ========== DEMO PAGE ========== */
.demo-wrap { min-height:100vh; padding-top:70px; position:relative; overflow-x:hidden; }
.demo-bg-canvas {
    position:fixed; top:0; left:0; right:0; bottom:0; z-index:0; pointer-events:none;
    background: radial-gradient(ellipse at 10% 20%, rgba(255,107,0,0.22) 0%, transparent 45%),
        radial-gradient(ellipse at 90% 10%, rgba(0,212,255,0.18) 0%, transparent 40%),
        radial-gradient(ellipse at 50% 90%, rgba(124,58,237,0.18) 0%, transparent 50%),
        radial-gradient(ellipse at 80% 60%, rgba(255,0,128,0.13) 0%, transparent 40%),
        linear-gradient(160deg, #060612 0%, #0c0c25 40%, #080818 100%);
    animation: bgPulse 12s ease-in-out infinite alternate;
}
/* This ensures the button stays fixed at the bottom like the image */
.sticky-footer-btn {
    position: fixed; 
    bottom: 0; 
    left: 0; 
    right: 0; 
    z-index: 9999;
    background: linear-gradient(135deg, rgba(6,6,18,0.97), rgba(12,12,37,0.97));
    backdrop-filter: blur(12px); /* Glassmorphism effect */
    padding: 10px 15px;
    border-top: 1px solid rgba(255,107,0,0.3);
    display: flex;
    justify-content: center;
}

/* The Glowing Submit Button */
.btn-sticky-submit {
    width: 100%;
    padding: 15px;
    background: linear-gradient(90deg, #ff6b00, #ff0080);
    border-radius: 50px;
    color: #fff;
    font-weight: 900;
    text-transform: uppercase;
    box-shadow: 0 4px 15px rgba(255, 107, 0, 0.4);
}
@keyframes bgPulse { 0%{opacity:0.8} 100%{opacity:1} }
.floating-orb { position:fixed; border-radius:50%; filter:blur(80px); pointer-events:none; z-index:0; animation:orbDrift ease-in-out infinite alternate; }
@keyframes orbDrift { 0%{transform:translate(0,0) scale(1)} 100%{transform:translate(30px,-40px) scale(1.15)} }

.sticky-footer-btn {
    position: fixed; bottom: 0; left: 0; right: 0; z-index: 9990;
    background: linear-gradient(135deg, rgba(6,6,18,0.97), rgba(12,12,37,0.97));
    border-top: 1px solid rgba(255,107,0,0.35);
    padding: 12px 20px; display: flex; align-items: center; justify-content: center;
    gap: 14px; backdrop-filter: blur(12px); box-shadow: 0 -6px 30px rgba(255,107,0,0.18);
}
.sticky-footer-btn .sfb-text { font-family:'Rajdhani',sans-serif; font-size:13px; color:rgba(255,255,255,0.55); white-space:nowrap; }
.sfb-text span { color:var(--green); font-weight:700; }
.btn-sticky-submit {
    display:inline-flex; align-items:center; gap:9px; padding:13px 36px;
    background:linear-gradient(135deg,var(--primary) 0%,var(--accent) 50%,var(--purple) 100%);
    color:#fff; border:none; border-radius:50px; cursor:pointer;
    font-family:'Rajdhani',sans-serif; font-weight:900; font-size:18px; letter-spacing:0.5px;
    position:relative; overflow:hidden; white-space:nowrap;
    animation:stickyBlink 1.1s ease-in-out infinite, stickyGlow 2.2s ease-in-out infinite;
}
@keyframes stickyBlink { 0%,100%{opacity:1} 50%{opacity:0.55} }
@keyframes stickyGlow {
    0%,100%{box-shadow:0 6px 28px rgba(255,107,0,0.55)}
    50%{box-shadow:0 10px 50px rgba(255,0,128,0.7),0 0 70px rgba(255,107,0,0.45);transform:translateY(-2px)}
}
.btn-sticky-submit::before {
    content:''; position:absolute; top:-50%; left:-60%; width:35%; height:200%;
    background:rgba(255,255,255,0.18); transform:skewX(-22deg); animation:shimmer 3s ease-in-out infinite;
}
.btn-sticky-submit:hover { animation:none; opacity:1; transform:translateY(-3px) scale(1.05); box-shadow:0 14px 50px rgba(255,107,0,0.75); transition:all .25s; }
.demo-wrap { padding-bottom:90px !important; }
@media(max-width:600px) {
    .sticky-footer-btn .sfb-text { display:none; }
    .btn-sticky-submit { font-size:16px; padding:13px 28px; width:100%; justify-content:center; }
    .sticky-footer-btn { padding:10px 14px; }
}

/* HERO */
.demo-hero { position:relative; z-index:1; text-align:center; padding:55px 20px 35px; }
.hero-tags { display:flex; justify-content:center; gap:10px; flex-wrap:wrap; margin-bottom:22px; }
.htag { padding:5px 16px; border-radius:20px; font-size:11px; font-weight:700; letter-spacing:1.5px; text-transform:uppercase; font-family:'Rajdhani',sans-serif; }
.htag-o { background:rgba(255,107,0,0.15); border:1px solid rgba(255,107,0,0.5); color:var(--primary); }
.htag-c { background:rgba(0,212,255,0.12); border:1px solid rgba(0,212,255,0.4); color:var(--secondary); }
.htag-g { background:rgba(0,255,136,0.12); border:1px solid rgba(0,255,136,0.4); color:var(--green); }
.htag-p { background:rgba(124,58,237,0.15); border:1px solid rgba(124,58,237,0.4); color:#A855F7; }
.demo-hero h1 { font-family:'Rajdhani',sans-serif; font-size:clamp(32px,5.5vw,68px); font-weight:900; line-height:1.05; margin-bottom:18px; }
.go { background:linear-gradient(90deg,var(--primary),var(--accent),var(--purple)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
.hero-stats { display:flex; gap:25px; margin-top:30px; flex-wrap:wrap; justify-content:center; align-items:center; width:100%; }
.stat-item { text-align:center; }
.stat-num { font-family:'Rajdhani',sans-serif; font-size:32px; font-weight:900; background:linear-gradient(90deg,var(--primary),var(--secondary)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; }
.stat-label { font-size:12px; color:var(--text-muted); text-transform:uppercase; letter-spacing:1px; }
.trust-row { display:flex; justify-content:center; align-items:center; gap:22px; flex-wrap:wrap; margin-top:22px; }
.trust-chip { display:flex; align-items:center; gap:6px; font-size:12px; color:var(--text-muted); }

/* STEP BAR */
.step-bar { display:flex; align-items:flex-start; justify-content:center; margin-bottom:36px; position:relative; z-index:1; padding:0 20px; }
.step { display:flex; flex-direction:column; align-items:center; }
.step-dot { width:38px; height:38px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-family:'Rajdhani',sans-serif; font-weight:700; font-size:15px; border:2px solid rgba(255,255,255,0.1); color:var(--text-muted); background:rgba(255,255,255,0.05); z-index:1; }
.step.active .step-dot { background:linear-gradient(135deg,var(--primary),var(--accent)); border-color:var(--primary); color:#fff; box-shadow:0 0 18px rgba(255,107,0,0.5); }
.step.done   .step-dot { background:var(--green); border-color:var(--green); color:#000; }
.step-label { font-size:10px; color:var(--text-muted); margin-top:6px; text-align:center; white-space:nowrap; font-family:'Rajdhani',sans-serif; }
.step.active .step-label { color:var(--primary); font-weight:600; }
.step.done   .step-label { color:var(--green); }
.step-line { width:55px; height:2px; background:rgba(255,255,255,0.08); margin-top:-15px; flex-shrink:0; }
.step-line.done { background:linear-gradient(90deg,var(--green),var(--secondary)); }

/* FORM CARD */
.demo-card-wrap { position:relative; z-index:1; max-width:980px; margin:0 auto; padding:0 20px 70px; }
.demo-card {
    background:linear-gradient(145deg,rgba(255,255,255,0.065) 0%,rgba(255,255,255,0.025) 60%,rgba(124,58,237,0.06) 100%);
    border:1px solid rgba(0,212,255,0.22); border-radius:28px; padding:48px 44px;
    box-shadow:0 40px 90px rgba(0,0,0,0.55), inset 0 1px 0 rgba(255,255,255,0.07);
    backdrop-filter:blur(16px); position:relative; overflow:hidden;
}
.demo-card::before { content:''; position:absolute; top:0; left:0; right:0; height:4px; background:linear-gradient(90deg,var(--primary),var(--secondary),var(--accent),var(--green),var(--purple),var(--primary)); background-size:400% 100%; animation:rainbow 5s linear infinite; }
@keyframes rainbow { 0%{background-position:0%} 100%{background-position:400%} }

/* SECTION TITLES */
.fst { display:flex; align-items:center; gap:13px; margin:38px 0 20px; padding-bottom:14px; border-bottom:1px solid rgba(0,212,255,0.12); }
.fst:first-of-type { margin-top:0; }
.fst-ico { width:40px; height:40px; border-radius:11px; display:flex; align-items:center; justify-content:center; font-size:19px; flex-shrink:0; }
.ico-o { background:linear-gradient(135deg,rgba(255,107,0,0.3),rgba(255,107,0,0.08)); border:1px solid rgba(255,107,0,0.4); }
.ico-g { background:linear-gradient(135deg,rgba(0,255,136,0.3),rgba(0,255,136,0.08)); border:1px solid rgba(0,255,136,0.4); }
.ico-p { background:linear-gradient(135deg,rgba(124,58,237,0.3),rgba(124,58,237,0.08)); border:1px solid rgba(124,58,237,0.4); }
.fst-txt h3 { font-family:'Rajdhani',sans-serif; font-size:19px; font-weight:700; color:var(--text); }
.fst-txt p  { font-size:12px; color:var(--text-muted); margin-top:1px; }

/* GRIDS & FIELDS */
.fg2 { display:grid; grid-template-columns:1fr 1fr; gap:18px; }
.col-full { grid-column:1/-1; }
.fw { display:flex; flex-direction:column; gap:7px; }
.fw label { font-size:11px; font-weight:700; color:var(--text-muted); text-transform:uppercase; letter-spacing:1.2px; font-family:'Rajdhani',sans-serif; display:flex; align-items:center; gap:5px; }
.fw label .req { color:var(--accent); font-size:14px; line-height:1; }
.fw input, .fw select { width:100%; padding:13px 16px; background:rgba(255,255,255,0.05); border:1.5px solid rgba(0,212,255,0.18); border-radius:12px; color:var(--text); font-family:'Exo 2',sans-serif; font-size:14px; outline:none; transition:all .25s; box-sizing:border-box; }
.fw input::placeholder { color:rgba(153,153,187,0.55); }
.fw input:focus, .fw select:focus { border-color:var(--primary); background:rgba(255,107,0,0.06); box-shadow:0 0 0 3px rgba(255,107,0,0.12); }
.fw select { appearance:none; cursor:pointer; background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23FF6B00' stroke-width='2' fill='none' stroke-linecap='round'/%3E%3C/svg%3E"); background-repeat:no-repeat; background-position:right 14px center; padding-right:38px; background-color:#0c0c25; }
.fw select optgroup { background-color:#111130; color:rgba(0,212,255,0.85); font-weight:700; }
.fw select option { background-color:#0c0c25; color:#ffffff; }

/* PHONE ROW */
.phone-row { display:flex; flex-direction:row; gap:10px; align-items:center; width:100%; }
.phone-row select { flex:0 0 160px; width:160px; padding:13px 10px; background:rgba(255,255,255,0.05); border:1.5px solid rgba(0,212,255,0.18); border-radius:12px; color:var(--text); font-family:'Exo 2',sans-serif; font-size:13px; outline:none; cursor:pointer; appearance:auto; box-sizing:border-box; }
.phone-row input[type="tel"] { flex:1; min-width:0; padding:13px 16px; background:rgba(255,255,255,0.05); border:1.5px solid rgba(0,212,255,0.18); border-radius:12px; color:var(--text); font-family:'Exo 2',sans-serif; font-size:14px; outline:none; box-sizing:border-box; transition:all .25s; }
.phone-row select:focus, .phone-row input[type="tel"]:focus { border-color:var(--primary); background:rgba(255,107,0,0.06); box-shadow:0 0 0 3px rgba(255,107,0,0.12); }

/* CHIPS */
.vchips { display:flex; flex-wrap:wrap; gap:8px; }
.vchip { padding:7px 15px; border-radius:20px; cursor:pointer; font-size:13px; font-family:'Rajdhani',sans-serif; font-weight:600; border:1.5px solid rgba(0,212,255,0.22); background:rgba(255,255,255,0.04); color:var(--text-muted); transition:all .2s; user-select:none; }
.vchip:hover { border-color:var(--secondary); color:var(--secondary); }
.vchip.sel { background:linear-gradient(135deg,rgba(255,107,0,0.2),rgba(255,0,128,0.12)); border-color:var(--primary); color:var(--primary); }

/* CHECKBOX GRID */
.cbgrid { display:grid; grid-template-columns:repeat(auto-fill,minmax(195px,1fr)); gap:10px; }
.ci { display:flex; align-items:center; gap:10px; padding:10px 13px; background:rgba(255,255,255,0.04); border:1px solid rgba(255,255,255,0.08); border-radius:10px; cursor:pointer; transition:all .2s; font-size:13px; color:var(--text-muted); user-select:none; }
.ci:hover { background:rgba(0,212,255,0.07); border-color:rgba(0,212,255,0.3); color:var(--text); }
.ci.on { background:rgba(0,255,136,0.08); border-color:rgba(0,255,136,0.4); color:var(--green); }
.ci .cbox { width:18px; height:18px; border-radius:5px; border:2px solid currentColor; display:flex; align-items:center; justify-content:center; flex-shrink:0; font-size:10px; font-weight:800; }
.fdiv { height:1px; background:linear-gradient(90deg,transparent,rgba(0,212,255,0.28),transparent); margin:32px 0; }

/* SUBMIT */
.submit-wrap { text-align:center; margin-top:34px; }
.btn-submit { display:inline-flex; align-items:center; gap:12px; padding:18px 52px; background:linear-gradient(135deg,var(--primary) 0%,var(--accent) 50%,var(--purple) 100%); color:#fff; border:none; border-radius:50px; cursor:pointer; font-family:'Rajdhani',sans-serif; font-weight:900; font-size:22px; box-shadow:0 8px 30px rgba(255,107,0,0.45); transition:all .3s; position:relative; overflow:hidden; animation:btnPulse 2.5s ease-in-out infinite; }
@keyframes btnPulse { 0%,100%{box-shadow:0 8px 30px rgba(255,107,0,0.45)} 50%{box-shadow:0 14px 50px rgba(255,107,0,0.7),0 0 80px rgba(255,0,128,0.3);transform:translateY(-2px)} }
.btn-submit::before { content:''; position:absolute; top:-50%; left:-60%; width:35%; height:200%; background:rgba(255,255,255,0.18); transform:skewX(-22deg); animation:shimmer 3.5s ease-in-out infinite; }
@keyframes shimmer { 0%{left:-60%} 55%{left:120%} 100%{left:120%} }
.btn-submit:hover { transform:translateY(-4px) scale(1.04); }
.btn-submit:disabled { opacity:0.7; cursor:not-allowed; animation:none; transform:none; }
.submit-note { margin-top:14px; font-size:13px; color:var(--text-muted); line-height:1.7; }
.submit-note a { color:var(--secondary); }

/* REVIEW CARDS */
.rv-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; }
.rv-card { border-radius:14px; padding:15px; box-sizing:border-box; }
.rv-g { background:rgba(255,255,255,0.06); border:1px solid rgba(251,188,5,0.25); }
.rv-t { background:rgba(255,255,255,0.06); border:1px solid rgba(0,182,122,0.25); }
.rv-top { display:flex; align-items:center; gap:9px; margin-bottom:10px; }
.rv-av { width:34px; height:34px; border-radius:50%; display:flex; align-items:center; justify-content:center; font-family:'Rajdhani',sans-serif; font-weight:700; font-size:14px; color:#fff; flex-shrink:0; }
.rv-name { font-family:'Rajdhani',sans-serif; font-weight:700; font-size:13px; color:#fff; margin-bottom:2px; }
.rv-stars { font-size:12px; }
.rv-stars.g { color:#FBBC05; }
.rv-stars.t { color:#00B67A; }
.rv-text { font-size:12px; color:rgba(255,255,255,0.6); line-height:1.65; }

/* SUCCESS MODAL */
.smodal { display:none; position:fixed; inset:0; background:rgba(0,0,0,0.88); backdrop-filter:blur(12px); z-index:9999; align-items:center; justify-content:center; padding:20px; }
.smodal.show { display:flex; }
.sbox { background:linear-gradient(145deg,#111130,#1A1050); border:2px solid var(--green); border-radius:26px; padding:44px 38px; text-align:center; max-width:520px; width:100%; box-shadow:0 0 70px rgba(0,255,136,0.25); animation:popIn .4s cubic-bezier(.175,.885,.32,1.275) both; }
@keyframes popIn { from{opacity:0;transform:scale(.65)} to{opacity:1;transform:scale(1)} }
.sbox .micon { font-size:64px; margin-bottom:14px; animation:bounce .9s ease infinite alternate; }
@keyframes bounce { from{transform:translateY(0)} to{transform:translateY(-10px)} }
.sbox h2 { font-family:'Rajdhani',sans-serif; font-size:30px; font-weight:900; color:var(--green); margin-bottom:8px; }
.sbox .msg-ok { font-size:15px; color:rgba(255,255,255,0.75); line-height:1.75; margin-bottom:20px; }
.pay-info-box { background:rgba(0,255,136,0.07); border:1px solid rgba(0,255,136,0.25); border-radius:16px; padding:18px 20px; margin-bottom:22px; text-align:left; }
.pay-info-box h4 { font-family:'Rajdhani',sans-serif; font-size:15px; font-weight:700; color:#fff; margin-bottom:10px; }
.pay-info-box ul { list-style:none; padding:0; margin:0; }
.pay-info-box ul li { font-size:13px; color:rgba(255,255,255,0.65); padding:4px 0; }
.btn-paynow { display:inline-flex; align-items:center; gap:10px; padding:16px 36px; background:linear-gradient(135deg,#FF6B00,#FF0080,#7C3AED); color:#fff; border-radius:40px; text-decoration:none; font-family:'Rajdhani',sans-serif; font-weight:800; font-size:19px; box-shadow:0 8px 30px rgba(255,107,0,0.4); transition:all .3s; animation:btnPulse 2s ease-in-out infinite; }
.btn-paynow:hover { transform:scale(1.04); }
.close-m { display:block; margin-top:14px; font-size:13px; color:var(--text-muted); cursor:pointer; text-decoration:underline; }

/* RESPONSIVE */
@media(max-width:768px) {
    .demo-card { padding:28px 18px; }
    .fg2 { grid-template-columns:1fr; }
    .col-full { grid-column:1; }
    .cbgrid { grid-template-columns:1fr 1fr; }
    .step-line { width:28px; }
    .btn-submit { font-size:17px; padding:15px 28px; }
    .rv-grid { grid-template-columns:1fr 1fr; }
    .phone-row select { flex:0 0 130px; width:130px; font-size:12px; padding:11px 6px; }
}
/* SERVING BAR */
.serving-bar {
    position: relative;
    z-index: 10;
    margin-top: 70px;
    width: 100%;
    text-align: center;
    padding: 13px 20px;
    font-family: 'Rajdhani', sans-serif;
    font-size: 15px;
    font-weight: 700;
    color: rgba(255,255,255,0.85);
    letter-spacing: 0.5px;
    background: linear-gradient(90deg,
        transparent 0%,
        rgba(255,107,0,0.08) 20%,
        rgba(0,212,255,0.08) 50%,
        rgba(124,58,237,0.08) 80%,
        transparent 100%);
    border-top: 1px solid rgba(255,107,0,0.25);
    border-bottom: 1px solid rgba(0,212,255,0.25);
    overflow: hidden;
}

/* animated rainbow underline */
.serving-bar::after {
    content: '';
    position: absolute;
    bottom: 0; left: 0; right: 0;
    height: 2px;
    background: linear-gradient(90deg,
        var(--primary), var(--secondary), var(--accent),
        var(--green), var(--purple), var(--primary));
    background-size: 300% 100%;
    animation: rainbow 3s linear infinite;
}

.sb-num {
    font-size: 20px;
    font-weight: 900;
    background: linear-gradient(90deg, var(--primary), var(--accent), var(--secondary));
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    margin: 0 2px;
}

.sb-flags {
    display: inline-block;
    margin: 0 10px;
    font-size: 16px;
    letter-spacing: 3px;
    animation: flagsScroll 3s ease-in-out infinite alternate;
}

@keyframes flagsScroll {
    0%   { opacity: 0.7; transform: translateX(-3px); }
    100% { opacity: 1;   transform: translateX(3px);  }
}

.sb-dots {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    margin: 0 8px;
    vertical-align: middle;
}

.sb-dots span {
    width: 5px;
    height: 5px;
    border-radius: 50%;
    display: inline-block;
    animation: dotPop 1.2s ease-in-out infinite;
}

.sb-dots span:nth-child(1) { background: var(--primary);   animation-delay: 0s;    }
.sb-dots span:nth-child(2) { background: var(--secondary); animation-delay: 0.2s;  }
.sb-dots span:nth-child(3) { background: var(--green);     animation-delay: 0.4s;  }
.pricing-banner-section {
    padding: 30px 20px;
    background: rgba(0,0,0,0.2);
    border-bottom: 1px solid rgba(255,255,255,0.1);
}

.pricing-banner-inner {
    max-width: 1200px;
    margin: 0 auto;
}

.pricing-banner-row {
    display: flex;
    align-items: center;
    gap: 15px;
    margin-bottom: 15px;
    flex-wrap: nowrap; /* Prevents jumping to next line */
}

.pricing-label-text {
    font-family: 'Rajdhani', sans-serif;
    font-weight: 700;
    font-size: 16px;
    color: #fff;
    white-space: nowrap;
}

.pricing-single-line {
    display: flex;
    align-items: center;
    gap: 8px;
    color: #fff;
    font-family: 'Rajdhani', sans-serif;
    font-weight: 600;
    font-size: 18px;
    flex-wrap: wrap; /* Allows wrapping only if screen is very small */
}

.p-item {
    padding: 4px 10px;
    border-radius: 6px;
    white-space: nowrap;
}

/* Matching the colors from your screenshot */
.p-rupee { color: #FF6B00; }
.p-dollar { color: #00E676; }
.p-euro { color: #2196F3; }
.p-pound { color: #BA68C8; }
.p-riyal { color: #00BCD4; }

.pricing-banner-icon { font-size: 24px; }

@media (max-width: 768px) {
    .pricing-banner-row {
        flex-direction: column;
        align-items: flex-start;
    }
}

@keyframes dotPop {
    0%, 100% { transform: scale(1);
@media(max-width:500px) { .rv-grid { grid-template-columns:1fr; } }
@media(max-width:480px) { .phone-row select { flex:0 0 100px !important; width:100px !important; font-size:11px !important; padding:10px 4px !important; } }
@media(max-width:440px) { .cbgrid { grid-template-columns:1fr; } }

</style>
        <div class="serving-bar">
    🌍 Services in <span class="sb-num">200+</span> Countries
    <span class="sb-dots">
        <span></span><span></span><span></span>
    </span>
    <span class="sb-flags">🇮🇳 🇺🇸 🇬🇧 🇦🇪 🇸🇬 🇦🇺 🇸🇦 🇶🇦 🇩🇪 🇫🇷 🇨🇦 🇧🇷 🇯🇵 🇿🇦 🇳🇬</span>
</div>
    </div>

    <!-- REVIEWS -->
    <div style="max-width:900px;margin:0 auto 40px;padding:0 20px;position:relative;z-index:1;">
        <div style="text-align:center;margin-bottom:20px;">
            <div style="font-family:'Rajdhani',sans-serif;font-weight:700;font-size:20px;color:#fff;margin-bottom:10px;">⭐ What Our Customers Say</div>
            <div style="display:flex;justify-content:center;gap:10px;flex-wrap:wrap;">
                <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.07);border:1px solid rgba(251,188,5,0.25);border-radius:20px;padding:5px 14px;">
                    <svg width="14" height="14" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
                    <span style="color:#FBBC05;font-size:12px;">★★★★★</span>
                    <span style="color:#ccc;font-size:12px;">4.9 · Google 200+ Reviews</span>
                </div>
                <div style="display:inline-flex;align-items:center;gap:6px;background:rgba(255,255,255,0.07);border:1px solid rgba(0,182,122,0.25);border-radius:20px;padding:5px 14px;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none"><rect width="24" height="24" rx="3" fill="#00B67A"/><path d="M12 4l2.09 6.26H20l-5.27 3.84 2.02 6.23L12 16.27l-4.75 4.06 2.02-6.23L4 10.26h5.91L12 4z" fill="white"/></svg>
                    <span style="color:#00B67A;font-size:12px;">★★★★★</span>
                    <span style="color:#ccc;font-size:12px;">4.8 · Trustpilot 300+ Reviews</span>
                </div>
            </div>
        </div>
    </div><!-- /reviews -->
    </div>
</div>

    <!-- FORM -->
        <div class="demo-card">

            <!-- Personal Info -->
            <div class="fst"><div class="fst-ico ico-o">👤</div><div class="fst-txt"><h3>Personal Information</h3><p>We'll use this to create your demo account and send login credentials</p></div></div>
            <div class="fg2">
                <div class="fw"><label>Full Name <span class="req">*</span></label><input type="text" id="fname" placeholder="e.g. Rajesh Kumar"></div>
                <div class="fw"><label>Email Address <span class="req">*</span></label><input type="email" id="email" placeholder="rajesh@yourcompany.com"></div>
                <div class="fg2" style="margin-top: 18px;">
    <div class="fw">
        <label>Create Password <span class="req">*</span></label>
        <input type="password" id="pw" name="password" placeholder="Min. 8 characters" minlength="8" required>
    </div>
    <div class="fw">
        <label>Confirm Password <span class="req">*</span></label>
        <input type="password" id="cpw" name="confirm_password" placeholder="Repeat password" required>
    </div>
</div>
                <div class="fw" style="grid-column:1/-1;">
                    <label>WhatsApp / Mobile <span class="req">*</span></label>
                    <div class="phone-row">
                        <select id="ccode">
                            <option value="+91">🇮🇳 +91</option><option value="+1">🇺🇸 +1</option>
                            <option value="+44">🇬🇧 +44</option><option value="+971">🇦🇪 +971</option>
                            <option value="+65">🇸🇬 +65</option><option value="+61">🇦🇺 +61</option>
                            <option value="+60">🇲🇾 +60</option><option value="+966">🇸🇦 +966</option>
                            <option value="+974">🇶🇦 +974</option><option value="+965">🇰🇼 +965</option>
                            <option value="+973">🇧🇭 +973</option><option value="+968">🇴🇲 +968</option>
                            <option value="+49">🇩🇪 +49</option><option value="+33">🇫🇷 +33</option>
                            <option value="+86">🇨🇳 +86</option><option value="+81">🇯🇵 +81</option>
                            <option value="+92">🇵🇰 +92</option><option value="+880">🇧🇩 +880</option>
                            <option value="+94">🇱🇰 +94</option><option value="+977">🇳🇵 +977</option>
                            <option value="+55">🇧🇷 +55</option><option value="+27">🇿🇦 +27</option>
                            <option value="+234">🇳🇬 +234</option><option value="+254">🇰🇪 +254</option>
                            <option value="+66">🇹🇭 +66</option><option value="+62">🇮🇩 +62</option>
                        </select>
                        <input type="tel" id="mobile" placeholder="98765 43210">
                    </div>
                </div>
                <div class="fw"><label>Country <span class="req">*</span></label><input type="text" id="country" placeholder="Enter your country" autocomplete="country-name"></div>
                <div class="fw"><label>Company / Business Name</label><input type="text" id="company" placeholder="Your Company Pvt. Ltd."></div>
                <div class="fw"><label>Company Located At</label><input type="text" id="company_location" placeholder="City, State, Country"></div>
            </div>

            <!-- Services -->
            <div class="fst"><div class="fst-ico ico-g">🚀</div><div class="fst-txt"><h3>Services Required</h3><p>Select your primary service — we'll demo this first</p></div></div>
            <div class="fg2">
                <div class="fw col-full">
                    <label>Primary Service for Demo <span class="req">*</span></label>
                    <select id="primary_svc">
                        <option value="">— Choose Primary Service —</option>
                        <optgroup label="📱 Bulk SMS">
                            <option>Promo / Marketing</option>
                            <option>Tran / OTP / Utility</option>
                            <option> Gaming / Casino</option>
                            <option>Two Way SMS</option>
                        </optgroup>
                        <optgroup label="💬 WhatsApp">
                            <option>Bulk WhatsApp</option>
                            <option>WhatsApp Business API (META)</option>
                        </optgroup>
                            <option>🌐 RCS Messaging</option>
                           <option>🎙️ Voice Broadcasting</option>
                           <option>🎙️ Voice QOS</option>
                           <option>📞 SIP Trunks / TDM</option>
                           <option>📱 DID Numbers</option>
                           <option>📟 Toll-Free Numbers</option>
                           <option>☁️ Cloud PBX</option>
                           <option>💼 MS Teams Routing</option>
                           <option>🏷️ White-Label Reseller</option>
                           <option>🔌 Custom API / Integration</option>
                        <optgroup label="📱 AI Automation">
                            <option>⚙️ AI Agents</option>
                            <option>🤖 AI Chatbots</option>
                            <option>🚀 AI Tools</option>
                        </optgroup>
                    </select>
                </div>
            </div>

            <!-- Also Interested In — INSIDE .demo-card -->
            <div style="margin-top:18px;">
                <div class="fw"><label>Also Interested In</label></div>
                <div class="cbgrid" style="margin-top:12px;" id="cbGrid">
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>📢 Promo / Marketing SMS</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🔐 Tran / OTP / Utility SMS</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🎮 Gaming / Casino SMS</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🎰 Two Way SMS</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>💬 Bulk WhatsApp</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🏢 WhatsApp Business API(META)</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🌐 RCS Messaging</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🎙️ Voice Broadcasting</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🎙️Voice QOS</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>📞 SIP Trunks /TDM</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>📱 DID Numbers</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>📟 Toll-Free Numbers</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>☁️ Cloud PBX</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>💼 MS Teams Routing</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🏷️ White-Label Reseller</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🔌 Custom API / Integration</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>⚙️AI Agents</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🤖 AI Chatbots</div>
                    <div class="ci" onclick="tick(this)"><div class="cbox"></div>🚀️AI Tools</div>
                    
                    
                </div>
            </div>

            <div class="fdiv"></div>

            <!-- Volume -->
            <div class="fst"><div class="fst-ico ico-p">📊</div><div class="fst-txt"><h3>Volume</h3><p>Helps us configure the right routes and pricing for your demo</p></div></div>
            <div class="fg2">
                <div class="fw col-full">
                    <label>Estimated SMS / WhatsApp / Voice Volume</label>
                    <div class="vchips" id="vc1">
                        <div class="vchip" onclick="chip(this,'vc1')">Under 10K</div>
                        <div class="vchip" onclick="chip(this,'vc1')">10K – 100K</div>
                        <div class="vchip" onclick="chip(this,'vc1')">0.1M – 1M</div>
                        <div class="vchip" onclick="chip(this,'vc1')">1M – 10M</div>
                        <div class="vchip" onclick="chip(this,'vc1')">10M+</div>
                    </div>
                </div>
            </div>
            <div class="fg2" style="margin-top:18px;">
                <div class="fw">
                    <label>Sending Country <span class="req">*</span></label>
                    <select id="sendingCountry">
                        <option value="">— Select Sending Country —</option>
                        <option>India</option><option>United States</option><option>United Kingdom</option><option>United Arab Emirates</option><option>Saudi Arabia</option><option>Qatar</option><option>Kuwait</option><option>Bahrain</option><option>Oman</option><option>Singapore</option><option>Malaysia</option><option>Australia</option><option>Germany</option><option>France</option><option>Canada</option><option>Indonesia</option><option>Thailand</option><option>Bangladesh</option><option>Sri Lanka</option><option>Nepal</option><option>Pakistan</option><option>Nigeria</option><option>Kenya</option><option>South Africa</option><option>Other</option>
                    </select>
                </div>
                <div class="fw">
                    <label>Receiving Country <span class="req">*</span></label>
                    <select id="receivingCountry">
                        <option value="">— Select Receiving Country —</option>
                        <option>India</option><option>United States</option><option>United Kingdom</option><option>United Arab Emirates</option><option>Saudi Arabia</option><option>Qatar</option><option>Kuwait</option><option>Bahrain</option><option>Oman</option><option>Singapore</option><option>Malaysia</option><option>Australia</option><option>Germany</option><option>France</option><option>Canada</option><option>Indonesia</option><option>Thailand</option><option>Bangladesh</option><option>Sri Lanka</option><option>Nepal</option><option>Pakistan</option><option>Nigeria</option><option>Kenya</option><option>South Africa</option><option>Other</option>
                    </select>
                </div>
            </div>

    <!-- T&C Checkbox -->
    
    <div id="confirmBox" style="background:rgba(255,255,255,0.05); border:1px solid rgba(255,255,255,0.12); border-radius:14px; padding:20px; margin:0 0 16px;">
    <p style="color:#e9edef; font-size:15px; font-weight:600; margin:0 0 6px;">
        By submitting your details, you agree to our
        Terms of Service & Privacy Policy.
    </p>
    <p style="color:#a0aec0; font-size:13px; margin:0 0 16px;">
        Do you confirm and agree to proceed?
    </p>
    <div style="display:flex; gap:12px;">
        <button onclick="handleAnswer('yes')" id="btnYes"
            style="flex:1; padding:12px; border-radius:10px; border:2px solid var(--green); background:transparent; color:var(--green); font-size:15px; font-weight:700; cursor:pointer; transition:all 0.2s;"
            onmouseover="this.style.background='var(--green)';this.style.color='#000';"
            onmouseout="this.style.background='transparent';this.style.color='var(--green)';">
            ✅ Yes<br>I Agree
        </button>
        <button onclick="handleAnswer('no')" id="btnNo"
            style="flex:1; padding:12px; border-radius:10px; border:2px solid #ff4d4d; background:transparent; color:#ff4d4d; font-size:15px; font-weight:700; cursor:pointer; transition:all 0.2s;"
            onmouseover="this.style.background='#ff4d4d';this.style.color='#fff';"
            onmouseout="this.style.background='transparent';this.style.color='#ff4d4d';">
            ❌ No<br>Cancel
        </button>
    </div>
    To get instant demo pay $5 to activate your demo account this $5 will be fully created to your Main account Balance
</div>

</div><!-- /submit-wrap -->

</div><!-- /demo-card -->
</div><!-- /demo-card-wrap -->
</div><!-- /demo-wrap -->

<!-- STICKY FOOTER BUTTON -->
<div class="sticky-footer-btn">
    <button class="btn-sticky-submit" onclick="handleSubmit()">
        ⚡ Submit your Requirement
    </button>
</div>

<script>
function tick(el) {
    el.classList.toggle('on');
    el.querySelector('.cbox').textContent = el.classList.contains('on') ? '✓' : '';
}

function chip(el, gid) {
    document.getElementById(gid).querySelectorAll('.vchip').forEach(function(c){ c.classList.remove('sel'); });
    el.classList.add('sel');
}

function validateForm() {
    var required = ['fname','email','mobile','country','primary_svc'];
    var ok = true;

    required.forEach(function(id) {
        var el = document.getElementById(id);
        if (el && !el.value.trim()) {
            el.style.borderColor = 'var(--accent)';
            el.style.boxShadow = '0 0 0 3px rgba(255,0,128,0.18)';
            ok = false;
            setTimeout(function(){ el.style.borderColor=''; el.style.boxShadow=''; }, 3500);
        }
    });

    var em = document.getElementById('email').value;
    if (em && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) {
        document.getElementById('email').style.borderColor = 'var(--accent)';
        ok = false;
    }

    // T&C checkbox validation
    var tc = document.getElementById('agreeTC');
    if (tc && !tc.checked) {
        tc.style.outline = '2px solid var(--accent)';
        setTimeout(function(){ tc.style.outline = ''; }, 3500);
        alert('⚠️ Please agree to our Terms & Conditions before submitting.');
        return false;
    }

    return ok;
}

function handleSubmit() {
    if (!validateForm()) {
        window.scrollTo({ top:0, behavior:'smooth' });
        return;
    }

    var extraServices = [];
    document.querySelectorAll('#cbGrid .ci.on').forEach(function(el){
        extraServices.push(el.textContent.trim());
    });
    var volEl = document.querySelector('#vc1 .vchip.sel');
    var volume = volEl ? volEl.textContent.trim() : '';

    var btn = document.getElementById('submitBtn');
    btn.disabled = true;
    btn.textContent = '⏳ Saving your details...';

    var data = new FormData();
    data.append('full_name',         document.getElementById('fname').value);
    data.append('email',             document.getElementById('email').value);
    data.append('mobile',            document.getElementById('ccode').value + ' ' + document.getElementById('mobile').value);
    data.append('country',           document.getElementById('country').value);
    data.append('company',           document.getElementById('company').value);
    data.append('company_location',  document.getElementById('company_location').value);
    data.append('primary_service',   document.getElementById('primary_svc').value);
    data.append('sending_country',   document.getElementById('sendingCountry').value);
    data.append('receiving_country', document.getElementById('receivingCountry').value);
    data.append('volume',            volume);
    data.append('extra_services',    extraServices.join(', '));

    fetch('save_demo.php', { method:'POST', body:data })
    .then(function(r){ return r.json(); })
    .then(function(res){
        btn.disabled = false;
        btn.innerHTML = '⚡ Submit My Details';
        window.location.href = 'https://razorpay.me/@pusapatibulksmsservices';
    })
    .catch(function(){
        btn.disabled = false;
        btn.innerHTML = '⚡ Submit My Details';
        window.location.href = 'https://razorpay.me/@pusapatibulksmsservices';
    });
}
</script>
