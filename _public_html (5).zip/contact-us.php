<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us | BulkSMSIndia</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #050a12;
            --card-bg: #0d141f;
            --accent-red: #d11a1a;
            --text-main: #ffffff;
            --text-muted: #a0a6b1;
            --border: rgba(255, 255, 255, 0.1);
        }
        body { margin: 0; padding: 0; font-family: 'Inter', sans-serif; background-color: var(--bg-dark); color: var(--text-main); }
        .container { max-width: 1200px; margin: 80px auto; padding: 0 20px; }
        
        .header-section { text-align: center; margin-bottom: 60px; }
        .header-section h1 { font-size: 3rem; font-weight: 800; margin-bottom: 10px; }
        .header-section span { color: var(--accent-red); }

        .contact-grid { display: grid; grid-template-columns: 1fr 1.5fr; gap: 40px; }

        /* Left side cards */
        .info-card { background: var(--card-bg); padding: 30px; border-radius: 20px; border: 1px solid var(--border); margin-bottom: 20px; }
        .info-card h3 { color: var(--accent-red); margin-top: 0; margin-bottom: 15px; font-size: 1.2rem; }
        .info-card p { color: var(--text-muted); line-height: 1.6; margin: 5px 0; }
        .phone-link { font-size: 1.5rem; font-weight: 700; color: white; text-decoration: none; display: block; margin-top: 10px; }

        /* Right side form */
        .form-box { background: var(--card-bg); padding: 40px; border-radius: 20px; border: 1px solid var(--border); }
        .form-group { margin-bottom: 20px; }
        .form-group label { display: block; margin-bottom: 8px; font-size: 0.9rem; color: var(--text-muted); }
        .form-group input, .form-group textarea { width: 100%; padding: 12px; background: #161e2b; border: 1px solid var(--border); border-radius: 8px; color: white; box-sizing: border-box; }
        .btn-submit { background: var(--accent-red); color: white; border: none; padding: 15px 40px; border-radius: 50px; font-weight: 700; width: 100%; cursor: pointer; transition: 0.3s; }
        .btn-submit:hover { transform: translateY(-3px); box-shadow: 0 10px 20px rgba(209, 26, 26, 0.3); }

        .office-img { width: 100%; height: 250px; border-radius: 15px; object-fit: cover; margin-top: 20px; border: 1px solid var(--border); }

        @media (max-width: 992px) { .contact-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="container">
        <div class="header-section">
            <h1>Get In <span>Touch</span></h1>
            <p style="color: var(--text-muted)">Have questions? Our team is ready to help you scale your business.</p>
        </div>

        <div class="contact-grid">
            <div class="info-side">
                <div class="info-card">
                    <h3>Corporate Headquarters</h3>
                    <h3>info@bulksmsindia.com</h3>
                    <p>Flat No.204, 2nd Floor, Prashanti Ram Towers,</p>
                    <p>Ameerpet, Hyderabad, Telangana – 500073</p>
                    <img src="https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=600&q=80" alt="Hyderabad Office" class="office-img">
                </div>
                
                <div class="info-card">
                    <h3>Direct Support Line</h3>
                    <p>Mon – Sat, 9am – 7pm IST</p>
                    <a href="tel:+919000937601" class="phone-link">+91 90009 37601</a>
                </div>
            </div>

            <div class="form-box">
                <form action="send_mail.php" method="POST">
                    <div class="form-group">
                        <label>Full Name</label>
                        <input type="text" placeholder="Enter your name" required>
                    </div>
                    <div class="form-group">
                        <label>Email ID</label>
                        <input type="email" placeholder="example@business.com" required>
                    </div>
                    <div class="form-group">
                        <label>Message</label>
                        <textarea rows="5" placeholder="How can we help you?"></textarea>
                    </div>
                    <button type="submit" class="btn-submit">Send Inquiry</button>
                </form>
            </div>
        </div>
    </div>
<?php include 'includes/footer.php'; ?>
</body>
</html>