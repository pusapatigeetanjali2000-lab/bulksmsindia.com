<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Custom API Integration | Seamless Connectivity | BulkSMSIndia";
?>

<style>
    :root {
        --api-navy: #0D2B8E;
        --api-red: #DB1212;
        --api-yellow: #FFD700;
        --api-glass: rgba(255, 255, 255, 0.03);
    }

    .api-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.92), rgba(5, 10, 21, 0.96)), 
                    url('https://images.unsplash.com/photo-1558494949-ef010cbdcc51?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
        color: #fff;
    }

    .hero-api {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .dev-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 8px 20px;
        background: rgba(255, 215, 0, 0.1);
        border: 1px solid var(--api-yellow);
        border-radius: 50px;
        color: var(--api-yellow);
        font-size: 0.75rem;
        font-weight: 700;
        margin-bottom: 25px;
        letter-spacing: 1.5px;
        text-transform: uppercase;
    }

    .api-card {
        background: var(--api-glass);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s ease;
        position: relative;
        overflow: hidden;
    }

    .api-card:hover {
        border-color: var(--api-red);
        background: rgba(13, 43, 142, 0.05);
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(219, 18, 18, 0.1);
    }

    .code-accent {
        font-family: 'Courier New', monospace;
        color: var(--api-yellow);
        font-size: 0.85rem;
        background: rgba(0,0,0,0.3);
        padding: 4px 10px;
        border-radius: 6px;
    }

    .step-hex {
        width: 50px;
        height: 50px;
        background: var(--api-red);
        clip-path: polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%);
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        margin-bottom: 20px;
    }
</style>

<div class="api-bg">
    <section class="hero-api">
        <div class="dev-badge">
            <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M9.4 16.6L4.8 12l4.6-4.6L8 6l-6 6 6 6 1.4-1.4zm5.2 0l4.6-4.6-4.6-4.6L16 6l6 6-6 6-1.4-1.4z"/></svg>
            Developer First Infrastructure
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1.1;">
            Plug & Play <br><span style="color: var(--api-red);">Custom Integrations.</span>
        </h1>
        <p style="max-width: 850px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Connect your existing software, CRM, or app to our enterprise messaging engine. 
            Our RESTful APIs are designed for speed, security, and effortless scaling.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="api-card">
                <h3 style="color: var(--api-yellow); margin-bottom: 15px;">🚀 Low Latency</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Deliver thousands of messages per second with our optimized global routing protocols.</p>
                <div style="margin-top:20px"><span class="code-accent">HTTP/2 Push</span></div>
            </div>
            <div class="api-card">
                <h3 style="color: var(--api-yellow); margin-bottom: 15px;">🛡️ Secure Auth</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Industry-standard OAuth2 and API Key encryption ensures your data remains yours alone.</p>
                <div style="margin-top:20px"><span class="code-accent">AES-256 Encrypted</span></div>
            </div>
            <div class="api-card">
                <h3 style="color: var(--api-yellow); margin-bottom: 15px;">📈 Real-time Webhooks</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Get instant delivery reports and inbound message alerts sent directly to your server.</p>
                <div style="margin-top:20px"><span class="code-accent">JSON Callbacks</span></div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80" alt="API Connections" style="width: 100%; border-radius: 40px; border: 1px solid var(--api-navy); box-shadow: 0 0 50px rgba(13, 43, 142, 0.4);">
                <div style="position: absolute; top: 30px; left: -20px; background: var(--api-red); padding: 15px 25px; border-radius: 12px; box-shadow: 0 10px 30px rgba(219, 18, 18, 0.3);">
                    <span style="font-weight: 800; font-size: 0.8rem;">API v2.0 ACTIVE</span>
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Powering Modern <br><span style="color: var(--api-red);">Industries</span></h2>
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <div style="padding: 20px; background: var(--api-glass); border-radius: 15px; border-left: 4px solid var(--api-yellow);">
                        <h4 style="color: var(--api-yellow);">Banking & Finance</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Instant OTP delivery and transaction alerts integrated via secure SDKs.</p>
                    </div>
                    <div style="padding: 20px; background: var(--api-glass); border-radius: 15px; border-left: 4px solid var(--api-yellow);">
                        <h4 style="color: var(--api-yellow);">Logistics & E-commerce</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Automated tracking updates and delivery notifications triggered by order status changes.</p>
                    </div>
                    <div style="padding: 20px; background: var(--api-glass); border-radius: 15px; border-left: 4px solid var(--api-yellow);">
                        <h4 style="color: var(--api-yellow);">Healthcare Systems</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Seamless appointment reminders and lab result notifications synced with HMS software.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">4 Steps to <span>Integrate</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 30px;">
            <div class="api-card">
                <div class="step-hex">01</div>
                <h4>Generate Key</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Create your unique API credentials in your dashboard settings.</p>
            </div>
            <div class="api-card">
                <div class="step-hex">02</div>
                <h4>Read Docs</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Explore our comprehensive documentation with multi-language code snippets.</p>
            </div>
            <div class="api-card">
                <div class="step-hex">03</div>
                <h4>Test Sandbox</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Use our sandbox environment to simulate requests without using live credits.</p>
            </div>
            <div class="api-card">
                <div class="step-hex">04</div>
                <h4>Go Live</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Switch to production and start sending messages at scale.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(13, 43, 142, 0.2), transparent); border: 1px solid var(--api-yellow);">
            <h2 style="margin-bottom: 20px;">Built by developers, for developers.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Ready to connect? Start your integration in less than 5 minutes.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="docs.php" class="btn-nav-primary" style="background: var(--api-yellow); color: #000; border: none;">View API Docs</a>
                <a href="signup.php" class="btn-nav-ghost">Get API Key</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>