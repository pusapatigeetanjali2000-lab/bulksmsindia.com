<?php 
    $page_title = "BulkSMSIndia | #1 AI-Powered Bulk SMS, WhatsApp & Voice Platform";
    include('includes/header.php'); 
?>
<style>
/* CSS Reset & Roots are in header.php */

.section-padding { padding: 100px 0; }
.bg-darker { background: #030812; }
.text-gradient-red { background: linear-gradient(90deg, var(--red), #ff5e5e); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }

/* Hero Styling */
.hero-section { 
    padding: 200px 0 120px; 
    text-align: center; 
    position: relative; 
    overflow: hidden; 
    background: radial-gradient(circle at center, #0d2b8e33 0%, transparent 70%);
}
.hero-glow { position: absolute; top: 0; left: 50%; transform: translateX(-50%); width: 100%; height: 100%; background: url('https://www.transparenttextures.com/patterns/carbon-fibre.png'); opacity: 0.1; }
.badge-ai { display: inline-flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.05); padding: 8px 20px; border-radius: 50px; border: 1px solid var(--border-base); margin-bottom: 30px; font-size: 0.85rem; font-weight: 600; color: var(--yellow); }
.pulse { width: 8px; height: 8px; background: #22c55e; border-radius: 50%; animation: pulse 2s infinite; }
@keyframes pulse { 0% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0.7); } 70% { box-shadow: 0 0 0 10px rgba(34, 197, 94, 0); } 100% { box-shadow: 0 0 0 0 rgba(34, 197, 94, 0); } }

.hero-content h1 { font-size: 4.5rem; line-height: 1; margin-bottom: 30px; font-weight: 900; }
.hero-content p { max-width: 800px; margin: 0 auto 40px; color: var(--text-300); font-size: 1.2rem; }

.hero-btns { display: flex; justify-content: center; gap: 20px; margin-bottom: 60px; }
.btn-main { background: var(--red); color: #fff; padding: 18px 40px; border-radius: 12px; font-weight: 800; box-shadow: 0 10px 30px var(--red-glow); transition: 0.3s; }
.btn-main:hover { transform: translateY(-3px); background: #f00; }
.btn-outline { border: 2px solid var(--border-base); padding: 18px 40px; border-radius: 12px; font-weight: 800; transition: 0.3s; }
.btn-outline:hover { background: rgba(255,255,255,0.05); }

.hero-stats-bar { display: inline-flex; gap: 50px; padding: 20px 60px; background: rgba(13, 43, 142, 0.2); border-radius: 100px; border: 1px solid var(--border-base); backdrop-filter: blur(10px); }
.h-stat strong { display: block; font-size: 1.8rem; color: #fff; }
.h-stat span { font-size: 0.75rem; text-transform: uppercase; color: var(--text-500); letter-spacing: 1px; }

/* Status Strip */
.status-strip { display: flex; justify-content: center; gap: 40px; padding: 15px; background: #000; border-bottom: 1px solid var(--border-base); font-size: 0.85rem; }
.dot-green { width: 8px; height: 8px; background: #22c55e; border-radius: 50%; display: inline-block; margin-right: 8px; }

/* Bento Grid */
.bento-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px; margin-top: 50px; }
.bento-item { background: var(--bg-card); padding: 40px; border-radius: 24px; border: 1px solid var(--border-base); transition: 0.3s; }
.bento-item:hover { border-color: var(--yellow); transform: translateY(-5px); }
.featured-red { background: linear-gradient(145deg, var(--red), #800a0a); border: none; }
.bento-item ul { margin: 20px 0; color: var(--text-300); font-size: 0.9rem; }
.bento-item ul li { margin-bottom: 10px; list-style: "✓ "; padding-left: 10px; }

/* Testimonials */
.testimonial-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 40px; }
.t-card { background: rgba(255,255,255,0.03); padding: 30px; border-radius: 16px; border: 1px solid var(--border-base); }
.t-head { border-left: 4px solid var(--red); padding-left: 15px; margin-bottom: 15px; }
.t-head strong { display: block; color: #fff; }
.t-head span { font-size: 0.75rem; color: var(--text-500); }
.t-stars { color: var(--yellow); margin-top: 15px; letter-spacing: 3px; }

/* AI Models Section */
.ai-box { background: var(--navy); border-radius: 30px; padding: 60px; text-align: center; border: 2px solid var(--border-base); }
.model-flex { display: flex; justify-content: space-around; flex-wrap: wrap; gap: 30px; margin-top: 40px; }
.m-item strong { display: block; font-size: 1.4rem; color: var(--yellow); }
.m-item span { color: var(--text-300); font-size: 0.8rem; }

/* Voice Grid */
.voice-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 20px; margin-top: 40px; }
.v-card { padding: 30px; border-radius: 15px; background: #111e33; border: 1px solid rgba(255,255,255,0.05); }
.v-card h4 { color: var(--yellow); margin-bottom: 10px; }
.v-card p { font-size: 0.85rem; color: var(--text-500); }

@media (max-width: 768px) {
    .hero-content h1 { font-size: 2.8rem; }
    .hero-stats-bar { flex-direction: column; gap: 20px; border-radius: 20px; padding: 30px; }
    .hero-btns { flex-direction: column; }
}/* Center the Service Section Header */
.services-section .section-header {
    text-align: center;
    max-width: 700px; /* Optional: limits width for better readability */
    margin: 0 auto 50px; /* Centers the block and adds bottom spacing */
    display: flex;
    flex-direction: column;
    align-items: center;
}

.services-section .sub-tag {
    display: inline-block; /* Allows margins to work */
    margin-bottom: 15px;
}
/* This centers every section-header globally on the page */
.section-header {
    text-align: center;
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-bottom: 60px; /* Space before the grid/content starts */
}

.section-header .sub-tag {
    display: inline-block;
    padding: 6px 16px;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin-bottom: 15px;
}

.section-header h2 {
    font-size: 2.5rem;
    font-weight: 800;
    line-height: 1.2;
    color: #fff;
}
/* Image Card Styles */
.image-card {
    position: relative;
    overflow: hidden;
    min-height: 320px;
    display: flex;
    align-items: flex-end;
}

.card-img-overlay {
    position: absolute;
    top: 0; left: 0; width: 100%; height: 100%;
    background-size: cover;
    background-position: center;
    filter: brightness(0.4) grayscale(0.5); /* Makes it cinematic */
    transition: 0.5s ease;
    z-index: 1;
}

.image-card:hover .card-img-overlay {
    filter: brightness(0.6) grayscale(0);
    transform: scale(1.1);
}

.card-content {
    position: relative;
    z-index: 2;
    width: 100%;
}

.v-card-modern {
    background: rgba(13, 43, 142, 0.1);
    padding: 40px;
    border-radius: 20px;
    border: 1px solid rgba(255,255,255,0.05);
    text-align: center;
    transition: 0.3s;
}

.v-card-modern:hover {
    background: rgba(13, 43, 142, 0.2);
    border-color: var(--yellow);
}

.v-icon {
    width: 50px;
    height: 50px;
    margin-bottom: 20px;
    filter: drop-shadow(0 0 10px var(--navy-glow));
}

.highlight-border {
    border: 1px solid var(--red);
}

.delivery-badge {
    display: inline-block;
    background: var(--yellow);
    color: #000;
    padding: 5px 12px;
    border-radius: 4px;
    font-size: 0.7rem;
    font-weight: 800;
    margin: 15px 0;
}
</style>
<section class="hero-section">
    <div class="hero-glow"></div>
    <div class="container">
        <div class="hero-content">
            <div class="badge-ai">
                <span class="pulse"></span> 100% AI-Powered Routing Active
            </div>
            <h1>1 AI-Powered <span class="text-gradient-red">BulkSMS</span>, <br>WhatsApp & Voice Platform</h1>
            <p>Reach millions of customers instantly with AI-driven Bulk SMS, WhatsApp, RCS, Voice and intelligent automation — the next-generation CPaaS platform built for enterprise scale.</p>
            
            <div class="hero-btns">
                <a href="signup.php" class="btn-main">Instant Access — Live in 30 Mins</a>
                <a href="pricing.php" class="btn-outline">View Pricing</a>
            </div>

            <div class="hero-stats-bar">
                <div class="h-stat"><strong>1000+</strong><span>AI Tools</span></div>
                <div class="h-stat"><strong>99.9%</strong><span>Uptime</span></div>
                <div class="h-stat"><strong>200+</strong><span>Countries</span></div>
            </div>
        </div>
    </div>
</section>

<div class="status-strip">
    <div class="status-item"><span class="dot-green"></span> AI Agent Active: <strong>12,400 msg/sec</strong></div>
    <div class="status-item"><span class="dot-green"></span> Delivery Rate: <strong>99.98% (Sub-second)</strong></div>
</div>

<section class="social-proof section-padding">
    <div class="container">
        <div class="section-header">
            <h2 style="color: var(--yellow);">Trusted by Millions Worldwide</h2>
            <p>Don’t take our word for it — see what customers say on Google and Trustpilot.</p>
        </div>
        <div class="testimonial-grid">
            <div class="t-card">
                <div class="t-head"><strong>Rahul Mehta</strong><span>CTO, FinTech · Mumbai</span></div>
                <p>“Outstanding AI-powered SMS platform! Our OTP delivery rate jumped to 99.8%.”</p>
                <div class="t-stars">★★★★★</div>
            </div>
            <div class="t-card">
                <div class="t-head" style="border-left-color: var(--yellow);"><strong>Priya Sharma</strong><span>Head of Marketing · USA</span></div>
                <p>“Best WhatsApp API! Our e-commerce read rate went from 60% to 97%.”</p>
                <div class="t-stars">★★★★★</div>
            </div>
            <div class="t-card">
                <div class="t-head" style="border-left-color: var(--red);"><strong>Vivek Kapoor</strong><span>E-commerce Head · Bengaluru</span></div>
                <p>“RCS messaging transformed our campaigns. Rich carousels led to 3x conversions.”</p>
                <div class="t-stars">★★★★★</div>
            </div>
        </div>
    </div>
</section>
<section class="services-section section-padding bg-darker">
    <div class="container">
        <div class="section-header" style="text-align: center; display: flex; flex-direction: column; align-items: center; margin-bottom: 60px;">
            <span class="sub-tag" style="background: rgba(219, 18, 18, 0.1); color: var(--red); border: 1px solid var(--red);">A2P Messaging</span>
            <h2 style="font-size: 3rem; margin-top: 15px;">AI-Powered <span style="color: var(--yellow);">Bulk SMS</span> Services</h2>
        </div>

        <div class="bento-grid">
            <div class="bento-item image-card">
                <div class="card-img-overlay" style="background-image: url('assets/images/sms-marketing-bg.jpg');"></div>
                <div class="card-content">
                    <h3 style="color: var(--yellow);">Promotional SMS</h3>
                    <p>Supercharge your marketing with high-volume blasts delivered via AI-optimized routes.</p>
                    <ul class="mini-list">
                        <li>Custom Sender IDs</li>
                        <li>Peak-time Scheduling</li>
                    </ul>
                    <a href="signup.php" class="text-link">Start Campaign →</a>
                </div>
            </div>

            <div class="bento-item featured-red image-card">
                <div class="card-img-overlay" style="background-image: url('assets/images/otp-security-bg.jpg'); opacity: 0.2;"></div>
                <div class="card-content">
                    <h3 style="color: #fff;">OTP & Transactional</h3>
                    <p>Mission-critical sub-second delivery for OTPs and alerts 24/7 with 99.99% success.</p>
                    <div class="delivery-badge">⚡ Sub-3s Delivery</div>
                    <a href="signup.php" class="btn-small-white">Get API Key</a>
                </div>
            </div>

            <div class="bento-item image-card">
                <div class="card-img-overlay" style="background-image: url('assets/images/gaming-sms-bg.jpg');"></div>
                <div class="card-content">
                    <h3 style="color: var(--yellow);">Gaming & Casino</h3>
                    <p>High-throughput routes for live scores, win/loss alerts, and player onboarding.</p>
                    <a href="signup.php" class="text-link">Request Access →</a>
                </div>
            </div>
        </div>
    </div>
</section>


<section class="ai-models section-padding">
    <div class="container">
        <div class="ai-box">
            <h3>Powered by World's Leading AI Models</h3>
            <div class="model-flex">
                <div class="m-item"><strong>OpenAI</strong><span>GPT-4o · o3</span></div>
                <div class="m-item"><strong>Gemini</strong><span>Gemini 2.0 Ultra</span></div>
                <div class="m-item"><strong>Claude</strong><span>Claude 4 Opus</span></div>
                <div class="m-item"><strong>Grok</strong><span>Grok 3 (xAI)</span></div>
            </div>
        </div>
    </div>
</section>

<section class="voice-section section-padding">
    <div class="container">
        <div class="section-header" style="text-align: center; display: flex; flex-direction: column; align-items: center; margin-bottom: 60px;">
            <span class="sub-tag" style="background: var(--yellow); color: #000;">Voice Solutions</span>
            <h2>Complete Cloud Voice Infrastructure</h2>
        </div>
        
        <div class="voice-grid">
            <div class="v-card-modern">
                <img src="images/tollfree.png" alt="Toll Free" class="v-icon">
                <h4>DID / Toll Free</h4>
                <p>Instant provisioning for 1800 & 1860 lines in 100+ countries.</p>
            </div>
            <div class="v-card-modern">
                <img src="images/voip.jfif" alt="VoIP" class="v-icon">
                <h4>VoIP Services</h4>
                <p>HD voice quality via Tier-1 carriers with unlimited concurrent channels.</p>
            </div>
            <div class="v-card-modern highlight-border">
                <img src="images/voicebroadcast.png" alt="Broadcast" class="v-icon">
                <h4>Voice Broadcasting</h4>
                <p>Automated calls & Voice OTPs with AI Text-to-Speech fallback.</p>
            </div>
            <div class="v-card-modern">
                <img src="images/ivr.png" alt="IVR" class="v-icon">
                <h4>Smart IVR Systems</h4>
                <p>24/7 intelligent menus: "Press 1 for Sales" with CRM integration.</p>
            </div>
        </div>
    </div>
</section>



<?php include('includes/footer.php'); ?>