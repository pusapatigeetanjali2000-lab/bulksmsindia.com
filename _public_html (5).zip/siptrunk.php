<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Enterprise SIP Trunking | Scalable Voice Solutions | BulkSMSIndia";
?>

<style>
    :root {
        --sip-blue: #0D2B8E;
        --sip-red: #DB1212;
        --sip-cyan: #00f2ff;
        --glass-sip: rgba(255, 255, 255, 0.03);
    }

    .sip-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1544197150-b99a580bb7a8?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-sip {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .sip-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 25px;
        background: rgba(0, 242, 255, 0.1);
        border: 1px solid var(--sip-cyan);
        border-radius: 50px;
        color: var(--sip-cyan);
        font-size: 0.8rem;
        font-weight: 700;
        margin-bottom: 25px;
        letter-spacing: 1px;
        backdrop-filter: blur(10px);
    }

    .sip-card {
        background: var(--glass-sip);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    }

    .sip-card:hover {
        border-color: var(--sip-red);
        background: rgba(219, 18, 18, 0.05);
        transform: translateY(-8px);
    }

    .sip-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 60px 4%;
    }

    .tech-spec {
        font-family: 'Courier New', monospace;
        color: var(--sip-cyan);
        background: rgba(0,0,0,0.4);
        padding: 5px 12px;
        border-radius: 5px;
        font-size: 0.8rem;
        margin-top: 10px;
        display: inline-block;
    }
</style>

<div class="sip-bg">
    <section class="hero-sip">
        <div class="sip-badge">
            <svg width="15" height="15" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2L4.5 20.29l.71.71L12 18l6.79 3 .71-.71z"/></svg>
            ELIMINATE LEGACY PRI LINES
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1;">
            Modern Voice <br><span style="color: var(--sip-red);">Unlimited Power.</span>
        </h1>
        <p style="max-width: 850px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Connect your existing IP-PBX to the world via our high-performance SIP Trunking. 
            Scale your call capacity instantly, enjoy HD voice quality, and save up to 60% on line rentals.
        </p>
    </section>

    <section class="sip-grid">
        <div class="sip-card">
            <h3 style="color: var(--yellow); margin-bottom: 15px;">⚡ Instant Elasticity</h3>
            <p style="color: var(--text-300); font-size: 0.95rem;">Never run out of phone lines during peak hours. Add or remove channels on-demand without waiting for hardware installation.</p>
            <div class="tech-spec">G.711 & G.729 Codecs</div>
        </div>
        <div class="sip-card">
            <h3 style="color: var(--yellow); margin-bottom: 15px;">🛡️ Disaster Recovery</h3>
            <p style="color: var(--text-300); font-size: 0.95rem;">If your local office internet fails, we automatically reroute calls to a secondary location or mobile numbers.</p>
            <div class="tech-spec">Failover Protection</div>
        </div>
        <div class="sip-card">
            <h3 style="color: var(--yellow); margin-bottom: 15px;">🌍 Unified Presence</h3>
            <p style="color: var(--text-300); font-size: 0.95rem;">Consolidate your voice infrastructure. Use one trunk for multiple office branches worldwide, simplifying billing and management.</p>
            <div class="tech-spec">Global Number Portability</div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="position: relative;">
                <div style="position: relative;">
    <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80" 
         alt="Digital Communication Backbone" 
         style="width: 100%; border-radius: 40px; border: 1px solid var(--sip-blue); box-shadow: 0 0 50px rgba(13, 43, 142, 0.4); filter: brightness(0.9) contrast(1.1);">
                </div>
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Built for the <br><span style="color: var(--red);">Enterprise</span></h2>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-radius: 15px; border-left: 4px solid var(--sip-cyan);">
                        <h4 style="color: var(--yellow);">Call Centers</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Support high-concurrency outbound dialing for maximum agent productivity.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-radius: 15px; border-left: 4px solid var(--sip-cyan);">
                        <h4 style="color: var(--yellow);">Financial Institutions</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Secure, TLS-encrypted voice trunks that meet strict regulatory compliance standards.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-radius: 15px; border-left: 4px solid var(--sip-cyan);">
                        <h4 style="color: var(--yellow);">Remote Workforce</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Connect remote employees' softphones directly to the main company switchboard.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">4 Steps to <span>Deploy</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 30px;">
            <div class="sip-card" style="text-align: center;">
                <h1 style="color: var(--sip-red); opacity: 0.5;">01</h1>
                <h4>SIP Audit</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">We test your PBX compatibility (3CX, Asterisk, Avaya, etc).</p>
            </div>
            <div class="sip-card" style="text-align: center;">
                <h1 style="color: var(--sip-red); opacity: 0.5;">02</h1>
                <h4>Trunk Creation</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">We provision your SIP credentials and assign channels.</p>
            </div>
            <div class="sip-card" style="text-align: center;">
                <h1 style="color: var(--sip-red); opacity: 0.5;">03</h1>
                <h4>Firewall Prep</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Whitelist our signaling and media IP ranges for secure traffic.</p>
            </div>
            <div class="sip-card" style="text-align: center;">
                <h1 style="color: var(--sip-red); opacity: 0.5;">04</h1>
                <h4>Voice Live</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Run a test call and start enjoying high-density cloud voice.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(13, 43, 142, 0.2), transparent); border: 1px solid var(--sip-cyan);">
            <h2 style="margin-bottom: 20px;">Upgrade Your PBX to the Cloud.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Start your free 7-day SIP Trunk trial today. No hidden costs.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary" style="background: var(--sip-cyan); color: #000; border: none;">Get SIP Credentials</a>
                <a href="contact.php" class="btn-nav-ghost">Talk to a Voice Architect</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>