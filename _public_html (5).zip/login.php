<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | BulkSMSIndia</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #050a12; /* Match the deep navy/black from your hero */
            --accent-red: #d11a1a; /* Match the "Instant Access" button red */
            --accent-blue: #0056b3;
            --text-main: #ffffff;
            --text-muted: #a0a6b1;
            --input-bg: #0d141f;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-card {
            background: rgba(13, 20, 31, 0.8);
            padding: 40px;
            border-radius: 12px;
            width: 100%;
            max-width: 400px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 1px solid rgba(255, 255, 255, 0.05);
            text-align: center;
        }

        .login-card h2 {
            font-weight: 800;
            font-size: 2rem;
            margin-bottom: 10px;
        }

        .login-card p {
            color: var(--text-muted);
            margin-bottom: 30px;
            font-size: 0.9rem;
        }

        .form-group {
            text-align: left;
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .form-group input[type="email"],
        .form-group input[type="password"] {
            width: 100%;
            padding: 12px 15px;
            background: var(--input-bg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 6px;
            color: white;
            font-size: 1rem;
            box-sizing: border-box;
            transition: border-color 0.3s;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--accent-red);
        }

        .options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85rem;
            margin-bottom: 25px;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 5px;
            color: var(--text-muted);
        }

        .forgot-pass {
            color: var(--accent-red);
            text-decoration: none;
            font-weight: 600;
        }

        .btn-login {
            background-color: var(--accent-red);
            color: white;
            width: 100%;
            padding: 14px;
            border: none;
            border-radius: 30px; /* Matching the rounded style of the hero buttons */
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: transform 0.2s, background-color 0.3s;
        }

        .btn-login:hover {
            background-color: #b01515;
            transform: translateY(-2px);
        }

        .signup-link {
            margin-top: 25px;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .signup-link a {
            color: white;
            text-decoration: none;
            font-weight: 600;
            border-bottom: 1px solid var(--accent-red);
        }
    </style>
</head>
<body>

    <div class="login-card">
        <h2>Welcome Back</h2>
        <p>Login to your BulkSMSIndia dashboard</p>

        <form action="process_login.php" method="POST">
            <div class="form-group">
                <label for="email">Email Address</label>
                <input type="email" id="email" name="email" placeholder="name@company.com" required>
            </div>

            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" placeholder="••••••••" required>
            </div>

            <div class="options">
                <label class="remember-me">
                    <input type="checkbox" name="remember"> Remember me
                </label>
                <a href="forgot-password.php" class="forgot-pass">Forgot Password?</a>
            </div>

            <button type="submit" class="btn-login">Login to Platform</button>
        </form>

        <div class="signup-link">
            Don't have an account? <a href="signup.php">Sign Up Free</a>
        </div>
    </div>
</body>
</html>
