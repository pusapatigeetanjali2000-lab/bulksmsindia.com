<?php include 'includes/header.php'; ?>

<style>
    :root {
        --wa-green: #25D366;
        --wa-dark: #075E54;
        --soft-bg: #f8fafc;
        --text-main: #2d3748;
        --accent: #128C7E;
    }

    body {
        font-family: 'Inter', 'Segoe UI', sans-serif;
        background-color: var(--soft-bg);
        color: var(--text-main);
        line-height: 1.6;
    }

    /* Elegant Hero with Background Pattern */
    .wa-hero {
        background: linear-gradient(rgba(7, 94, 84, 0.9), rgba(18, 140, 126, 0.9)), 
                    url('https://www.transparenttextures.com/patterns/cubes.png'),
                    url('https://images.unsplash.com/photo-1611746872915-64382b5c76da?auto=format&fit=crop&w=1200&q=80');
        background-size: cover;
        background-position: center;
        color: white;
        padding: 100px 5% 140px;
        text-align: center;
        clip-path: ellipse(150% 100% at 50% 0%);
    }

    .wa-hero h1 { font-size: 3.5rem; margin-bottom: 10px; font-weight: 800; }
    .powered-badge {
        background: rgba(255,255,255,0.2);
        padding: 5px 20px;
        border-radius: 50px;
        font-size: 0.9rem;
        text-transform: uppercase;
        letter-spacing: 2px;
    }

    /* Feature Grid */
    .section-padding { padding: 80px 10%; }
    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 30px;
        margin-top: -80px;
    }

    .f-card {
        background: #fff;
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 20px 40px rgba(0,0,0,0.05);
        text-align: center;
        transition: 0.3s;
        border-bottom: 4px solid transparent;
    }

    .f-card:hover { transform: translateY(-10px); border-bottom-color: var(--wa-green); }
    .f-card i { font-size: 3rem; color: var(--wa-green); margin-bottom: 20px; }

    /* Use Cases & Industries */
    .industry-section { background: #fff; border-radius: 30px; padding: 60px; margin: 40px 0; }
    .pill {
        display: inline-block;
        padding: 8px 20px;
        background: #e6f9ed;
        color: var(--wa-dark);
        border-radius: 50px;
        margin: 5px;
        font-weight: 600;
        font-size: 0.9rem;
    }

    /* Steps to Use CloudPBX */
    .step-box {
        display: flex;
        align-items: flex-start;
        gap: 20px;
        margin-bottom: 30px;
        background: #fff;
        padding: 25px;
        border-radius: 15px;
    }
    .step-num {
        background: var(--wa-green);
        color: white;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-shrink: 0;
        font-weight: bold;
    }

    .guarantee-banner {
        background: var(--wa-dark);
        color: white;
        padding: 60px;
        border-radius: 30px;
        text-align: center;
        margin-top: 50px;
    }

    .big-stat { font-size: 5rem; font-weight: 900; color: var(--wa-green); display: block; }

    .btn-demo {
        background: var(--wa-green);
        color: white;
        padding: 20px 50px;
        border-radius: 50px;
        font-size: 1.2rem;
        font-weight: 700;
        text-decoration: none;
        display: inline-block;
        margin-top: 30px;
        box-shadow: 0 10px 20px rgba(37, 211, 102, 0.3);
    }
</style>

<div class="wa-hero">
    <span class="powered-badge">Powered by CheapSMS.com</span>
    <h1>Unlimited WhatsApp Marketing</h1>
    <p>The Ultimate Communication Suite for BulkSMSIndia Clients</p>
</div>

<div class="section-padding">
    <div class="feature-grid">
        <div class="f-card">
            <i class="fas fa-bolt"></i>
            <h3>1 Lakh Messages</h3>
            <p>High-capacity daily delivery for massive reach.</p>
        </div>
        <div class="f-card">
            <i class="fas fa-photo-video"></i>
            <h3>Rich Media</h3>
            <p>Send PDFs, Images, and 1500+ Character texts.</p>
        </div>
        <div class="f-card">
            <i class="fas fa-shield-alt"></i>
            <h3>Anti-Block Tech</h3>
            <p>Smart rotation systems to keep your number safe.</p>
        </div>
    </div>

    <div class="industry-section">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 40px;">
            <div>
                <h2 style="color:var(--wa-dark)">📍 Key Use Cases</h2>
                <ul style="list-style: none; padding:0;">
                    <li>✅ <strong>Flash Sales:</strong> Send instant alerts for time-limited deals.</li>
                    <li>✅ <strong>Abandoned Carts:</strong> Remind customers to finish checkout.</li>
                    <li>✅ <strong>Event Updates:</strong> Share ticket links and reminders.</li>
                    <li>✅ <strong>Customer Support:</strong> 24/7 automated bot interactions.</li>
                </ul>
            </div>
            <div>
                <h2 style="color:var(--wa-dark)">🏢 Top Industries</h2>
                <div class="pill-container">
                    <span class="pill">E-Commerce</span>
                    <span class="pill">Real Estate</span>
                    <span class="pill">Banking & Finance</span>
                    <span class="pill">Healthcare</span>
                    <span class="pill">Education</span>
                    <span class="pill">Gaming</span>
                </div>
            </div>
        </div>
    </div>

    <h2 style="text-align: center; margin: 60px 0 30px;">How to Start with CloudPBX Integration</h2>
    <div style="max-width: 800px; margin: 0 auto;">
        <div class="step-box">
            <div class="step-num">1</div>
            <div>
                <h4>Verify Your Business</h4>
                <p>Register your Meta Business Manager and verify your domain for API access.</p>
            </div>
        </div>
        <div class="step-box">
            <div class="step-num">2</div>
            <div>
                <h4>Setup CloudPBX Triggers</h4>
                <p>Connect your phone number to our CloudPBX system to handle inbound voice & text events.</p>
            </div>
        </div>
        <div class="step-box">
            <div class="step-num">3</div>
            <div>
                <h4>Upload & Launch</h4>
                <p>Upload your contact list, choose your media, and hit send. Monitor ROI in real-time.</p>
            </div>
        </div>
    </div>

    <div class="guarantee-banner">
        <h2>GUARANTEED TOTAL DELIVERY</h2>
        <span class="big-stat">18,000,000</span>
        <p>Messages Delivered Every 6 Months</p>
        <a href="#" class="btn-demo">GET INSTANT DEMO</a>
    </div>
</div>

<?php include 'includes/footer.php'; ?>