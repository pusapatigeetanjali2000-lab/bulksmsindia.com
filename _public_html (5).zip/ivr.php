<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Smart IVR Solutions | Automated Call Routing | BulkSMSIndia";
?>

<style>
    :root {
        --ivr-blue: #0d2b8e;
        --ivr-red: #db1212;
        --ivr-glass: rgba(255, 255, 255, 0.03);
    }

    .ivr-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.85), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-ivr {
        padding: 180px 4% 80px;
        text-align: center;
    }

    /* Flowline Animation for that 'Smart' feel */
    .flow-line {
        width: 2px;
        height: 50px;
        background: linear-gradient(to bottom, var(--ivr-red), transparent);
        margin: 0 auto;
        position: relative;
    }

    .ivr-card {
        background: var(--ivr-glass);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        padding: 35px;
        transition: all 0.4s ease;
        text-align: center;
    }

    .ivr-card:hover {
        border-color: var(--ivr-red);
        transform: translateY(-10px);
        box-shadow: 0 15px 30px rgba(219, 18, 18, 0.1);
    }

    .ivr-step {
        background: rgba(13, 43, 142, 0.3);
        border: 1px dashed var(--ivr-red);
        border-radius: 15px;
        padding: 20px;
        position: relative;
    }

    .ivr-step::after {
        content: '➔';
        position: absolute;
        right: -20px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--ivr-red);
        font-weight: bold;
        opacity: 0.5;
    }

    @media (max-width: 768px) {
        .ivr-step::after { content: '⬇'; right: auto; bottom: -25px; left: 50%; transform: translateX(-50%); }
    }
</style>

<div class="ivr-bg">
    <section class="hero-ivr">
        <div style="display: inline-block; padding: 6px 16px; background: rgba(219, 18, 18, 0.15); color: var(--ivr-red); border-radius: 5px; font-size: 0.8rem; font-weight: 700; margin-bottom: 20px; letter-spacing: 1px;">24/7 VIRTUAL RECEPTIONIST</div>
        <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 900; line-height: 1.1; margin-bottom: 25px;">
            Professional <span style="color: var(--ivr-red);">Call Handling</span> <br>Without the Overhead.
        </h1>
        <p style="max-width: 800px; margin: 0 auto; color: var(--text-300); font-size: 1.1rem; line-height: 1.8;">
            Impress your callers with a custom IVR menu. Route calls to the right department, 
            provide automated information, and never miss a business lead again.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="ivr-card">
                <div style="font-size: 2.5rem; margin-bottom: 15px;">🏢</div>
                <h3 style="color: var(--yellow); margin-bottom: 10px;">Corporate Image</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Sound like a Fortune 500 company from day one with a professional voice greeting.</p>
            </div>
            <div class="ivr-card">
                <div style="font-size: 2.5rem; margin-bottom: 15px;">⏳</div>
                <h3 style="color: var(--yellow); margin-bottom: 10px;">Zero Wait Time</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Handle multiple calls simultaneously and resolve queries via automated self-service menus.</p>
            </div>
            <div class="ivr-card">
                <div style="font-size: 2.5rem; margin-bottom: 15px;">🎯</div>
                <h3 style="color: var(--yellow); margin-bottom: 10px;">Smart Routing</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Direct callers to Sales, Support, or Billing based on their keypad input (Press 1, Press 2).</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div>
                <img src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=800&q=80" alt="Customer Service" style="width: 100%; border-radius: 30px; box-shadow: 0 30px 60px rgba(0,0,0,0.4);">
            </div>
            <div>
                <h2 style="font-size: 2.5rem; margin-bottom: 30px;">Designed for Every <span>Business Scale</span></h2>
                <ul style="list-style: none; padding: 0; color: var(--text-300); display: flex; flex-direction: column; gap: 20px;">
                    <li style="display: flex; gap: 15px; background: rgba(255,255,255,0.03); padding: 20px; border-radius: 15px;">
                        <span style="color: var(--ivr-red); font-weight: bold;">✔</span>
                        <span><strong>Banking:</strong> Check balance or block cards without an agent.</span>
                    </li>
                    <li style="display: flex; gap: 15px; background: rgba(255,255,255,0.03); padding: 20px; border-radius: 15px;">
                        <span style="color: var(--ivr-red); font-weight: bold;">✔</span>
                        <span><strong>E-commerce:</strong> Track order status via automated order IDs.</span>
                    </li>
                    <li style="display: flex; gap: 15px; background: rgba(255,255,255,0.03); padding: 20px; border-radius: 15px;">
                        <span style="color: var(--ivr-red); font-weight: bold;">✔</span>
                        <span><strong>Healthcare:</strong> Book, cancel, or reschedule appointments 24/7.</span>
                    </li>
                </ul>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Setup Your <span>Smart Flow</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 40px; position: relative;">
            <div class="ivr-step">
                <h4>1. Greeting</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Record or upload your welcome message.</p>
            </div>
            <div class="ivr-step">
                <h4>2. Menu Logic</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Set 'Press 1 for Sales, 2 for Support'.</p>
            </div>
            <div class="ivr-step">
                <h4>3. Mapping</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Map inputs to mobile numbers or landlines.</p>
            </div>
            <div class="ivr-step" style="border-right: 1px dashed var(--ivr-red);">
                <h4>4. Go Live</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Your virtual office is now open for calls.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 800px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(219, 18, 18, 0.1), transparent); border: 1px solid var(--ivr-red);">
            <h2 style="margin-bottom: 20px;">Never Miss a Call Again.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Get started with BulkSMSIndia's intelligent IVR today.</p>
            <a href="signup.php" class="btn-nav-primary" style="padding: 18px 50px;">Create IVR Flow</a>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>