<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?php echo isset($page_title) ? $page_title : 'BulkSMSIndia | AI-Powered CPaaS Platform'; ?></title>
  
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">

  <style>
    :root {
      --navy: #0d2b8e;
      --red: #db1212;
      --yellow: #fde74c;
      --bg-dark: #050a15;
      --text-100: #ffffff;
      --text-300: #cbd5e1;
      --nav-h: 85px;
      --transition: .3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* Base Reset */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { background: var(--bg-dark); color: var(--text-100); font-family: 'Outfit', sans-serif; }
    a { text-decoration: none; color: inherit; transition: var(--transition); }
    ul { list-style: none; }

    /* Navbar Structure */
    .navbar {
      position: fixed; top: 0; left: 0; width: 100%; height: var(--nav-h);
      background: rgba(13, 43, 142, 0.96);
      backdrop-filter: blur(15px);
      border-bottom: 3px solid var(--red);
      display: flex; align-items: center; justify-content: space-between;
      padding: 0 4%; z-index: 1000;
    }

    .nav-logo { display: flex; align-items: center; gap: 12px; z-index: 1001; }
    .logo-mark {
      width: 40px; height: 40px; background: var(--red); border-radius: 8px;
      display: flex; align-items: center; justify-content: center; font-weight: 900; color: #fff;
    }
    .logo-wordmark .bottom { font-size: 1.2rem; font-weight: 800; display: block; }
    .logo-wordmark .bottom span { color: var(--yellow); }
    .logo-wordmark .tagline { font-size: 0.6rem; color: var(--yellow); text-transform: uppercase; letter-spacing: 1px; font-weight: 600; }

    /* Nav Menu */
    .nav-menu { display: flex; align-items: center; gap: 4px; }
    .nav-menu > li > a {
      padding: 10px 12px; font-size: 0.85rem; font-weight: 600; color: #fff;
      display: flex; align-items: center; gap: 6px; cursor: pointer;
      position: relative;
    }
    .nav-menu > li:hover > a { color: var(--yellow); }

    /* Dropdowns */
    .dropdown-wrapper { position: relative; }
    .dropdown-content {
      display: none; 
      position: absolute; 
      top: 100%; 
      left: 50%; 
      transform: translateX(-50%);
      min-width: 260px; 
      padding-top: 15px; 
      z-index: 1100;
    }
    .dropdown-content.active { display: block !important; }
    
    .wide-dropdown { min-width: 500px; }

    .nav-dropdown {
      background: #0b1a4a; border-top: 3px solid var(--red);
      border-radius: 0 0 12px 12px; padding: 15px 0;
      box-shadow: 0 20px 50px rgba(0,0,0,0.5);
      max-height: 80vh; overflow-y: auto;
    }

    .nav-dropdown a { 
      display: block; 
      padding: 10px 25px; 
      font-size: 0.85rem; 
      color: var(--text-300); 
      transition: all 0.2s ease;
    }
    .nav-dropdown a:hover { 
      background: rgba(253, 231, 76, 0.05); 
      color: var(--yellow); 
      padding-left: 30px; 
    }

    .group-label {
      display: block; padding: 12px 25px 5px; font-size: 0.7rem; font-weight: 800;
      color: var(--yellow); text-transform: uppercase; letter-spacing: 1px;
    }

    /* Actions */
    .nav-actions { display: flex; align-items: center; gap: 15px; }
    .btn-nav-ghost { 
      padding: 8px 20px; 
      border: 2px solid var(--yellow); 
      color: var(--yellow); 
      border-radius: 6px; 
      font-weight: 700; 
      font-size: 0.8rem; 
      display: inline-block;
      text-align: center;
    }
    .btn-nav-primary { 
      padding: 10px 24px; 
      background: var(--red); 
      color: #fff; 
      border-radius: 6px; 
      font-weight: 700; 
      font-size: 0.8rem; 
      box-shadow: 0 4px 15px rgba(219, 18, 18, 0.3); 
      display: inline-block;
      text-align: center;
    }
    .btn-nav-ghost:hover { background: var(--yellow); color: var(--navy); }
    .btn-nav-primary:hover { background: #ff1a1a; }

    .arrow-icon { 
      transition: transform 0.3s ease; 
      display: inline-block;
      flex-shrink: 0;
    }
    .arrow-icon.rotate-180 { transform: rotate(180deg); }

    /* Mobile Menu Logic */
    .hamburger { 
      display: none; 
      flex-direction: column; 
      gap: 6px; 
      background: none; 
      border: none; 
      cursor: pointer; 
      z-index: 1001; 
      padding: 10px;
    }
    .hamburger span { 
      width: 28px; 
      height: 3px; 
      background: #fff; 
      border-radius: 10px; 
      transition: var(--transition); 
    }

    /* Hamburger Animation to 'X' */
    .hamburger.active span:nth-child(1) { transform: translateY(9px) rotate(45deg); }
    .hamburger.active span:nth-child(2) { opacity: 0; }
    .hamburger.active span:nth-child(3) { transform: translateY(-9px) rotate(-45deg); }

    /* Mobile Close Button */
    .mobile-close {
      display: none;
      position: fixed;
      top: 20px;
      right: 20px;
      background: var(--red);
      color: white;
      border: none;
      width: 45px;
      height: 45px;
      border-radius: 50%;
      cursor: pointer;
      font-size: 28px;
      align-items: center;
      justify-content: center;
      z-index: 1002;
      transition: var(--transition);
      line-height: 1;
      box-shadow: 0 4px 15px rgba(219, 18, 18, 0.4);
    }
    .mobile-close:hover { background: #ff1a1a; transform: rotate(90deg); }
    .mobile-close:active { transform: scale(0.95); }

    .mobile-actions { display: none; }

    @media (max-width: 1200px) {
      .hamburger { display: flex; }
      
      /* Show close button only when menu is open */
      .nav-menu.open ~ .mobile-close {
        display: flex;
      }
      
      .nav-menu {
        position: fixed; 
        top: 0; 
        right: -100%; 
        width: 320px; 
        height: 100vh;
        background: #0b1a4a; 
        flex-direction: column; 
        align-items: flex-start;
        padding: 80px 0 40px; 
        transition: 0.4s ease; 
        overflow-y: auto;
        box-shadow: -10px 0 30px rgba(0,0,0,0.5);
      }
      
      .nav-menu.open { right: 0; }

      .nav-menu > li { width: 100%; }
      .nav-menu > li > a { 
        font-size: 1rem; 
        padding: 15px 20px; 
        justify-content: space-between; 
        border-bottom: 1px solid rgba(255,255,255,0.1); 
        width: 100%;
      }

      .dropdown-content { 
        position: static !important; 
        transform: none !important; 
        min-width: 100% !important; 
        padding-top: 0 !important; 
        background: rgba(0,0,0,0.2); 
        display: none;
      }
      .dropdown-content.active {
        display: block !important;
      }

      .wide-dropdown { min-width: 100% !important; }
      
      .nav-dropdown { 
        background: none !important; 
        border: none !important; 
        box-shadow: none !important; 
        padding: 5px 0 !important; 
      }
      .nav-dropdown div { grid-template-columns: 1fr !important; }
      .nav-dropdown a {
        padding: 10px 30px !important;
        font-size: 0.9rem;
      }
      .nav-dropdown a:hover {
        padding-left: 35px !important;
      }
      
      .group-label {
        padding: 10px 30px 5px !important;
        font-size: 0.65rem;
      }
      
      .nav-actions {
        display: none;
      }
      
      .mobile-actions { 
        display: flex !important; 
        flex-direction: column; 
        gap: 12px; 
        width: 100%; 
        padding: 20px; 
        margin-top: 10px;
        border-top: 1px solid rgba(255,255,255,0.1);
      }
    }

    /* Desktop hover for dropdowns */
    @media (min-width: 1201px) {
      .dropdown-wrapper:hover .dropdown-content {
        display: block;
      }
      .dropdown-wrapper:hover .arrow-icon {
        transform: rotate(180deg);
      }
    }

    /* Content spacing */
    .page-content {
      margin-top: calc(var(--nav-h) + 40px);
      padding: 20px;
      min-height: 100vh;
    }
  </style>
</head>
<body>

<nav class="navbar">
  <a href="index.php" class="nav-logo">
    <div class="logo-mark">BI</div>
    <div class="logo-wordmark">
      <span class="bottom">BulkSMS<span>India</span></span>
      <span class="tagline">The Firm Group Partner</span>
    </div>
  </a>

  <ul class="nav-menu" id="nav-menu">
    <li class="dropdown-wrapper">
      <a href="javascript:void(0)" class="dropdown-toggle">
        <span>Bulk SMS</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="arrow-icon">
          <path d="M19 9l-7 7-7-7" />
        </svg>
      </a>
      <div class="dropdown-content">
        <div class="nav-dropdown">
          <a href="promotional-bulksms.php">Promo / Marketing SMS</a>
          <a href="transactional-bulksms.php">Transactional / OTP SMS</a>
          <a href="twoway-bulksms-services.php">Two Way SMS</a>
          <a href="dlt-registration.php">DLT Registration</a>
        </div>
      </div>
    </li>

    <li class="dropdown-wrapper">
      <a href="javascript:void(0)" class="dropdown-toggle">
        <span>WhatsApp</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="arrow-icon">
          <path d="M19 9l-7 7-7-7" />
        </svg>
      </a>
      <div class="dropdown-content">
        <div class="nav-dropdown">
          <a href="bulk-whatsapp.php">Bulk WhatsApp</a>
          <a href="whatsapp-business-api-meta.php">WhatsApp Business API (META)</a>
          <a href="unlimited-whatsapp.php">Unlimited WhatsApp</a>
        </div>
      </div>
    </li>

    <li><a href="rcs-rich-communication-sms-services.php">RCS</a></li>

    <li class="dropdown-wrapper">
      <a href="javascript:void(0)" class="dropdown-toggle">
        <span>Voice</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="arrow-icon">
          <path d="M19 9l-7 7-7-7" />
        </svg>
      </a>
      <div class="dropdown-content">
        <div class="nav-dropdown">
          <a href="voicebroadcasting.php">Voice Broadcasting</a>
          <a href="ivr.php">IVR</a>
          <a href="voip.php">VoIP Services</a>
          <a href="voiceqos.php">Voice QoS</a>
          <a href="siptrunk.php">SIP Trunk / TDM</a>
          <a href="didnumbers.php">DID / Toll Free</a>
        </div>
      </div>
    </li>

    <li class="dropdown-wrapper">
      <a href="javascript:void(0)" class="dropdown-toggle">
        <span>AI Automation</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="arrow-icon">
          <path d="M19 9l-7 7-7-7" />
        </svg>
      </a>
      <div class="dropdown-content">
        <div class="nav-dropdown">
          <a href="ai-agents.php">AI Agents</a>
          <a href="ai-chatbots.php">AI Chatbots</a>
          <a href="ai-tools.php">AI Tools</a>
        </div>
      </div>
    </li>

    <li class="dropdown-wrapper">
      <a href="javascript:void(0)" class="dropdown-toggle" style="color: var(--yellow);">
        <span>All Services</span>
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" class="arrow-icon">
          <path d="M19 9l-7 7-7-7" />
        </svg>
      </a>
      <div class="dropdown-content wide-dropdown">
        <div class="nav-dropdown">
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0 10px;">
            <div>
              <span class="group-label">Bulk Messaging</span>
              <a href="promotional-bulksms.php">Promo / Marketing SMS</a>
              <a href="transactional-bulksms.php">Transactional / OTP SMS</a>
              <a href="dlt-registration.php">DLT Registration</a>
              <a href="twoway-bulksms-services.php">Two Way SMS</a>
              <a href="rcs-rich-communication-sms-services.php">RCS Messaging</a>
              
              <span class="group-label">WhatsApp</span>
              <a href="bulk-whatsapp.php">Bulk WhatsApp</a>
              <a href="whatsapp-business-api-meta.php">WhatsApp Business API</a>
              <a href="unlimited-whatsapp.php">Unlimited WhatsApp</a>
            </div>
            <div>
              <span class="group-label">AI Solutions</span>
              <a href="ai-agents.php">AI Agents</a>
              <a href="ai-chatbots.php">AI Chatbots</a>
              <a href="ai-tools.php">AI Tools</a>

              <span class="group-label">Voice Services</span>
              <a href="voicebroadcasting.php">Voice Broadcasting</a>
              <a href="ivr.php">IVR</a>
              <a href="voip.php">VoIP Services</a>
              
              <span class="group-label">Enterprise</span>
              <a href="white-label-reseller.php">White-Label Reseller</a>
              <a href="custom-api-integration.php">Custom API</a>
              <a href="cloudpbx.php">Cloudpbx</a>
              <a href="ms-teams-routing.php">Ms Teams Direct Routing</a>
            </div>
          </div>
        </div>
      </div>
    </li>

    <li><a href="pricing.php">Pricing</a></li>
    
    <li class="mobile-actions">
      <a href="login.php" class="btn-nav-ghost">Log in</a>
      <a href="signup.php" class="btn-nav-primary">Sign Up</a>
    </li>
  </ul>

  <div class="nav-actions">
    <a href="login.php" class="btn-nav-ghost">Log in</a>
    <a href="signup.php" class="btn-nav-primary">Sign Up</a>
  </div>

  <button class="hamburger" id="hamburger" aria-label="Toggle menu">
    <span></span><span></span><span></span>
  </button>

  <button class="mobile-close" id="mobile-close" aria-label="Close menu">×</button>
</nav>


<script>
document.addEventListener('DOMContentLoaded', function() {
    const hamburger = document.getElementById('hamburger');
    const mobileClose = document.getElementById('mobile-close');
    const navMenu = document.getElementById('nav-menu');
    const dropdownToggles = document.querySelectorAll('.dropdown-toggle');
    const body = document.body;

    console.log("Navigation initialized");
    console.log("Dropdown toggles found:", dropdownToggles.length);

    // Function to close menu
    function closeMenu() {
        navMenu.classList.remove('open');
        hamburger.classList.remove('active');
        hamburger.style.display = 'flex';
        if (mobileClose) {
            mobileClose.style.display = 'none';
        }
        // Close all dropdowns
        document.querySelectorAll('.dropdown-content').forEach(d => {
            d.classList.remove('active');
        });
        document.querySelectorAll('.arrow-icon').forEach(icon => {
            icon.classList.remove('rotate-180');
        });
    }

    // Function to open menu
    function openMenu() {
        navMenu.classList.add('open');
        hamburger.classList.add('active');
        if (window.innerWidth <= 1200) {
            hamburger.style.display = 'none';
            if (mobileClose) {
                mobileClose.style.display = 'flex';
            }
        }
    }

    // Hamburger click
    if (hamburger) {
        hamburger.addEventListener('click', function(e) {
            e.stopPropagation();
            if (navMenu.classList.contains('open')) {
                closeMenu();
            } else {
                openMenu();
            }
            console.log("Menu toggled:", navMenu.classList.contains('open'));
        });
    }

    // Mobile close button
    if (mobileClose) {
        mobileClose.addEventListener('click', function(e) {
            e.stopPropagation();
            closeMenu();
            console.log("Close button clicked");
        });
    }

    // Dropdown toggle logic
    dropdownToggles.forEach(function(toggle) {
        toggle.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();

            const parent = this.closest('.dropdown-wrapper');
            const dropdown = parent.querySelector('.dropdown-content');
            const icon = this.querySelector('.arrow-icon');
            
            const isActive = dropdown.classList.contains('active');

            // On mobile, allow multiple dropdowns open
            // On desktop, close others
            if (window.innerWidth > 1200) {
                document.querySelectorAll('.dropdown-content').forEach(d => {
                    if (d !== dropdown) {
                        d.classList.remove('active');
                    }
                });
                document.querySelectorAll('.arrow-icon').forEach(i => {
                    if (i !== icon) {
                        i.classList.remove('rotate-180');
                    }
                });
            }

            // Toggle current dropdown
            dropdown.classList.toggle('active');
            if (icon) {
                icon.classList.toggle('rotate-180');
            }

            console.log("Dropdown toggled. Active:", dropdown.classList.contains('active'));
        });
    });

    // Close menu when clicking outside (mobile only)
    document.addEventListener('click', function(e) {
        const isClickInsideMenu = navMenu.contains(e.target);
        const isClickOnHamburger = hamburger.contains(e.target);
        const isClickOnClose = mobileClose && mobileClose.contains(e.target);
        
        if (!isClickInsideMenu && !isClickOnHamburger && !isClickOnClose && navMenu.classList.contains('open')) {
            closeMenu();
            console.log("Clicked outside - menu closed");
        }
    });

    // Close menu on escape key
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape' && navMenu.classList.contains('open')) {
            closeMenu();
            console.log("Escape pressed - menu closed");
        }
    });

    // Prevent body scroll when mobile menu is open
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.attributeName === 'class') {
                if (navMenu.classList.contains('open')) {
                    body.style.overflow = 'hidden';
                } else {
                    body.style.overflow = '';
                }
            }
        });
    });

    observer.observe(navMenu, { attributes: true });

    // Handle window resize
    window.addEventListener('resize', function() {
        if (window.innerWidth > 1200) {
            // Desktop view - reset mobile menu state
            closeMenu();
            hamburger.style.display = 'none';
            if (mobileClose) {
                mobileClose.style.display = 'none';
            }
        } else {
            // Mobile view - show hamburger if menu is closed
            if (!navMenu.classList.contains('open')) {
                hamburger.style.display = 'flex';
                if (mobileClose) {
                    mobileClose.style.display = 'none';
                }
            }
        }
    });

    // Initial state on load
    if (window.innerWidth <= 1200) {
        hamburger.style.display = 'flex';
        if (mobileClose) {
            mobileClose.style.display = 'none';
        }
    }
});
</script>

</body>
</html>