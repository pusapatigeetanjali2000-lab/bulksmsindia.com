<footer class="site-footer" style="background: #050a15; border-top: 4px solid var(--red); padding: 70px 0 30px; margin-top: 50px;">
  <div style="max-width: 1200px; margin: 0 auto; padding: 0 20px;">
    
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 40px; padding-bottom: 40px; border-bottom: 1px solid rgba(255,255,255,0.1);">
      
      <div class="footer-brand">
        <a href="index.php" class="nav-logo" style="margin-bottom: 20px;">
          <div class="logo-mark">BI</div>
          <div class="logo-wordmark">
            <span class="bottom">BulkSMS<span>India</span></span>
            <span class="tagline">The Firm Group Partner</span>
          </div>
        </a>
        <p style="font-size: 0.85rem; color: var(--text-500); line-height: 1.8;">
          Leading India's digital communication revolution with enterprise-grade SMS, WhatsApp, and AI solutions.
        </p>
      </div>

      <div>
        <h4 style="color: var(--yellow); font-size: 0.9rem; margin-bottom: 20px; text-transform: uppercase;">Services</h4>
        <ul style="display: flex; flex-direction: column; gap: 10px; font-size: 0.85rem; color: var(--text-500);">
          <li><a href="promotional-bulksms.php" onmouseover="this.style.color='var(--yellow)'" onmouseout="this.style.color=''">Promo SMS</a></li>
          <li><a href="transactional-bulksms.php" onmouseover="this.style.color='var(--yellow)'" onmouseout="this.style.color=''">OTP Services</a></li>
          <li><a href="bulk-whatsapp.php" onmouseover="this.style.color='var(--yellow)'" onmouseout="this.style.color=''">WhatsApp Marketing</a></li>
          <li><a href="ai-agents.php" onmouseover="this.style.color='var(--yellow)'" onmouseout="this.style.color=''">AI Automation</a></li>
        </ul>
      </div>

      <div>
        <h4 style="color: var(--yellow); font-size: 0.9rem; margin-bottom: 20px; text-transform: uppercase;">Company</h4>
        <ul style="display: flex; flex-direction: column; gap: 10px; font-size: 0.85rem; color: var(--text-500);">
          <li><a href="about-us.php">About Us</a></li>
          <li><a href="pricing.php">Pricing Plans</a></li>
          <li><a href="contact-us.php">Contact Support</a></li>
          <li><a href="privacy.php">Privacy Policy</a></li>
        </ul>
      </div>

    </div>

    <div style="display: flex; justify-content: space-between; align-items: center; padding-top: 30px; flex-wrap: wrap; gap: 20px;">
      <p style="font-size: 0.8rem; color: var(--text-500);">
        &copy; <?php echo date('Y'); ?> BulkSMSIndia.com. All rights reserved. 
      </p>
    </div>
  </div>
</footer>

<script>
document.addEventListener('DOMContentLoaded', () => {
    // Desktop Dropdown Logic
    const triggers = document.querySelectorAll('.desktop-toggle');
    
    triggers.forEach(trigger => {
        trigger.addEventListener('click', (e) => {
            e.stopPropagation();
            const content = trigger.nextElementSibling;
            const arrow = trigger.querySelector('.arrow-icon');
            
            // Close others
            document.querySelectorAll('.dropdown-content').forEach(c => {
                if(c !== content) c.classList.remove('active');
            });
            document.querySelectorAll('.arrow-icon').forEach(a => {
                if(a !== arrow) a.classList.remove('rotate-180');
            });

            content.classList.toggle('active');
            arrow.classList.toggle('rotate-180');
        });
    });

    // Close on outside click
    document.addEventListener('click', () => {
        document.querySelectorAll('.dropdown-content').forEach(c => c.classList.remove('active'));
        document.querySelectorAll('.arrow-icon').forEach(a => a.classList.remove('rotate-180'));
    });

    // Mobile Menu Toggle
    const hbg = document.getElementById('hamburger');
    const mNav = document.getElementById('mobileNav');
    hbg.addEventListener('click', () => {
        mNav.classList.toggle('open');
        hbg.classList.toggle('active');
    });
});

function toggleMob(btn) {
    const sub = btn.nextElementSibling;
    sub.classList.toggle('open');
}
</script>
</body>
</html>