<?php include 'includes/header.php'; ?>
<style>
    .hero-section {
        padding: 150px 4% 80px;
        background: radial-gradient(circle at top right, rgba(219, 18, 18, 0.1), transparent), 
                    radial-gradient(circle at bottom left, rgba(13, 43, 142, 0.2), transparent);
        text-align: center;
    }

    .hero-badge {
        display: inline-block;
        padding: 6px 16px;
        background: rgba(253, 231, 76, 0.1);
        border: 1px solid var(--yellow);
        color: var(--yellow);
        border-radius: 50px;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 1px;
        margin-bottom: 20px;
    }

    .glass-card {
        background: rgba(255, 255, 255, 0.03);
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        padding: 30px;
        transition: var(--transition);
    }

    .glass-card:hover {
        border-color: var(--red);
        transform: translateY(-5px);
    }

    .step-number {
        font-size: 3rem;
        font-weight: 900;
        color: rgba(255, 255, 255, 0.05);
        position: absolute;
        top: 10px;
        right: 20px;
    }

    .section-title {
        font-size: 2.5rem;
        font-weight: 800;
        margin-bottom: 50px;
        text-align: center;
    }

    .section-title span { color: var(--red); }

    .grid-3 {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 25px;
        padding: 50px 0;
    }

    .industry-img {
        width: 100%;
        height: 180px;
        object-fit: cover;
        border-radius: 12px;
        margin-bottom: 15px;
    }
</style>

<main>
    <section class="hero-section">
        <div class="hero-badge">MARKETING & SALES</div>
        <h1 class="section-title">Scale Your Reach with <span>Promotional SMS</span></h1>
        <p style="max-width: 700px; margin: 0 auto 30px; color: var(--text-300); line-height: 1.6;">
            Turn every mobile phone into a storefront. Promotional SMS is the fastest way to blast offers, discounts, and brand updates to your audience with a 98% open rate.
        </p>
        <div class="nav-actions" style="justify-content: center;">
            <a href="signup.php" class="btn-nav-primary" style="padding: 15px 40px; font-size: 1rem;">Launch Campaign Now</a>
        </div>
    </section>

    <section style="padding: 80px 4%;">
        <h2 class="section-title">Why <span>Promo SMS?</span></h2>
        <div class="grid-3">
            <div class="glass-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">⚡ Instant Delivery</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Reach thousands of customers simultaneously in less than 10 seconds. Perfect for flash sales.</p>
            </div>
            <div class="glass-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">📈 High Conversion</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">SMS has a 45% response rate compared to just 6% for email. Get more clicks per message.</p>
            </div>
            <div class="glass-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">💰 Low Cost, High ROI</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">The most affordable digital marketing channel available today for small and large businesses.</p>
            </div>
        </div>
    </section>

    <section style="padding: 80px 4%; background: rgba(13, 43, 142, 0.2);">
        <h2 class="section-title">Industries <span>Winning</span> with Us</h2>
        <div class="grid-3">
            <div class="glass-card">
                <img src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=500&q=80" alt="Retail" class="industry-img">
                <h4 style="margin-bottom: 10px;">Retail & E-commerce</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Send coupon codes, discount alerts, and "back-in-stock" notifications to boost sales.</p>
            </div>
            <div class="glass-card">
                <img src="https://images.unsplash.com/photo-1560518883-ce09059eeffa?auto=format&fit=crop&w=500&q=80" alt="Real Estate" class="industry-img">
                <h4 style="margin-bottom: 10px;">Real Estate</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Announce new project launches and schedule site visits with interested buyers instantly.</p>
            </div>
            <div class="glass-card">
                <img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=500&q=80" alt="Education" class="industry-img">
                <h4 style="margin-bottom: 10px;">Education</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Alert parents about admissions, promote new courses, and send holiday notices easily.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 class="section-title">Start in <span>5 Minutes</span></h2>
        <div class="grid-3" style="grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));">
            <div class="glass-card" style="position: relative;">
                <span class="step-number">01</span>
                <h4 style="color: var(--red);">Register</h4>
                <p style="font-size: 0.85rem; margin-top: 10px;">Sign up and get your DLT registration verified.</p>
            </div>
            <div class="glass-card" style="position: relative;">
                <span class="step-number">02</span>
                <h4 style="color: var(--red);">Add Credits</h4>
                <p style="font-size: 0.85rem; margin-top: 10px;">Choose a package that fits your marketing budget.</p>
            </div>
            <div class="glass-card" style="position: relative;">
                <span class="step-number">03</span>
                <h4 style="color: var(--red);">Upload List</h4>
                <p style="font-size: 0.85rem; margin-top: 10px;">Import your customer contacts via Excel or CSV.</p>
            </div>
            <div class="glass-card" style="position: relative;">
                <span class="step-number">04</span>
                <h4 style="color: var(--red);">Send</h4>
                <p style="font-size: 0.85rem; margin-top: 10px;">Craft your message and hit the send button!</p>
            </div>
        </div>
    </section>

    <section style="padding: 80px 4%; text-align: center; background: linear-gradient(to bottom, transparent, rgba(219, 18, 18, 0.1));">
        <h3 style="font-size: 1.8rem; margin-bottom: 20px;">Ready to grow your revenue?</h3>
        <a href="contact.php" style="color: var(--yellow); font-weight: 700; text-decoration: underline;">Talk to our experts for a custom plan →</a>
    </section>
</main>
<?php include 'includes/footer.php'; ?>