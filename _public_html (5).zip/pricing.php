<?php
// pricing.php — BULKSMSINDIA.COM | International SMS Pricing Calculator
// Per-SMS prices in INR. Exchange rates (March 2026):
// 1 INR = 0.01026 EUR | 0.01108 USD | 0.00872 GBP | 0.04073 AED

$countries = [
  ["Afghanistan",30.352],["Åland Islands",10.040],["Albania",9.469],["Algeria",24.024],
  ["American Samoa",17.696],["Andorra",10.618],["Angola",12.087],["Anguilla",13.600],
  ["Antigua & Barbuda",21.193],["Argentina",7.615],["Armenia",16.302],["Aruba",25.386],
  ["Australia",4.612],["Austria",7.239],["Azerbaijan",32.711],["Bahamas",4.934],
  ["Bahrain",2.703],["Bangladesh",31.532],["Barbados",25.386],["Belarus",20.581],
  ["Belgium",9.931],["Belize",23.938],["Benin",21.310],["Bermuda",25.386],
  ["Bhutan",31.532],["Bolivia",18.876],["Bosnia & Herzegovina",34.963],["Botswana",7.744],
  ["Bouvet Island",1.019],["Brazil",2.038],["British Indian Ocean Territory",10.040],
  ["British Virgin Islands",25.386],["Brunei",5.802],["Bulgaria",13.696],
  ["Burkina Faso",16.731],["Burundi",31.961],["Cambodia",32.711],["Cameroon",20.624],
  ["Canada",1.158],["Cape Verde",19.520],["Caribbean Netherlands",10.040],
  ["Cayman Islands",25.386],["Central African Republic",31.424],["Chad",26.072],
  ["Chile",4.279],["China",3.164],["Colombia",3.754],["Comoros",22.964],
  ["Congo - Brazzaville",25.526],["Congo - Kinshasa",20.849],["Cook Islands",13.127],
  ["Costa Rica",3.368],["Côte d'Ivoire",32.711],["Croatia",8.473],["Cyprus",6.574],
  ["Czechia",4.998],["Denmark",5.180],["Djibouti",15.272],["Dominica",14.425],
  ["Dominican Republic",8.312],["Ecuador",19.949],["Egypt",31.424],["El Salvador",20.498],
  ["Equatorial Guinea",20.914],["Eritrea",10.221],["Estonia",7.186],["Eswatini",21.922],
  ["Ethiopia",30.888],["Falkland Islands",8.044],["Faroe Islands",6.564],["Fiji",16.270],
  ["Finland",7.079],["France",6.135],["French Guiana",13.406],["French Polynesia",13.245],
  ["Gabon",24.775],["Gambia",20.839],["Georgia",14.532],["Germany",9.148],
  ["Ghana",28.100],["Gibraltar",10.296],["Greece",4.815],["Greenland",3.057],
  ["Grenada",21.986],["Guadeloupe",12.902],["Guam",5.395],["Guatemala",20.120],
  ["Guernsey",10.040],["Guinea",25.740],["Guinea-Bissau",31.210],["Guyana",15.347],
  ["Haiti",26.684],["Heard & McDonald Islands",10.040],["Honduras",22.201],
  ["Hong Kong SAR China",5.255],["Hungary",6.639],["Iceland",6.671],["India",6.221],
  ["Indonesia",37.966],["Iraq",31.961],["Ireland",5.706],["Isle of Man",10.040],
  ["Israel",20.807],["Italy",7.561],["Jamaica",25.386],["Japan",6.896],
  ["Jersey",10.040],["Jordan",25.204],["Kazakhstan",25.954],["Kenya",13.288],
  ["Kiribati",13.621],["Kuwait",26.169],["Kyrgyzstan",22.201],["Laos",19.284],
  ["Latvia",5.684],["Lebanon",31.521],["Lesotho",23.059],["Liberia",20.495],
  ["Libya",31.854],["Liechtenstein",3.432],["Lithuania",4.183],["Luxembourg",6.907],
  ["Macao SAR China",2.553],["Madagascar",35.028],["Malawi",30.137],["Malaysia",21.343],
  ["Maldives",2.874],["Mali",28.743],["Malta",8.237],["Marshall Islands",14.468],
  ["Martinique",11.690],["Mauritania",24.346],["Mauritius",15.519],["Mayotte",10.040],
  ["Mexico",11.433],["Micronesia",6.221],["Moldova",10.939],["Monaco",15.712],
  ["Mongolia",26.169],["Montenegro",14.286],["Montserrat",18.801],["Morocco",19.444],
  ["Mozambique",30.459],["Myanmar (Burma)",26.619],["Namibia",4.826],["Nauru",25.386],
  ["Nepal",26.062],["Netherlands",8.923],["New Caledonia",11.926],["New Zealand",7.744],
  ["Nicaragua",13.213],["Niger",29.182],["Nigeria",28.743],["Niue",23.209],
  ["Norfolk Island",10.040],["North Macedonia",10.403],["Northern Mariana Islands",10.040],
  ["Norway",5.523],["Oman",16.806],["Pakistan",38.932],["Palau",9.395],
  ["Palestinian Territories",10.040],["Panama",15.659],["Papua New Guinea",25.386],
  ["Paraguay",10.511],["Peru",18.211],["Philippines",18.340],["Pitcairn Islands",10.040],
  ["Poland",3.368],["Portugal",4.076],["Puerto Rico",3.368],["Qatar",20.498],
  ["Réunion",13.085],["Romania",5.813],["Russia",41.828],["Rwanda",23.724],
  ["Samoa",25.386],["San Marino",7.036],["São Tomé & Príncipe",7.443],
  ["Saudi Arabia",12.623],["Senegal",31.210],["Serbia",28.100],["Seychelles",21.343],
  ["Sierra Leone",35.285],["Singapore",3.486],["Sint Maarten",10.040],["Slovakia",7.400],
  ["Slovenia",17.589],["Solomon Islands",10.296],["Somalia",23.595],["South Africa",1.180],
  ["South Korea",3.872],["South Sudan",21.321],["Spain",4.826],["Sri Lanka",31.724],
  ["St. Helena",10.040],["St. Kitts & Nevis",25.386],["St. Lucia",25.386],
  ["St. Martin",10.040],["St. Pierre & Miquelon",9.653],["St. Vincent & Grenadines",21.021],
  ["Suriname",25.386],["Svalbard & Jan Mayen",10.040],["Sweden",4.097],
  ["Switzerland",5.609],["Tajikistan",41.184],["Tanzania",27.242],["Thailand",2.241],
  ["Timor-Leste",15.873],["Togo",35.929],["Tokelau",10.040],["Tonga",25.386],
  ["Trinidad & Tobago",25.386],["Tunisia",30.674],["Turkey",2.241],
  ["Turkmenistan",29.816],["Turks & Caicos Islands",23.059],["Tuvalu",9.684],
  ["U.S. Virgin Islands",10.040],["Uganda",27.799],["Ukraine",12.334],
  ["United Arab Emirates",9.781],["United Kingdom",4.676],["United States",0.901],
  ["Uruguay",7.293],["Uzbekistan",30.169],["Vanuatu",25.386],["Vatican City",10.040],
  ["Venezuela",14.060],["Vietnam",14.586],["Wallis & Futuna",8.151],
  ["Zambia",26.577],["Zimbabwe",12.441]
];

// Build JSON for JS
$js_countries = json_encode($countries);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>SMS Pricing Calculator — All Countries | BulkSMSIndia.com</title>
<meta name="description" content="Calculate exact SMS costs per country. Real-time pricing in INR, USD, GBP, EUR, AED for 233 countries. From 200 to 20 lakh SMS.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
<style>
/* ── INDIAN COLOR SCHEME ── */
:root{
  --navy:#0a1929;--navy2:#0d1f2d;--blue:#1565c0;--blue2:#0d47a1;--blue3:#42a5f5;
  --orange:#ff6f00;--orange2:#e65100;--green:#2e7d32;--text:#e3f2fd;--muted:#90caf9;--dim:#64b5f6;
  --border:rgba(66,165,245,.15);--card:rgba(66,165,245,.08);--surface:#112240;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:'Inter',sans-serif;background:var(--navy);color:var(--text);min-height:100vh;display:flex;flex-direction:column;-webkit-font-smoothing:antialiased}
a{color:inherit;text-decoration:none}
img{max-width:100%}

/* ══ TOP ANNOUNCEMENT BAR ══ */
.top-bar{
  background:linear-gradient(90deg,var(--orange),var(--blue),var(--orange));
  background-size:300% auto;animation:barShimmer 5s linear infinite;
  text-align:center;padding:8px 16px;
  font-size:.73rem;font-weight:600;color:#fff;letter-spacing:.3px;
}
.top-bar .live-dot{display:inline-block;width:7px;height:7px;border-radius:50%;background:#4eff91;margin-right:7px;vertical-align:middle;animation:livePulse 1.6s ease-in-out infinite}
@keyframes barShimmer{to{background-position:300% center}}
@keyframes livePulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.35;transform:scale(.7)}}

/* ══ NAVIGATION ══ */
.site-nav{background:rgba(10,25,41,.96);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-bottom:1px solid var(--border);position:sticky;top:0;z-index:500}
.nav-wrap{max-width:1320px;margin:0 auto;padding:0 28px;height:66px;display:flex;align-items:center;gap:6px}
.nav-logo{display:flex;align-items:center;gap:10px;margin-right:24px;flex-shrink:0}
.logo-box{width:38px;height:38px;background:linear-gradient(135deg,var(--orange),var(--blue));border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:1.15rem;font-weight:900;color:#fff;flex-shrink:0;box-shadow:0 4px 14px rgba(255,111,0,.4)}
.logo-name{font-size:1.05rem;font-weight:800;color:#fff;letter-spacing:-.3px}.logo-name em{color:var(--orange);font-style:normal}
.nav-menu{display:flex;align-items:center;gap:1px;flex:1}
.nm-item{position:relative}
.nm-link{display:flex;align-items:center;gap:4px;padding:8px 12px;font-size:.82rem;font-weight:500;color:var(--muted);border-radius:7px;transition:color .15s,background .15s;cursor:pointer;white-space:nowrap}
.nm-link:hover,.nm-link.cur{color:#fff;background:var(--card)}
.nm-link.cur{color:var(--orange)}
.nm-chev{font-size:.58rem;opacity:.55}
.nm-drop{position:absolute;top:calc(100% + 8px);left:0;background:#0d1f2d;border:1px solid var(--border);border-radius:11px;padding:8px;min-width:210px;box-shadow:0 24px 48px rgba(0,0,0,.55);opacity:0;visibility:hidden;transform:translateY(-8px);transition:all .16s;z-index:600}
.nm-item:hover .nm-drop{opacity:1;visibility:visible;transform:translateY(0)}
.nm-drop a{display:block;padding:8px 12px;font-size:.81rem;color:var(--muted);border-radius:7px;transition:color .12s,background .12s}
.nm-drop a:hover{color:#fff;background:var(--card)}
.nm-drop .d-title{padding:9px 12px 3px;font-size:.68rem;font-weight:700;text-transform:uppercase;letter-spacing:.9px;color:var(--dim)}
.nm-drop .d-sep{border:none;border-top:1px solid var(--border);margin:6px 0}
.nav-end{display:flex;align-items:center;gap:9px;margin-left:auto;flex-shrink:0}
.btn-login{padding:7px 17px;font-size:.81rem;font-weight:600;color:var(--muted);border:1px solid var(--border);border-radius:8px;transition:all .15s}
.btn-login:hover{color:#fff;border-color:rgba(66,165,245,.3)}
.btn-demo{padding:8px 19px;font-size:.81rem;font-weight:700;color:#fff;background:linear-gradient(135deg,var(--orange),var(--orange2));border-radius:8px;box-shadow:0 4px 16px rgba(255,111,0,.38);transition:transform .15s,opacity .15s}
.btn-demo:hover{transform:translateY(-1px);opacity:.9}

/* ══ HERO ══ */
.hero{
  background:radial-gradient(ellipse 90% 70% at 50% -10%,rgba(21,101,192,.18) 0%,transparent 65%),
             linear-gradient(180deg,#0a1929 0%,#0d1f2d 100%);
  padding:60px 28px 50px;text-align:center;border-bottom:1px solid var(--border);position:relative;overflow:hidden
}
.hero::after{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%231565c0' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");pointer-events:none}
.hero-pill{display:inline-flex;align-items:center;gap:8px;background:rgba(255,111,0,.12);border:1px solid rgba(255,111,0,.3);border-radius:20px;padding:5px 16px;font-size:.73rem;font-weight:700;color:var(--orange);margin-bottom:20px;letter-spacing:.4px;text-transform:uppercase}
.hero h1{font-size:clamp(1.7rem,3.5vw,2.7rem);font-weight:900;color:#fff;letter-spacing:-.6px;line-height:1.15;margin-bottom:13px}
.hero h1 span{background:linear-gradient(90deg,var(--orange),var(--blue3));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.hero p{font-size:.96rem;color:var(--muted);max-width:540px;margin:0 auto 30px;line-height:1.7}
.hero-stats{display:flex;justify-content:center;flex-wrap:wrap;gap:28px}
.hstat strong{display:block;font-size:1.3rem;font-weight:800;color:#fff}
.hstat small{font-size:.7rem;color:var(--muted);text-transform:uppercase;letter-spacing:.5px}

/* ══ MAIN CALCULATOR CARD ══ */
.calc-wrap{max-width:860px;margin:0 auto;width:100%;padding:36px 24px 52px}
.calc-card{
  background:linear-gradient(160deg,rgba(66,165,245,.08) 0%,rgba(21,101,192,.04) 100%);
  border:1px solid var(--border);border-radius:20px;
  box-shadow:0 8px 40px rgba(0,0,0,.3),inset 0 1px 0 rgba(66,165,245,.1);
  overflow:hidden;
}
.calc-head{
  background:linear-gradient(135deg,rgba(21,101,192,.15),rgba(255,111,0,.08));
  border-bottom:1px solid var(--border);
  padding:24px 32px 22px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px
}
.calc-head-left h2{font-size:1.05rem;font-weight:700;color:#fff;margin-bottom:3px}
.calc-head-left p{font-size:.8rem;color:var(--muted)}
.calc-badge{display:flex;align-items:center;gap:7px;background:rgba(255,111,0,.08);border:1px solid rgba(255,111,0,.25);border-radius:20px;padding:5px 14px;font-size:.74rem;font-weight:700;color:var(--orange)}
.calc-badge .dot{width:7px;height:7px;border-radius:50%;background:var(--orange);animation:livePulse 1.6s infinite}
.calc-body{padding:28px 32px}

/* ── Country search bar ── */
.field-group{margin-bottom:26px}
.field-label{display:block;font-size:.77rem;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);margin-bottom:9px}

.country-search-wrap{position:relative}
.country-search-wrap .cs-icon{
  position:absolute;left:13px;top:50%;transform:translateY(-50%);
  font-size:.85rem;color:var(--muted);pointer-events:none;line-height:1;z-index:2
}
#countrySearchInput{
  width:100%;padding:12px 38px 12px 36px;
  background:rgba(66,165,245,.05);border:1px solid var(--border);
  border-radius:10px 10px 0 0;font-size:.9rem;color:#fff;
  font-family:'Inter',sans-serif;outline:none;
  transition:border-color .15s,background .15s;
}
#countrySearchInput::placeholder{color:var(--muted)}
#countrySearchInput:focus{border-color:var(--blue3);background:rgba(66,165,245,.08)}
.cs-clear{
  position:absolute;right:12px;top:50%;transform:translateY(-50%);
  background:none;border:none;color:var(--muted);cursor:pointer;
  font-size:1rem;line-height:1;padding:2px 4px;display:none;
  transition:color .12s
}
.cs-clear:hover{color:#fff}
#countrySearchInput:not(:placeholder-shown) ~ .cs-clear{display:block}

/* Dropdown list */
#countryDropdown{
  position:absolute;top:100%;left:0;right:0;z-index:400;
  background:#0d1f2d;border:1px solid var(--border);border-top:none;
  border-radius:0 0 10px 10px;
  max-height:260px;overflow-y:auto;
  display:none;
  box-shadow:0 16px 40px rgba(0,0,0,.5)
}
#countryDropdown.open{display:block}
#countryDropdown::-webkit-scrollbar{width:5px}
#countryDropdown::-webkit-scrollbar-track{background:transparent}
#countryDropdown::-webkit-scrollbar-thumb{background:rgba(66,165,245,.2);border-radius:3px}
.cd-item{
  display:flex;align-items:center;justify-content:space-between;
  padding:10px 14px;cursor:pointer;font-size:.86rem;
  border-bottom:1px solid rgba(66,165,245,.04);
  transition:background .1s;
}
.cd-item:last-child{border-bottom:none}
.cd-item:hover,.cd-item.active{background:rgba(21,101,192,.12)}
.cd-name{color:#fff;font-weight:500}
.cd-name mark{background:transparent;color:var(--orange);font-weight:700}
.cd-rate{color:var(--muted);font-size:.78rem;font-family:'Courier New',monospace;white-space:nowrap;margin-left:10px}
.cd-empty{padding:16px 14px;text-align:center;color:var(--muted);font-size:.83rem}

/* Hidden real select (drives updateCalc) */
#countrySelect{display:none}

/* When search has focus, show border on input only, let dropdown continue */
.country-search-wrap:focus-within #countrySearchInput{
  border-radius:10px 10px 0 0;
}

/* Rate display */
.rate-bar{
  display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;
  background:rgba(21,101,192,.08);border:1px solid rgba(21,101,192,.2);
  border-radius:10px;padding:12px 16px;margin-bottom:26px
}
.rate-item{text-align:center}
.rate-item .r-label{font-size:.69rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px;color:var(--muted);margin-bottom:3px}
.rate-item .r-val{font-size:.96rem;font-weight:800;color:#fff}
.rate-item .r-val.orange{color:var(--orange)}
.rate-sep{width:1px;height:36px;background:var(--border)}

/* Slider */
.slider-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:10px}
.slider-header .field-label{margin-bottom:0}
.credits-pill{
  background:linear-gradient(135deg,var(--orange),var(--blue));
  border-radius:20px;padding:5px 16px;
  font-size:.85rem;font-weight:800;color:#fff;
  letter-spacing:-.2px;white-space:nowrap
}
.slider-track{position:relative;padding:10px 0 6px}
input[type=range].sms-slider{
  -webkit-appearance:none;width:100%;height:6px;
  background:linear-gradient(90deg,var(--blue) var(--pct,2%),rgba(66,165,245,.15) var(--pct,2%));
  border-radius:3px;outline:none;cursor:pointer;
}
input[type=range].sms-slider::-webkit-slider-thumb{
  -webkit-appearance:none;width:22px;height:22px;border-radius:50%;
  background:linear-gradient(135deg,var(--orange),var(--blue));
  border:3px solid #fff;box-shadow:0 2px 8px rgba(21,101,192,.5);cursor:pointer;
  transition:transform .12s
}
input[type=range].sms-slider::-webkit-slider-thumb:hover{transform:scale(1.15)}
input[type=range].sms-slider::-moz-range-thumb{width:22px;height:22px;border-radius:50%;background:linear-gradient(135deg,var(--orange),var(--blue));border:3px solid #fff;cursor:pointer}
.slider-marks{display:flex;justify-content:space-between;padding:0 2px;margin-top:2px}
.slider-marks span{font-size:.63rem;color:var(--dim);text-align:center}

/* Currency tabs */
.cur-row{display:flex;gap:7px;flex-wrap:wrap;margin:24px 0 22px}
.cur-tab{
  padding:8px 18px;background:rgba(66,165,245,.05);
  border:1px solid var(--border);border-radius:20px;
  font-size:.82rem;font-weight:700;color:var(--muted);cursor:pointer;
  transition:all .15s;font-family:'Inter',sans-serif
}
.cur-tab:hover{border-color:var(--blue3);color:#fff}
.cur-tab.active{background:var(--orange);border-color:var(--orange);color:#fff;box-shadow:0 4px 14px rgba(255,111,0,.4)}

/* Results panel */
.results{
  display:grid;grid-template-columns:1fr 1px 1fr 1px 1fr;
  background:linear-gradient(135deg,rgba(21,101,192,.1),rgba(255,111,0,.06));
  border:1px solid rgba(21,101,192,.25);border-radius:14px;
  overflow:hidden;
}
.res-col{padding:20px 16px;text-align:center}
.res-divider{background:var(--border);width:1px}
.res-label{font-size:.7rem;font-weight:700;text-transform:uppercase;letter-spacing:.7px;color:var(--muted);margin-bottom:6px}
.res-val{font-size:1.65rem;font-weight:900;color:#fff;letter-spacing:-.5px;line-height:1}
.res-val.accent{color:var(--orange)}
.res-val.big{font-size:1.45rem}
.res-sub{font-size:.73rem;color:var(--muted);margin-top:4px}

/* Summary text */
.calc-summary{
  margin-top:18px;
  padding:14px 18px;
  background:rgba(66,165,245,.03);
  border:1px solid var(--border);
  border-radius:10px;
  font-size:.84rem;
  color:var(--muted);
  line-height:1.6
}
.calc-summary strong{color:#fff}
.calc-summary .formula{
  margin-top:8px;font-size:.78rem;
  font-family:'Courier New',monospace;
  color:var(--orange);
  padding:6px 10px;background:rgba(255,111,0,.06);border-radius:6px;display:inline-block
}

/* Enterprise CTA inside card */
.ent-cta{
  margin-top:24px;
  border-top:1px solid var(--border);
  padding-top:22px;
  display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px
}
.ent-cta-text h3{font-size:.92rem;font-weight:700;color:#fff;margin-bottom:3px}
.ent-cta-text p{font-size:.78rem;color:var(--muted)}
.ent-cta-btns{display:flex;gap:9px;flex-wrap:wrap}
.btn-cta-primary{padding:9px 22px;background:linear-gradient(135deg,var(--orange),var(--orange2));color:#fff;font-size:.82rem;font-weight:700;border-radius:8px;transition:transform .15s,opacity .15s;box-shadow:0 4px 14px rgba(255,111,0,.35)}
.btn-cta-primary:hover{transform:translateY(-1px);opacity:.9}
.btn-cta-ghost{padding:9px 20px;border:1px solid var(--border);color:var(--muted);font-size:.82rem;font-weight:600;border-radius:8px;transition:all .15s}
.btn-cta-ghost:hover{border-color:rgba(66,165,245,.3);color:#fff}

/* ══ FULL COUNTRY TABLE ══ */
.table-section{max-width:1200px;margin:0 auto;width:100%;padding:0 24px 60px}
.section-head{text-align:center;margin-bottom:28px}
.section-head h2{font-size:1.4rem;font-weight:800;color:#fff;margin-bottom:6px}
.section-head p{font-size:.86rem;color:var(--muted)}
.table-controls{display:flex;flex-wrap:wrap;align-items:center;gap:12px;margin-bottom:16px}
.tbl-search{position:relative;flex:1 1 240px;max-width:320px}
.tbl-search input{width:100%;padding:9px 12px 9px 36px;background:var(--card);border:1px solid var(--border);border-radius:9px;font-size:.84rem;color:#fff;font-family:'Inter',sans-serif;outline:none;transition:border-color .15s}
.tbl-search input::placeholder{color:var(--muted)}
.tbl-search input:focus{border-color:var(--blue3)}
.tbl-search .si{position:absolute;left:11px;top:50%;transform:translateY(-50%);color:var(--muted);font-size:.85rem}
.tbl-cur-tabs{display:flex;gap:6px;flex-wrap:wrap}
.tbl-cur{padding:7px 15px;background:var(--card);border:1px solid var(--border);border-radius:20px;font-size:.78rem;font-weight:600;color:var(--muted);cursor:pointer;transition:all .15s;font-family:'Inter',sans-serif}
.tbl-cur:hover{border-color:var(--blue3);color:#fff}
.tbl-cur.active{background:var(--orange);border-color:var(--orange);color:#fff}
.tbl-count{margin-left:auto;font-size:.77rem;color:var(--muted);background:var(--card);border:1px solid var(--border);border-radius:20px;padding:5px 13px;white-space:nowrap}
.tbl-wrap{border:1px solid var(--border);border-radius:14px;overflow:hidden;overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.84rem}
thead tr{background:#0d1f2d}
thead th{padding:13px 18px;text-align:left;font-size:.71rem;font-weight:700;text-transform:uppercase;letter-spacing:.65px;color:var(--muted);white-space:nowrap;cursor:pointer;user-select:none;transition:color .14s}
thead th:hover{color:#fff}
thead th.sa::after{content:' ↑';color:var(--orange)}
thead th.sd::after{content:' ↓';color:var(--orange)}
tbody tr{border-bottom:1px solid rgba(66,165,245,.035);transition:background .1s}
tbody tr:last-child{border-bottom:none}
tbody tr:nth-child(even){background:rgba(21,101,192,.03)}
tbody tr:hover{background:rgba(21,101,192,.09)}
td{padding:10px 18px;white-space:nowrap}
td.num{color:var(--dim);font-size:.75rem;width:44px}
td.cname{font-weight:500;color:#fff;white-space:normal;min-width:150px}
td.price{font-family:'Courier New',monospace;font-size:.83rem;text-align:right}
td.price.hi{color:var(--orange);font-weight:700}
.no-rows{text-align:center;padding:52px 20px;color:var(--muted)}

/* ══ CTA STRIP ══ */
.cta-strip{background:linear-gradient(135deg,#0d1f2d 0%,#112240 100%);border-top:1px solid var(--border);border-bottom:1px solid var(--border);padding:52px 28px;text-align:center}
.cta-strip h2{font-size:1.5rem;font-weight:800;color:#fff;margin-bottom:9px}
.cta-strip p{color:var(--muted);font-size:.9rem;margin-bottom:26px}
.cta-btns{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}
.cbtn-p{padding:12px 30px;background:linear-gradient(135deg,var(--orange),var(--orange2));color:#fff;font-weight:700;font-size:.88rem;border-radius:9px;box-shadow:0 6px 22px rgba(255,111,0,.4);transition:transform .14s,opacity .14s}
.cbtn-p:hover{transform:translateY(-2px);opacity:.9}
.cbtn-g{padding:12px 28px;border:1px solid var(--border);color:var(--muted);font-weight:600;font-size:.88rem;border-radius:9px;transition:all .14s}
.cbtn-g:hover{border-color:rgba(66,165,245,.3);color:#fff}

/* ══ FOOTER ══ */
.site-footer{background:#0a1929;border-top:1px solid var(--border);padding:56px 28px 0}
.ft-inner{max-width:1320px;margin:0 auto}
.ft-grid{display:grid;grid-template-columns:270px repeat(4,1fr);gap:44px;padding-bottom:48px;border-bottom:1px solid var(--border)}
.ft-brand .fl{display:flex;align-items:center;gap:10px;margin-bottom:15px}
.ft-brand p{font-size:.8rem;color:var(--muted);line-height:1.75;margin-bottom:18px}
.ft-socials{display:flex;gap:8px}
.ft-soc{width:34px;height:34px;background:var(--card);border:1px solid var(--border);border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:.84rem;transition:all .14s}
.ft-soc:hover{border-color:var(--blue3);background:rgba(21,101,192,.15)}
.ft-col h4{font-size:.73rem;font-weight:800;text-transform:uppercase;letter-spacing:.8px;color:#fff;margin-bottom:15px}
.ft-col ul{list-style:none}
.ft-col ul li{margin-bottom:9px}
.ft-col ul li a{font-size:.8rem;color:var(--muted);transition:color .12s}
.ft-col ul li a:hover{color:var(--orange)}
.ft-col ul hr{border:none;border-top:1px solid var(--border);margin:10px 0}
.ft-bottom{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px;padding:18px 0}
.ft-copy{font-size:.76rem;color:var(--muted)}
.ft-badges{display:flex;gap:7px;flex-wrap:wrap}
.fbadge{padding:4px 11px;background:var(--card);border:1px solid var(--border);border-radius:20px;font-size:.68rem;font-weight:700;color:var(--muted);letter-spacing:.3px}
.fbadge.g{border-color:rgba(46,125,50,.3);color:var(--green)}

/* ══ RESPONSIVE ══ */
@media(max-width:1100px){.nav-menu{display:none}.ft-grid{grid-template-columns:1fr 1fr}.ft-brand{grid-column:1/-1}}
@media(max-width:700px){.results{grid-template-columns:1fr;grid-template-rows:auto}.res-divider{height:1px;width:auto}.calc-body{padding:20px 18px}.ft-grid{grid-template-columns:1fr}.hero-stats{gap:18px}}
@media(max-width:480px){.cur-row{gap:5px}.cur-tab{padding:7px 13px;font-size:.77rem}.calc-head{padding:18px 18px 16px}.credits-pill{font-size:.78rem}}
</style>
</head>
<body>

<!-- ══ TOP BAR ══ -->
<div class="top-bar">
  <span class="live-dot"></span>
  Live · Trusted in India · 99.9% Uptime · 230+ Countries · Since 2002
</div>

<!-- ══ NAVIGATION ══ -->
<nav class="site-nav">
  <div class="nav-wrap">
    <a href="https://bulksmsindia.com/" class="nav-logo">
      <div class="logo-name">BulkSMS<em>India</em></div>
    </a>
    
    <div class="nav-menu">
      <div class="nm-item">
        <span class="nm-link">Bulk SMS <span class="nm-chev">▾</span></span>
        <div class="nm-drop">
          <a href="https://bulksmsindia.com/promotional-bulksms.php">Promotional SMS</a>
          <a href="https://bulksmsindia.com/transactional-bulksms.php">Transactional SMS</a>
          <a href="https://bulksmsindia.com/twoway-bulksms-services.php">TWO WAY SMS</a>
          <a href="https://bulksmsindia.com/dlt-registration.php">DLT Registration</a>
        </div>
      </div>

      <div class="nm-item">
        <span class="nm-link">WhatsApp <span class="nm-chev">▾</span></span>
        <div class="nm-drop">
          <a href="https://bulksmsindia.com/bulk-whatsapp.php">Bulk WhatsApp</a>
          <a href="https://bulksmsindia.com/whatsapp-business-api-meta.php">WhatsApp Business API</a>
          <a href="https://bulksmsindia.com/unlimited-whatsapp.php">Unlimited WhatsApp</a>
        </div>
      </div>

      <div class="nm-item">
        <span class="nm-link">Voice <span class="nm-chev">▾</span></span>
        <div class="nm-drop">
          <a href="https://bulksmsindia.com/voicebroadcasting.php">Voice Broadcasting</a>
          <a href="https://bulksmsindia.com/ivr.php">IVR</a>
          <a href="https://bulksmsindia.com/voip.php">VoIP Services</a>
          <a href="https://bulksmsindia.com/voiceqos.php">Voice QoS</a>
          <a href="https://bulksmsindia.com/siptrunk.php">SIP Trunk / TDM</a>
          <a href="https://bulksmsindia.com/didnumbers.php">DID / Toll Free</a>
        </div>
      </div>

      <div class="nm-item">
        <span class="nm-link">AI Automation <span class="nm-chev">▾</span></span>
        <div class="nm-drop">
          <a href="https://bulksmsindia.com/ai-agents.php">AI Agents</a>
          <a href="https://bulksmsindia.com/ai-chatbots.php">AI Chatbots</a>
          <a href="https://bulksmsindia.com/ai-tools.php">AI Tools</a>
        </div>
      </div>
    </div> <div class="nav-end">
      <a href="login.php" class="btn-login">Log in</a>
      <a href="signup.php" class="btn-demo">Sign Up</a>
    </div>
  </div> </nav>
<!-- ══ HERO ══ -->
<section class="hero">
  <div class="hero-pill">🇮🇳 Made in India Pricing</div>
  <h1>Calculate Your <span>SMS Cost</span><br>For Any Country</h1>
  <p>Real-time pricing across 233 countries. Select your destination, drag the slider — see exact costs in INR, USD, GBP, EUR or AED instantly.</p>
  <div class="hero-stats">
    <div class="hstat"><strong>233</strong><small>Countries</small></div>
    <div class="hstat"><strong>200 – 20L</strong><small>SMS Range</small></div>
    <div class="hstat"><strong>5</strong><small>Currencies</small></div>
    <div class="hstat"><strong>99.9%</strong><small>Uptime SLA</small></div>
  </div>
</section>

<!-- ══ CALCULATOR ══ -->
<div class="calc-wrap">
  <div class="calc-card">

    <div class="calc-head">
      <div class="calc-head-left">
        <h2>SMS Price Calculator</h2>
        <p>Select country · Drag slider · Switch currency</p>
      </div>
      <div class="calc-badge"><span class="dot"></span> Live Rates</div>
    </div>

    <div class="calc-body">

      <!-- ── Country search bar ── -->
      <div class="field-group">
        <label class="field-label" for="countrySearchInput">📍 Sending To (Destination Country)</label>
        <div class="country-search-wrap" id="csWrap">
          <span class="cs-icon">🔍</span>
          <input
            type="text"
            id="countrySearchInput"
            placeholder="Search country…"
            autocomplete="off"
            spellcheck="false"
          />
          <button class="cs-clear" id="csClear" tabindex="-1" title="Clear">✕</button>
          <div id="countryDropdown"></div>
        </div>
        <!-- Hidden real select that updateCalc() reads -->
        <select id="countrySelect" onchange="updateCalc()">
          <?php foreach($countries as $c): ?>
            <option value="<?= htmlspecialchars($c[0]) ?>" data-inr="<?= $c[1] ?>"
              <?= $c[0]==='India'?'selected':'' ?>>
              <?= htmlspecialchars($c[0]) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- Rate bar -->
      <div class="rate-bar" id="rateBar">
        <div class="rate-item">
          <div class="r-label">Rate / SMS (INR)</div>
          <div class="r-val orange" id="rb-inr">₹6.221</div>
        </div>
        <div class="rate-sep"></div>
        <div class="rate-item">
          <div class="r-label">Rate / SMS (USD)</div>
          <div class="r-val" id="rb-usd">$0.06893</div>
        </div>
        <div class="rate-sep"></div>
        <div class="rate-item">
          <div class="r-label">Rate / SMS (GBP)</div>
          <div class="r-val" id="rb-gbp">£0.05425</div>
        </div>
        <div class="rate-sep"></div>
        <div class="rate-item">
          <div class="r-label">Rate / SMS (EUR)</div>
          <div class="r-val" id="rb-eur">€0.06383</div>
        </div>
        <div class="rate-sep"></div>
        <div class="rate-item">
          <div class="r-label">Rate / SMS (AED)</div>
          <div class="r-val" id="rb-aed">د.إ 0.2534</div>
        </div>
      </div>

      <!-- Slider -->
      <div class="field-group" style="margin-bottom:10px">
        <div class="slider-header">
          <label class="field-label">✉️ Number of SMS</label>
          <div class="credits-pill" id="sliderLabel">200 SMS</div>
        </div>
        <div class="slider-track">
          <input type="range" class="sms-slider" id="smsSlider"
                 min="0" max="27" value="0"
                 oninput="updateCalc()" style="--pct:0%">
        </div>
        <div class="slider-marks">
          <span>200</span><span>1K</span><span>5K</span><span>10K</span>
          <span>50K</span><span>1L</span><span>5L</span><span>10L</span><span>20L</span>
        </div>
      </div>

      <!-- Currency tabs -->
      <div class="cur-row" id="curRow">
        <button class="cur-tab active" data-c="INR" onclick="setCur('INR',this)">₹ INR</button>
        <button class="cur-tab" data-c="USD" onclick="setCur('USD',this)">$ USD</button>
        <button class="cur-tab" data-c="GBP" onclick="setCur('GBP',this)">£ GBP</button>
        <button class="cur-tab" data-c="EUR" onclick="setCur('EUR',this)">€ EUR</button>
        <button class="cur-tab" data-c="AED" onclick="setCur('AED',this)">د.إ AED</button>
      </div>

      <!-- Results -->
      <div class="results">
        <div class="res-col">
          <div class="res-label">No. of SMS</div>
          <div class="res-val" id="r-sms">200</div>
          <div class="res-sub">messages</div>
        </div>
        <div class="res-divider"></div>
        <div class="res-col">
          <div class="res-label">Cost per SMS</div>
          <div class="res-val accent" id="r-cps">₹6.221</div>
          <div class="res-sub">per message</div>
        </div>
        <div class="res-divider"></div>
        <div class="res-col">
          <div class="res-label">Total Cost</div>
          <div class="res-val big" id="r-total">₹1,244.20</div>
          <div class="res-sub" id="r-cur-lbl">Indian rupees</div>
        </div>
      </div>

      <!-- Summary -->
      <div class="calc-summary" id="calcSummary">
        If you send <strong id="s-qty">200 SMS</strong> to <strong id="s-country">India</strong>,
        the total cost is <strong id="s-total">₹1,244.20</strong>.<br>
        <span class="formula" id="s-formula">200 × ₹6.221 = ₹1,244.20</span>
      </div>

      <!-- Enterprise CTA -->
      <div class="ent-cta">
        <div class="ent-cta-text">
          <h3>Enterprise &amp; Large Volume?</h3>
          <p>Custom SLA · Dedicated routes · DLT compliant · Tier-1 carriers</p>
        </div>
        <div class="ent-cta-btns">
          <a href="signup.php" class="btn-cta-primary">🚀 Sign Up</a>
          <a href="contact.php" class="btn-cta-ghost">Talk to Expert</a>
        </div>
      </div>

    </div><!-- /calc-body -->
  </div><!-- /calc-card -->
</div><!-- /calc-wrap -->

<!-- ══ FULL RATES TABLE ══ -->
<div class="table-section">
  <div class="section-head">
    <h2>Per-SMS Rates — All 233 Countries</h2>
    <p>Click any column header to sort. Switch currency above the table.</p>
  </div>
  <div class="table-controls">
    <div class="tbl-search">
      <span class="si">🔍</span>
      <input type="text" id="tblSearch" placeholder="Search country…" oninput="filterTbl()">
    </div>
    <div class="tbl-cur-tabs" id="tblCurTabs">
      <button class="tbl-cur active" onclick="tblCur('inr',this)">₹ INR</button>
      <button class="tbl-cur" onclick="tblCur('usd',this)">$ USD</button>
      <button class="tbl-cur" onclick="tblCur('gbp',this)">£ GBP</button>
      <button class="tbl-cur" onclick="tblCur('eur',this)">€ EUR</button>
      <button class="tbl-cur" onclick="tblCur('aed',this)">د.إ AED</button>
      <button class="tbl-cur" onclick="tblCur('all',this)">All</button>
    </div>
    <div class="tbl-count" id="tblCount">233 countries</div>
  </div>
  <div class="tbl-wrap">
    <table id="priceTbl">
      <thead>
        <tr>
          <th onclick="sortTbl(0)">#</th>
          <th onclick="sortTbl(1)">Country</th>
          <th class="tc-inr" onclick="sortTbl(2)">₹ INR / SMS</th>
          <th class="tc-usd" style="display:none" onclick="sortTbl(3)">$ USD / SMS</th>
          <th class="tc-gbp" style="display:none" onclick="sortTbl(4)">£ GBP / SMS</th>
          <th class="tc-eur" style="display:none" onclick="sortTbl(5)">€ EUR / SMS</th>
          <th class="tc-aed" style="display:none" onclick="sortTbl(6)">د.إ AED / SMS</th>
        </tr>
      </thead>
      <tbody id="tblBody">
        <?php
        $i=1;
        foreach($countries as $c){
          $inr=$c[1]; $name=htmlspecialchars($c[0]);
          $usd=round($inr*0.01108,5); $gbp=round($inr*0.00872,5);
          $eur=round($inr*0.01026,5); $aed=round($inr*0.04073,5);
          echo "<tr>";
          echo "<td class='num'>{$i}</td>";
          echo "<td class='cname'>{$name}</td>";
          echo "<td class='price tc-inr hi'>₹{$inr}</td>";
          echo "<td class='price tc-usd' style='display:none'>\${$usd}</td>";
          echo "<td class='price tc-gbp' style='display:none'>£{$gbp}</td>";
          echo "<td class='price tc-eur' style='display:none'>€{$eur}</td>";
          echo "<td class='price tc-aed' style='display:none'>د.إ {$aed}</td>";
          echo "</tr>";
          $i++;
        }
        ?>
      </tbody>
    </table>
    <div class="no-rows" id="noRows" style="display:none">🔍 No countries match your search.</div>
  </div>
  <p style="margin-top:12px;font-size:.72rem;color:var(--muted)">
    Rates (March 2026): 1 INR = $0.01108 USD · £0.00872 GBP · €0.01026 EUR · د.إ 0.04073 AED
  </p>
</div>

<!-- ══ CTA STRIP ══ -->
<section class="cta-strip">
  <h2>Ready to Launch Your Campaign?</h2>
  <p>Join 100,000+ Indian businesses. Live access in 30 minutes — no setup fees.</p>
  <div class="cta-btns">
    <a href="signup.php" class="cbtn-p">🚀 Sign Up</a>
    <a href="contact.php" class="cbtn-g">Talk to Expert</a>
  </div>
</section>

<!-- ══ FOOTER ══ -->
<footer class="site-footer">
  <div class="ft-inner">
    <div class="ft-grid">
      <div class="ft-brand">
        <div class="fl">
          <div class="logo-box">B</div>
          <div class="logo-name">BulkSMS<em>India</em></div>
        </div>
        <p>India's trusted bulk SMS platform. Connecting businesses with customers since 2002. DLT compliant, TRAI approved.</p>
      </div>
      <div class="ft-col">
        <h4>SMS Services</h4>
        <ul>
          <li><a href="https://bulksmsindia.com/promotional-sms.php">Promotional SMS</a></li>
          <li><a href="https://bulksmsindia.com/transactional-sms.php">Transactional SMS</a></li>
          <li><a href="https://bulksmsindia.com/otp-sms.php">OTP SMS</a></li>
          <li><a href="https://bulksmsindia.com/voice-sms.php">Voice SMS</a></li>
          <li><a href="https://bulksmsindia.com/dlt-registration.php">DLT Registration</a></li>
        </ul>
      </div>
      <div class="ft-col">
        <h4>WhatsApp &amp; IVR</h4>
        <ul>
          <li><a href="https://bulksmsindia.com/bulk-whatsapp.php">Bulk WhatsApp</a></li>
          <li><a href="https://bulksmsindia.com/whatsapp-business-api.php">WhatsApp Business API</a></li>
          <li><a href="https://bulksmsindia.com/ivr.php">IVR Services</a></li>
          <li><a href="https://bulksmsindia.com/toll-free.php">Toll Free Numbers</a></li>
          <li><a href="https://bulksmsindia.com/missed-call.php">Missed Call Service</a></li>
          <li><a href="https://bulksmsindia.com/virtual-number.php">Virtual Numbers</a></li>
        </ul>
      </div>
      <div class="ft-col">
        <h4>Solutions</h4>
        <ul>
          <li><a href="https://bulksmsindia.com/api.php">API Integration</a></li>
          <li><a href="https://bulksmsindia.com/reseller.php">Reseller Program</a></li>
          <li><a href="https://bulksmsindia.com/enterprise.php">Enterprise Solutions</a></li>
          <li><a href="https://bulksmsindia.com/education.php">Education Sector</a></li>
          <li><a href="https://bulksmsindia.com/ecommerce.php">E-commerce</a></li>
        </ul>
      </div>
      <div class="ft-col">
        <h4>Company</h4>
        <ul>
          <li><a href="https://bulksmsindia.com/about.php">About Us</a></li>
          <li><a href="https://bulksmsindia.com/pricing.php">Pricing</a></li>
          <li><a href="https://bulksmsindia.com/demo.php">Request Demo</a></li>
          <li><a href="https://bulksmsindia.com/contact.php">Contact Us</a></li>
          <hr>
          <li><a href="https://bulksmsindia.com/privacy.php">Privacy Policy</a></li>
          <li><a href="https://bulksmsindia.com/terms.php">Terms of Service</a></li>
        </ul>
      </div>
    </div>
    <div class="ft-bottom">
      <span class="ft-copy">© 2026 BulkSMSIndia.com. All rights reserved.</span>
      <div class="ft-badges">
        <span class="fbadge g">🇮🇳 Made in India</span>
        <span class="fbadge">DLT Compliant</span>
        <span class="fbadge">TRAI Approved</span>
        <span class="fbadge">ISO 27001</span>
      </div>
    </div>
  </div>
</footer>

<script>
// ── Exchange rates (INR base) ──
const FX = { INR:1, USD:0.01108, GBP:0.00872, EUR:0.01026, AED:0.04073 };
const CUR_SYM = { INR:'₹', USD:'$', GBP:'£', EUR:'€', AED:'د.إ ' };
const CUR_NAME = { INR:'Indian rupees', USD:'US dollars', GBP:'pounds sterling', EUR:'euros', AED:'UAE dirhams' };

// ── SMS slider steps ──
const SMS_STEPS = [
  200,300,500,750,
  1000,1500,2000,3000,5000,7500,
  10000,15000,20000,30000,50000,75000,
  100000,150000,200000,300000,500000,
  750000,1000000,1250000,1500000,1750000,2000000
];

let activeCur = 'INR';

// ── Country search bar logic ──
const allCountries = <?= $js_countries ?>;
const csInput   = document.getElementById('countrySearchInput');
const csDrop    = document.getElementById('countryDropdown');
const csClear   = document.getElementById('csClear');
const csWrap    = document.getElementById('csWrap');
const realSelect= document.getElementById('countrySelect');

// Set initial display value
csInput.value = realSelect.value;

function highlight(text, q) {
  if (!q) return text;
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return text;
  return text.slice(0,i) + '<mark>' + text.slice(i, i+q.length) + '</mark>' + text.slice(i+q.length);
}

function renderDrop(results, q) {
  if (!results.length) {
    csDrop.innerHTML = '<div class="cd-empty">No countries found for "' + q + '"</div>';
  } else {
    csDrop.innerHTML = results.map(c =>
      '<div class="cd-item" data-name="' + c[0].replace(/"/g,'&quot;') + '" data-inr="' + c[1] + '">' +
        '<span class="cd-name">' + highlight(c[0], q) + '</span>' +
        '<span class="cd-rate">₹' + c[1].toFixed(3) + '</span>' +
      '</div>'
    ).join('');
    csDrop.querySelectorAll('.cd-item').forEach(item => {
      item.addEventListener('mousedown', e => {
        e.preventDefault();
        selectCountry(item.dataset.name);
      });
    });
  }
  csDrop.classList.add('open');
}

function selectCountry(name) {
  csInput.value = name;
  // Sync hidden select
  for (let opt of realSelect.options) {
    if (opt.value === name) { opt.selected = true; break; }
  }
  closeDrop();
  updateCalc();
}

function closeDrop() {
  csDrop.classList.remove('open');
}

csInput.addEventListener('input', () => {
  const q = csInput.value.trim();
  csClear.style.display = q ? 'block' : 'none';
  if (!q) { closeDrop(); return; }
  const results = allCountries.filter(c =>
    c[0].toLowerCase().includes(q.toLowerCase())
  ).slice(0, 12);
  renderDrop(results, q);
});

csInput.addEventListener('focus', () => {
  const q = csInput.value.trim();
  if (q) {
    const results = allCountries.filter(c =>
      c[0].toLowerCase().includes(q.toLowerCase())
    ).slice(0, 12);
    renderDrop(results, q);
  }
});

csInput.addEventListener('blur', () => {
  setTimeout(closeDrop, 150);
  // If input doesn't match any country, revert to last valid selection
  const valid = allCountries.find(c => c[0].toLowerCase() === csInput.value.trim().toLowerCase());
  if (!valid) csInput.value = realSelect.value;
});

csInput.addEventListener('keydown', e => {
  if (e.key === 'Escape') { closeDrop(); csInput.blur(); }
  if (e.key === 'Enter') {
    const first = csDrop.querySelector('.cd-item');
    if (first) selectCountry(first.dataset.name);
  }
  if (e.key === 'ArrowDown') {
    const first = csDrop.querySelector('.cd-item');
    if (first) first.focus();
  }
});

csClear.addEventListener('click', () => {
  csInput.value = '';
  csClear.style.display = 'none';
  closeDrop();
  csInput.focus();
});

document.addEventListener('click', e => {
  if (!csWrap.contains(e.target)) closeDrop();
});

// ── Calculator ──
function fmtNum(n){
  if(n>=100000) return (n/100000).toFixed(n%100000===0?0:2)+' L';
  if(n>=1000)   return (n/1000).toFixed(n%1000===0?0:1)+'K';
  return n.toString();
}

function getRate(){
  const sel = document.getElementById('countrySelect');
  return parseFloat(sel.options[sel.selectedIndex].dataset.inr);
}

function updateCalc(){
  const slider = document.getElementById('smsSlider');
  const idx = parseInt(slider.value);
  const qty = SMS_STEPS[idx];
  const rateINR = getRate();
  const countryName = document.getElementById('countrySelect').value;

  // Sync search input display
  csInput.value = countryName;

  const pct = (idx / (SMS_STEPS.length-1) * 100).toFixed(1);
  slider.style.setProperty('--pct', pct+'%');
  document.getElementById('sliderLabel').textContent = qty.toLocaleString() + ' SMS';

  document.getElementById('rb-inr').textContent = '₹' + rateINR.toFixed(3);
  document.getElementById('rb-usd').textContent = '$' + (rateINR*0.01108).toFixed(5);
  document.getElementById('rb-gbp').textContent = '£' + (rateINR*0.00872).toFixed(5);
  document.getElementById('rb-eur').textContent = '€' + (rateINR*0.01026).toFixed(5);
  document.getElementById('rb-aed').textContent = 'د.إ ' + (rateINR*0.04073).toFixed(4);

  const rateC = rateINR * FX[activeCur];
  const total = rateC * qty;
  const sym = CUR_SYM[activeCur];

  document.getElementById('r-sms').textContent = qty.toLocaleString();
  document.getElementById('r-cps').textContent = sym + rateC.toFixed(activeCur==='INR'?3:5);
  document.getElementById('r-total').textContent = sym + total.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
  document.getElementById('r-cur-lbl').textContent = CUR_NAME[activeCur];

  const qtyFmt = qty.toLocaleString();
  const totalFmt = sym + total.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});
  document.getElementById('s-qty').textContent = qtyFmt + ' SMS';
  document.getElementById('s-country').textContent = countryName;
  document.getElementById('s-total').textContent = totalFmt;
  document.getElementById('s-formula').textContent =
    qtyFmt + ' × ' + sym + rateC.toFixed(activeCur==='INR'?3:5) + ' = ' + totalFmt;
}

function setCur(c, btn){
  activeCur = c;
  document.querySelectorAll('.cur-tab').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  updateCalc();
}

// ── Table currency toggle ──
let tblActiveCur = 'inr';
function tblCur(c, btn){
  tblActiveCur = c;
  document.querySelectorAll('.tbl-cur').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  const cols = ['inr','usd','gbp','eur','aed'];
  cols.forEach(col=>{
    const show = (c==='all' || c===col);
    document.querySelectorAll('.tc-'+col).forEach(el=>el.style.display = show?'':'none');
  });
  document.querySelectorAll('td.price').forEach(el=>el.classList.remove('hi'));
  const hi = (c==='all')?'inr':c;
  document.querySelectorAll('td.tc-'+hi+'.price').forEach(el=>el.classList.add('hi'));
}

// ── Table search ──
function filterTbl(){
  const q = document.getElementById('tblSearch').value.toLowerCase();
  const rows = document.querySelectorAll('#tblBody tr');
  let n=0;
  rows.forEach(r=>{
    const show = r.cells[1].textContent.toLowerCase().includes(q);
    r.style.display = show?'':'none';
    if(show) r.cells[0].textContent = ++n;
  });
  document.getElementById('tblCount').textContent = n + ' countr'+(n===1?'y':'ies');
  document.getElementById('noRows').style.display = n===0?'':'none';
}

// ── Table sort ──
let sState={col:-1,asc:true};
function sortTbl(col){
  const tbody=document.getElementById('tblBody');
  const rows=Array.from(tbody.querySelectorAll('tr'));
  const asc = sState.col===col ? !sState.asc : true;
  sState={col,asc};
  rows.sort((a,b)=>{
    if(col<=1){
      return asc ? a.cells[col].textContent.trim().localeCompare(b.cells[col].textContent.trim())
                 : b.cells[col].textContent.trim().localeCompare(a.cells[col].textContent.trim());
    }
    const va=parseFloat(a.cells[col].textContent.replace(/[^0-9.]/g,''))||0;
    const vb=parseFloat(b.cells[col].textContent.replace(/[^0-9.]/g,''))||0;
    return asc?va-vb:vb-va;
  });
  rows.forEach((r,i)=>{r.cells[0].textContent=i+1;tbody.appendChild(r);});
  document.querySelectorAll('thead th').forEach((th,i)=>{
    th.classList.remove('sa','sd');
    if(i===col) th.classList.add(asc?'sa':'sd');
  });
}

// Init - default to India
updateCalc();
</script>
</body>
</html>