<?php include 'includes/header.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DLT Registration | BulkSMSIndia</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg-dark: #050a12;
            --card-bg: #0d141f;
            --accent-red: #d11a1a;
            --text-main: #ffffff;
            --text-muted: #a0a6b1;
            --border: rgba(255, 255, 255, 0.08);
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            color: var(--text-main);
            line-height: 1.6;
        }

        .container {
            max-width: 900px;
            margin: 80px auto;
            padding: 0 20px;
        }

        /* Header Section */
        .dlt-header {
            text-align: center;
            margin-bottom: 50px;
        }

        .dlt-header h1 {
            font-size: 2.8rem;
            font-weight: 800;
            margin-bottom: 15px;
        }

        .dlt-header h1 span {
            color: var(--accent-red);
        }

        .dlt-header p {
            color: var(--text-muted);
            font-size: 1.1rem;
            max-width: 600px;
            margin: 0 auto;
        }

        /* Steps Section */
        .dlt-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 50px;
        }

        .step-card {
            background: var(--card-bg);
            padding: 30px;
            border-radius: 15px;
            border: 1px solid var(--border);
            transition: 0.3s;
        }

        .step-card:hover {
            border-color: var(--accent-red);
            transform: translateY(-5px);
        }

        .step-num {
            background: var(--accent-red);
            width: 35px;
            height: 35px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-weight: 800;
            margin-bottom: 20px;
        }

        .step-card h3 {
            margin-bottom: 10px;
            font-size: 1.3rem;
        }

        /* Registration Form Section */
        .reg-box {
            background: var(--card-bg);
            padding: 40px;
            border-radius: 20px;
            border: 1px solid var(--border);
        }

        .reg-box h2 {
            margin-bottom: 30px;
            border-left: 4px solid var(--accent-red);
            padding-left: 15px;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            margin-bottom: 8px;
            font-size: 0.9rem;
            color: var(--text-muted);
        }

        .form-group input, .form-group select {
            padding: 12px;
            background: #161e2b;
            border: 1px solid var(--border);
            border-radius: 8px;
            color: white;
            outline: none;
        }

        .form-group input:focus {
            border-color: var(--accent-red);
        }

        .btn-submit {
            background: var(--accent-red);
            color: white;
            padding: 15px 40px;
            border: none;
            border-radius: 50px;
            font-weight: 700;
            font-size: 1rem;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
            transition: 0.3s;
        }

        .btn-submit:hover {
            box-shadow: 0 0 20px rgba(209, 26, 26, 0.4);
            transform: scale(1.02);
        }

        @media (max-width: 768px) {
            .form-row { grid-template-columns: 1fr; }
            .dlt-header h1 { font-size: 2rem; }
        }
    </style>
</head>
<body>

    <div class="container">
        <div class="dlt-header">
            <h1>TRAI <span>DLT</span> Registration</h1>
            <p>Mandatory registration for all enterprises to send Bulk SMS in India. We help you navigate the process seamlessly.</p>
        </div>

        <div class="dlt-grid">
            <div class="step-card">
                <div class="step-num">1</div>
                <h3>Entity Reg</h3>
                <p>Register your business on any operator DLT portal like Jio, Airtel, or BSNL.</p>
            </div>
            <div class="step-card">
                <div class="step-num">2</div>
                <h3>Header ID</h3>
                <p>Get your 6-character Sender ID approved for your specific brand.</p>
            </div>
            <div class="step-card">
                <div class="step-num">3</div>
                <h3>Templates</h3>
                <p>Register your Content Templates (SMS body) with variables on the portal.</p>
            </div>
        </div>

        <div class="reg-box">
            <h2>Request DLT Assistance</h2>
            <form action="submit_dlt.php" method="POST">
                <div class="form-row">
                    <div class="form-group">
                        <label>Business Name</label>
                        <input type="text" name="business_name" placeholder="Legal Entity Name" required>
                    </div>
                    <div class="form-group">
                        <label>Contact Person</label>
                        <input type="text" name="contact_name" placeholder="Your Full Name" required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label>Email Address</label>
                        <input type="email" name="email" placeholder="work@company.com" required>
                    </div>
                    <div class="form-group">
                        <label>Phone Number</label>
                        <input type="tel" name="phone" placeholder="+91 00000 00000" required>
                    </div>
                </div>

                <div class="form-group">
                    <label>Select Preferred Operator</label>
                    <select name="operator">
                        <option value="jio">Jio DLT</option>
                        <option value="airtel">Airtel DLT</option>
                        <option value="videocon">Videocon (PingConnect)</option>
                        <option value="bsnl">BSNL DLT</option>
                    </select>
                </div>

                <button type="submit" class="btn-submit">Submit Registration Request</button>
            </form>
        </div>
    </div>
<?php include 'includes/footer.php'; ?>
</body>
</html>