<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Official WhatsApp Business API | Meta Partner | BulkSMSIndia";
?>

<style>
    :root {
        --meta-blue: #0668E1;
        --wa-official: #25D366;
        --glass-navy: rgba(13, 43, 142, 0.1);
    }

    .meta-api-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.85), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1611746872915-64382b5c76da?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .api-hero {
        padding: 180px 4% 100px;
        text-align: center;
    }

    .verified-badge {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 25px;
        background: rgba(6, 104, 225, 0.15);
        border: 1px solid var(--meta-blue);
        border-radius: 50px;
        color: #fff;
        font-weight: 600;
        margin-bottom: 30px;
        backdrop-filter: blur(10px);
    }

    .meta-card {
        background: rgba(255, 255, 255, 0.02);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        position: relative;
        overflow: hidden;
        transition: all 0.4s ease;
    }

    .meta-card:hover {
        background: rgba(6, 104, 225, 0.05);
        border-color: var(--meta-blue);
        transform: translateY(-5px);
    }

    .meta-card::after {
        content: '';
        position: absolute;
        top: -50%;
        left: -50%;
        width: 200%;
        height: 200%;
        background: radial-gradient(circle, rgba(6, 104, 225, 0.1) 0%, transparent 70%);
        opacity: 0;
        transition: 0.4s;
    }

    .meta-card:hover::after {
        opacity: 1;
    }

    .api-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        margin-top: 50px;
    }

    .step-line {
        display: flex;
        align-items: flex-start;
        gap: 20px;
        margin-bottom: 30px;
        padding: 20px;
        background: rgba(255, 255, 255, 0.03);
        border-radius: 15px;
    }

    .step-number-circle {
        min-width: 40px;
        height: 40px;
        background: var(--red);
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 800;
    }
</style>

<div class="meta-api-bg">
    <section class="api-hero">
        <div class="verified-badge">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="#25D366"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
            Official Meta Business Service Provider
        </div>
        <h1 style="font-size: clamp(2rem, 5vw, 4rem); font-weight: 900; line-height: 1.1;">
            The Ultimate <span style="color: var(--meta-blue);">WhatsApp API</span> <br>For Scalable Enterprises
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.15rem;">
            Unlock the power of the Official WhatsApp Business API. Automate conversations, 
            integrate your CRM, and build trust with a verified Green Tick profile.
        </p>
        <div style="margin-top: 40px;">
            <a href="contact.php" class="btn-nav-primary" style="background: var(--meta-blue); border: none;">Apply for Green Tick</a>
        </div>
    </section>

    <section style="padding: 60px 4%;">
        <div class="api-grid">
            <div class="meta-card">
                <h3 style="color: var(--wa-official); margin-bottom: 15px;">✅ Verified Identity</h3>
                <p style="color: var(--text-300);">Get the prestigious Green Tick next to your brand name. Build 100% customer trust instantly.</p>
            </div>
            <div class="meta-card">
                <h3 style="color: var(--meta-blue); margin-bottom: 15px;">🤖 AI Chatbots</h3>
                <p style="color: var(--text-300);">Automate 80% of customer queries with intelligent bots that work 24/7 on your behalf.</p>
            </div>
            <div class="meta-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">🔌 CRM Integration</h3>
                <p style="color: var(--text-300);">Seamlessly connect with Salesforce, Zoho, or your custom CRM for a unified data experience.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.2);">
        <h2 style="text-align: center; margin-bottom: 60px;">Solutions Designed for <span style="color: var(--red);">Growth</span></h2>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;">
            <img src="https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=800&q=80" alt="Tech Office" style="width: 100%; border-radius: 20px; border: 1px solid var(--meta-blue);">
            <div style="display: flex; flex-direction: column; gap: 20px;">
                <div class="meta-card" style="padding: 25px;">
                    <h4 style="color: var(--yellow);">Automated Notifications</h4>
                    <p style="font-size: 0.9rem; color: var(--text-300);">Send shipping alerts, appointment reminders, and payment receipts automatically.</p>
                </div>
                <div class="meta-card" style="padding: 25px;">
                    <h4 style="color: var(--yellow);">Two-Way Support</h4>
                    <p style="font-size: 0.9rem; color: var(--text-300);">Allow multiple agents to reply to customers from a single official number.</p>
                </div>
                <div class="meta-card" style="padding: 25px;">
                    <h4 style="color: var(--yellow);">Marketing Campaigns</h4>
                    <p style="font-size: 0.9rem; color: var(--text-300);">Run highly targeted personalized campaigns with interactive CTA buttons.</p>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <div style="max-width: 800px; margin: 0 auto;">
            <h2 style="text-align: center; margin-bottom: 50px;">4 Simple Steps to <span style="color: var(--wa-official);">Go Official</span></h2>
            
            <div class="step-line">
                <div class="step-number-circle">1</div>
                <div>
                    <h4>Facebook Business Verification</h4>
                    <p style="color: var(--text-300); font-size: 0.9rem;">Verify your business details in the Meta Business Suite to unlock API access.</p>
                </div>
            </div>

            <div class="step-line">
                <div class="step-number-circle">2</div>
                <div>
                    <h4>Number Registration</h4>
                    <p style="color: var(--text-300); font-size: 0.9rem;">Pick a clean mobile or landline number to host your official WhatsApp account.</p>
                </div>
            </div>

            <div class="step-line">
                <div class="step-number-circle">3</div>
                <div>
                    <h4>Template Approval</h4>
                    <p style="color: var(--text-300); font-size: 0.9rem;">Submit your message templates to Meta for quick approval within minutes.</p>
                </div>
            </div>

            <div class="step-line">
                <div class="step-number-circle">4</div>
                <div>
                    <h4>API Integration</h4>
                    <p style="color: var(--text-300); font-size: 1rem;">Connect our API to your software and start messaging at scale.</p>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 80px 4%; text-align: center;">
        <div class="meta-card" style="max-width: 900px; margin: 0 auto; background: linear-gradient(135deg, rgba(6, 104, 225, 0.2), transparent);">
            <h3 style="font-size: 2rem; margin-bottom: 20px;">Ready for the Official Green Tick?</h3>
            <p style="margin-bottom: 30px;">Don't settle for unofficial tools. Get the stability of the Meta Cloud API today.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary">Sign Up Now</a>
                <a href="contact.php" class="btn-nav-ghost">Talk to a Meta Expert</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>