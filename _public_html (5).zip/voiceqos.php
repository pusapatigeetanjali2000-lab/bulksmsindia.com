<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Voice QoS Monitoring | Crystal Clear Audio | BulkSMSIndia";
?>

<style>
    :root {
        --qos-blue: #0D2B8E;
        --qos-red: #DB1212;
        --qos-cyan: #00f2ff;
        --glass-panel: rgba(255, 255, 255, 0.03);
    }

    .qos-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.96)), 
                    url('https://images.unsplash.com/photo-1551434678-e076c223a692?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-qos {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .performance-bar {
        height: 4px;
        background: rgba(255,255,255,0.1);
        border-radius: 10px;
        margin-top: 10px;
        overflow: hidden;
    }

    .bar-fill {
        height: 100%;
        background: linear-gradient(90deg, var(--qos-red), var(--qos-cyan));
        width: 98%;
        box-shadow: 0 0 10px var(--qos-cyan);
    }

    .qos-card {
        background: var(--glass-panel);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 20px;
        padding: 35px;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .qos-card:hover {
        border-color: var(--qos-cyan);
        transform: scale(1.03);
        background: rgba(0, 242, 255, 0.02);
    }

    .metric-value {
        font-family: 'Courier New', monospace;
        color: var(--qos-cyan);
        font-size: 1.5rem;
        font-weight: 900;
    }

    .step-box {
        border-left: 2px solid var(--qos-red);
        padding-left: 25px;
        margin-bottom: 30px;
        position: relative;
    }

    .step-box::before {
        content: '';
        position: absolute;
        left: -6px;
        top: 0;
        width: 10px;
        height: 10px;
        background: var(--qos-red);
        border-radius: 50%;
    }
</style>

<div class="qos-bg">
    <section class="hero-qos">
        <div style="display: inline-flex; align-items: center; gap: 10px; padding: 8px 16px; background: rgba(0, 242, 255, 0.1); border-radius: 8px; border: 1px solid var(--qos-cyan); color: var(--qos-cyan); font-size: 0.8rem; font-weight: 700; margin-bottom: 25px;">
            <span style="display: inline-block; width: 8px; height: 8px; background: var(--qos-cyan); border-radius: 50%;"></span>
            REAL-TIME PACKET PRIORITIZATION
        </div>
        <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 900; line-height: 1.1;">
            Perfect Voice <br><span style="color: var(--qos-cyan);">Zero Distractions.</span>
        </h1>
        <p style="max-width: 750px; margin: 25px auto; color: var(--text-300); font-size: 1.1rem; line-height: 1.8;">
            Our Voice QoS engine ensures that your calls always take the "Fast Lane" on the internet. 
            No jitters, no lag, and no dropped words—just pure, high-definition audio.
        </p>
    </section>

    <section style="padding: 40px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px;">
            <div class="qos-card">
                <div class="metric-value">99.9%</div>
                <h4 style="margin: 10px 0;">Audio Uptime</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Consistent connection stability across global Tier-1 carriers.</p>
                <div class="performance-bar"><div class="bar-fill"></div></div>
            </div>
            <div class="qos-card">
                <div class="metric-value">&lt; 150ms</div>
                <h4 style="margin: 10px 0;">Ultra-Low Latency</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Minimized delay for natural, real-time conversations without overlaps.</p>
                <div class="performance-bar"><div class="bar-fill" style="width: 95%"></div></div>
            </div>
            <div class="qos-card">
                <div class="metric-value">4.5/5</div>
                <h4 style="margin: 10px 0;">MOS Score</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Industry-leading Mean Opinion Score for crystal-clear voice quality.</p>
                <div class="performance-bar"><div class="bar-fill" style="width: 90%"></div></div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(13, 43, 142, 0.1);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div>
                <h2 style="font-size: 2.5rem; margin-bottom: 30px;">Why Quality <br><span style="color: var(--qos-red);">Matters</span></h2>
                <p style="color: var(--text-300); margin-bottom: 35px;">In business communication, a single second of lag can mean a lost deal. Voice QoS manages your network traffic to protect your most important asset: your voice.</p>
                
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <div style="background: rgba(255,255,255,0.03); padding: 20px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                        <strong style="color: var(--yellow);">Priority Routing:</strong> Voice data is prioritized over file downloads or background web traffic.
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 20px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                        <strong style="color: var(--yellow);">Jitter Buffering:</strong> Smooths out the arrival of data packets to eliminate robotic or choppy sounds.
                    </div>
                    <div style="background: rgba(255,255,255,0.03); padding: 20px; border-radius: 12px; border: 1px solid rgba(255,255,255,0.05);">
                        <strong style="color: var(--yellow);">Packet Recovery:</strong> Advanced error correction to fill in gaps if network data is lost.
                    </div>
                </div>
            </div>
            <div style="position: relative;">
                <div style="position: relative;">
    <img src="https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&w=800&q=80" 
         alt="High Speed Voice Data" 
         style="width: 100%; border-radius: 30px; box-shadow: 0 0 50px rgba(0, 242, 255, 0.2); border: 1px solid var(--qos-cyan); filter: brightness(0.9) contrast(1.1);">
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Setup Your <span>High-Definition</span> Network</h2>
        <div style="max-width: 800px; margin: 0 auto;">
            <div class="step-box">
                <h4 style="color: var(--qos-cyan);">Analyze Bandwidth</h4>
                <p style="color: var(--text-300); font-size: 0.9rem;">Our team audits your current internet capacity to calculate the number of concurrent HD calls supported.</p>
            </div>
            <div class="step-box">
                <h4 style="color: var(--qos-cyan);">Configure Router DSCP</h4>
                <p style="color: var(--text-300); font-size: 0.9rem;">We help you tag voice packets so your router knows exactly what to prioritize during peak hours.</p>
            </div>
            <div class="step-box" style="border-color: var(--qos-cyan);">
                <h4 style="color: var(--qos-cyan);">Cloud Optimization</h4>
                <p style="color: var(--text-300); font-size: 0.9rem;">Route your calls through BulkSMSIndia's optimized backbone for the shortest path to the receiver.</p>
            </div>
            <div class="step-box" style="border: none;">
                <h4 style="color: var(--qos-cyan);">Live Monitoring</h4>
                <p style="color: var(--text-300); font-size: 0.9rem;">Access real-time dashboards that show the MOS score and health of every single call made.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(13, 43, 142, 0.2), transparent); border: 1px solid var(--qos-cyan);">
            <h2 style="margin-bottom: 20px;">Stop Settling for Choppy Audio.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Experience the clarity of a dedicated voice-optimized network.</p>
            <a href="contact.php" class="btn-nav-primary" style="background: var(--qos-cyan); color: #000; border: none;">Get a Network Audit</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>