<?php include 'includes/header.php'; ?>
<style>
    :root {
        --glass-bg: rgba(255, 255, 255, 0.03);
        --glass-border: rgba(255, 255, 255, 0.1);
    }

    .page-hero {
        padding: 160px 4% 100px;
        background: radial-gradient(circle at bottom right, rgba(13, 43, 142, 0.3), transparent),
                    url('assets/images/grid-pattern.png'); /* Add a subtle grid pattern if you have one */
        text-align: center;
    }

    .status-badge {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 20px;
        background: rgba(0, 255, 136, 0.1);
        border: 1px solid #00ff88;
        color: #00ff88;
        border-radius: 50px;
        font-size: 0.8rem;
        font-weight: 600;
        margin-bottom: 25px;
    }

    .live-dot {
        width: 8px;
        height: 8px;
        background: #00ff88;
        border-radius: 50%;
        animation: pulse 1.5s infinite;
    }

    @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.3; }
        100% { opacity: 1; }
    }

    .feature-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 30px;
        margin-top: 60px;
    }

    .info-card {
        background: var(--glass-bg);
        border: 1px solid var(--glass-border);
        padding: 40px;
        border-radius: 24px;
        backdrop-filter: blur(15px);
        transition: var(--transition);
        position: relative;
        overflow: hidden;
    }

    .info-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; width: 4px; height: 100%;
        background: var(--red);
        opacity: 0;
        transition: var(--transition);
    }

    .info-card:hover {
        background: rgba(255, 255, 255, 0.05);
        transform: translateY(-10px);
    }

    .info-card:hover::before { opacity: 1; }

    .step-box {
        text-align: center;
        padding: 20px;
    }

    .step-icon {
        width: 60px;
        height: 60px;
        background: var(--navy);
        border: 2px solid var(--red);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 20px;
        font-weight: 800;
        color: var(--yellow);
    }

    .industry-pill {
        background: var(--navy);
        border: 1px solid var(--glass-border);
        padding: 10px 20px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        gap: 12px;
    }
</style>

<main>
    <section class="page-hero">
        <div class="status-badge">
            <span class="live-dot"></span> 99.9% API Uptime Guaranteed
        </div>
        <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 900; line-height: 1.1;">
            Mission Critical <span style="color: var(--red);">Transactional SMS</span>
        </h1>
        <p style="max-width: 800px; margin: 25px auto; color: var(--text-300); font-size: 1.1rem; line-height: 1.8;">
            Delivering automated alerts, OTPs, and real-time notifications with ultra-low latency. 
            Because your users shouldn't have to wait for the code that matters.
        </p>
        <div style="margin-top: 40px; display: flex; gap: 15px; justify-content: center;">
            <a href="signup.php" class="btn-nav-primary">Get API Key</a>
            <a href="docs.php" class="btn-nav-ghost">Read Docs</a>
        </div>
    </section>

    <section style="padding: 80px 4%;">
        <div class="feature-grid">
            <div class="info-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">24/7 Delivery</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Unlike promotional SMS, transactional messages are delivered 24/7, even to DND numbers.</p>
            </div>
            <div class="info-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">Smart Routing</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Our AI-powered infrastructure automatically selects the fastest operator path for instant OTP delivery.</p>
            </div>
            <div class="info-card">
                <h3 style="color: var(--yellow); margin-bottom: 15px;">API First</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Robust REST APIs that integrate with your existing website or app in just a few lines of code.</p>
            </div>
        </div>
    </section>

    <section style="padding: 80px 4%; background: rgba(0,0,0,0.2);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 50px; align-items: center;">
            <div>
                <h2 style="font-size: 2.5rem; margin-bottom: 30px;">Reliability Across <br><span style="color: var(--red);">Every Sector</span></h2>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
                    <div class="industry-pill">🏦 Banking & Finance</div>
                    <div class="industry-pill">🏥 Healthcare</div>
                    <div class="industry-pill">🛍️ E-commerce</div>
                    <div class="industry-pill">🚗 Logistics</div>
                    <div class="industry-pill">🛡️ Security Apps</div>
                    <div class="industry-pill">🎓 EdTech</div>
                </div>
            </div>
            <div>
                <img src="https://images.unsplash.com/photo-1563986768609-322da13575f3?auto=format&fit=crop&w=600&q=80" alt="Secure Tech" style="width: 100%; border-radius: 30px; border: 1px solid var(--red); box-shadow: 0 0 30px rgba(219, 18, 18, 0.2);">
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 60px;">Simple 4-Step <span style="color: var(--yellow);">Integration</span></h2>
        <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 20px;">
            <div class="step-box">
                <div class="step-icon">1</div>
                <h4>API Access</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Sign up and generate your unique API secret key.</p>
            </div>
            <div class="step-box">
                <div class="step-icon">2</div>
                <h4>Whitelist</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Get your Transactional Sender ID (Header) approved.</p>
            </div>
            <div class="step-box">
                <div class="step-icon">3</div>
                <h4>Template</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Register your message templates on the DLT portal.</p>
            </div>
            <div class="step-box">
                <div class="step-icon">4</div>
                <h4>Go Live</h4>
                <p style="font-size: 0.8rem; color: var(--text-300); margin-top: 10px;">Trigger automated SMS via our PHP/Python/Node.js SDKs.</p>
            </div>
        </div>
    </section>

    <section style="padding: 60px 4%; text-align: center;">
        <div style="max-width: 600px; margin: 0 auto; padding: 40px; border-top: 1px solid var(--glass-border);">
            <p style="font-style: italic; color: var(--text-300);">"Trust is built on consistency. We ensure your critical data reaches your users every single time."</p>
            <h5 style="margin-top: 20px; color: var(--yellow);">— BulkSMSIndia Tech Team</h5>
        </div>
    </section>
</main>
<?php include 'includes/footer.php'; ?>