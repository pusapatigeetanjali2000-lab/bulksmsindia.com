<?php include 'includes/header.php'; ?>
<?php 
  $page_title = "Autonomous AI Agents | Your Digital Workforce | BulkSMSIndia";
?>

<style>
    :root {
        --ai-blue: #0D2B8E;
        --ai-red: #DB1212;
        --ai-purple: #8A2BE2;
        --glass-ai: rgba(255, 255, 255, 0.03);
    }

    .ai-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1677442136019-21780ecad995?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-ai {
        padding: 180px 4% 80px;
        text-align: center;
    }

    .ai-chip {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 10px 25px;
        background: rgba(138, 43, 226, 0.1);
        border: 1px solid var(--ai-purple);
        border-radius: 50px;
        color: #fff;
        font-size: 0.8rem;
        font-weight: 700;
        margin-bottom: 30px;
        letter-spacing: 1px;
    }

    .ai-card {
        background: var(--glass-ai);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 24px;
        padding: 40px;
        transition: all 0.4s ease;
        text-align: center;
    }

    .ai-card:hover {
        border-color: var(--ai-purple);
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(138, 43, 226, 0.15);
    }

    .ai-icon-box {
        width: 70px;
        height: 70px;
        background: linear-gradient(135deg, var(--ai-blue), var(--ai-purple));
        border-radius: 20px;
        margin: 0 auto 25px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 2rem;
    }

    .floating-bot {
        animation: float 4s ease-in-out infinite;
        border-radius: 30px;
        border: 1px solid rgba(255,255,255,0.1);
    }

    @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-20px); }
    }
</style>

<div class="ai-bg">
    <section class="hero-ai">
        <div class="ai-chip">
            <span style="display: block; width: 8px; height: 8px; background: #00f2ff; border-radius: 50%; box-shadow: 0 0 10px #00f2ff;"></span>
            NEXT-GEN AUTONOMOUS AGENTS
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1;">
            Hire AI Agents. <br><span style="color: var(--ai-purple);">Scale Your Business.</span>
        </h1>
        <p style="max-width: 850px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Beyond simple bots. Our AI Agents reason, plan, and execute tasks across your favorite platforms. 
            Automate customer support, lead generation, and operations with 24/7 digital workers.
        </p>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="ai-card">
                <div class="ai-icon-box">🧠</div>
                <h3 style="color: var(--yellow); margin-bottom: 15px;">Smart Reasoning</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Our agents don't just follow scripts; they understand context and intent to provide human-like solutions.</p>
            </div>
            <div class="ai-card">
                <div class="ai-icon-box">🛠️</div>
                <h3 style="color: var(--yellow); margin-bottom: 15px;">Tool Integration</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Agents can interact with your CRM, Google Sheets, and databases to perform real actions.</p>
            </div>
            <div class="ai-card">
                <div class="ai-icon-box">⚡</div>
                <h3 style="color: var(--yellow); margin-bottom: 15px;">Instant Response</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Zero wait times. Handle thousands of simultaneous conversations without ever breaking a sweat.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
                <img src="https://images.unsplash.com/photo-1675271591211-126ad94e495d?auto=format&fit=crop&w=400&q=80" alt="AI Interface" class="floating-bot" style="margin-top: 40px;">
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Industries <span>Transformed</span></h2>
                <div style="display: flex; flex-direction: column; gap: 15px;">
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-radius: 15px; border-left: 4px solid var(--ai-purple);">
                        <h4 style="color: var(--ai-purple);">Real Estate</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Agents that qualify leads and schedule property viewings automatically.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-radius: 15px; border-left: 4px solid var(--ai-purple);">
                        <h4 style="color: var(--ai-purple);">Healthcare</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">Assistants that triage symptoms and book appointments with specialized doctors.</p>
                    </div>
                    <div style="padding: 20px; background: rgba(255,255,255,0.02); border-radius: 15px; border-left: 4px solid var(--ai-purple);">
                        <h4 style="color: var(--ai-purple);">FinTech</h4>
                        <p style="font-size: 0.9rem; color: var(--text-300);">24/7 support for transaction inquiries and personalized financial advice.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Deploy Your <span>Agent</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 30px;">
            <div class="ai-card">
                <h1 style="color: var(--ai-purple); opacity: 0.3;">01</h1>
                <h4>Define Goals</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Tell us what you want your agent to achieve—from sales to support.</p>
            </div>
            <div class="ai-card">
                <h1 style="color: var(--ai-purple); opacity: 0.3;">02</h1>
                <h4>Feed Knowledge</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Upload your company docs, FAQs, and data to train your agent.</p>
            </div>
            <div class="ai-card">
                <h1 style="color: var(--ai-purple); opacity: 0.3;">03</h1>
                <h4>Connect Tools</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Link your CRM and messaging channels (WhatsApp, SMS, Web).</p>
            </div>
            <div class="ai-card">
                <h1 style="color: var(--ai-purple); opacity: 0.3;">04</h1>
                <h4>Activate</h4>
                <p style="font-size: 0.85rem; color: var(--text-300);">Watch your agent handle tasks while you focus on growth.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="max-width: 900px; margin: 0 auto; padding: 60px; border-radius: 40px; background: linear-gradient(135deg, rgba(138, 43, 226, 0.1), transparent); border: 1px solid var(--ai-purple);">
            <h2 style="margin-bottom: 20px;">Hire Your First AI Worker Today.</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Transform your operations with the power of Agentic AI.</p>
            <div style="display: flex; gap: 15px; justify-content: center;">
                <a href="signup.php" class="btn-nav-primary" style="background: var(--ai-purple); border: none;">Get Started Free</a>
                <a href="contact.php" class="btn-nav-ghost">Schedule a Demo</a>
            </div>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>