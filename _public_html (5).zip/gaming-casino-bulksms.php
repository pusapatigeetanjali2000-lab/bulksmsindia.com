<?php include 'includes/header.php'; ?>
<style>
    :root {
        --casino-gold: #fde74c;
        --neon-red: #ff0000;
        --glass-dark: rgba(5, 10, 21, 0.85);
    }

    .gaming-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.8), rgba(5, 10, 21, 0.9)), 
                    url('https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-gaming {
        padding: 180px 4% 100px;
        text-align: center;
    }

    .gaming-card {
        background: var(--glass-dark);
        backdrop-filter: blur(20px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-top: 4px solid var(--red);
        padding: 40px;
        border-radius: 20px;
        transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    }

    .gaming-card:hover {
        transform: scale(1.02);
        border-top-color: var(--casino-gold);
        box-shadow: 0 15px 40px rgba(219, 18, 18, 0.2);
    }

    .gaming-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 30px;
        padding: 60px 4%;
    }

    .neon-text {
        text-shadow: 0 0 10px rgba(219, 18, 18, 0.5);
    }

    .step-indicator {
        background: linear-gradient(135deg, var(--red), #8e0d0d);
        width: 40px;
        height: 40px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 900;
        margin-bottom: 20px;
        box-shadow: 0 5px 15px rgba(219, 18, 18, 0.4);
    }

    .floating-image {
        border-radius: 20px;
        border: 1px solid rgba(255,255,255,0.1);
        box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        animation: floating 6s ease-in-out infinite;
    }

    @keyframes floating {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-20px); }
    }
</style>

<div class="gaming-bg">
    <section class="hero-gaming">
        <h1 class="neon-text" style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; color: #fff; line-height: 1;">
            Level Up Your <br><span style="color: var(--casino-gold);">Player Engagement</span>
        </h1>
        <p style="max-width: 750px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.6;">
            The ultimate communication toolkit for Casinos, Esports, and I-Gaming platforms. 
            Deliver rewards, alerts, and betting tips straight to the palm of their hand.
        </p>
        <div style="display: flex; gap: 20px; justify-content: center; margin-top: 40px;">
            <a href="signup.php" class="btn-nav-primary" style="padding: 15px 40px;">Start Winning Now</a>
        </div>
    </section>

    <section style="padding: 60px 4%;">
        <div class="gaming-grid">
            <div class="gaming-card">
                <h3 style="color: var(--casino-gold); margin-bottom: 15px;">🎰 Real-Time Jackpot Alerts</h3>
                <p style="color: var(--text-300); line-height: 1.7;">Keep the excitement alive! Notify players about massive jackpots and tournament start times instantly.</p>
            </div>
            <div class="gaming-card">
                <h3 style="color: var(--casino-gold); margin-bottom: 15px;">🛡️ Secure OTPs</h3>
                <p style="color: var(--text-300); line-height: 1.7;">Protect player accounts and wallets with lightning-fast 2FA and transaction alerts.</p>
            </div>
            <div class="gaming-card">
                <h3 style="color: var(--casino-gold); margin-bottom: 15px;">🎁 Personalized Bonuses</h3>
                <p style="color: var(--text-300); line-height: 1.7;">Send exclusive promo codes and "Welcome Back" offers to increase player retention.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 60px; align-items: center;">
            <div class="gaming-card">
                <h2 style="font-size: 2.5rem; margin-bottom: 25px;">The House <span style="color: var(--red);">Always Wins</span> With Better Tech</h2>
                <ul style="color: var(--text-300); display: flex; flex-direction: column; gap: 20px;">
                    <li style="display: flex; gap: 15px;">✅ <strong>Global Reach:</strong> Target players in 190+ countries.</li>
                    <li style="display: flex; gap: 15px;">✅ <strong>Scalability:</strong> Handle 1 million+ messages during peak events.</li>
                    <li style="display: flex; gap: 15px;">✅ <strong>API Integration:</strong> Connect directly to your gaming engine.</li>
                </ul>
            </div>
            <div>
                <img src="https://images.unsplash.com/photo-1596838132731-dd964a977507?auto=format&fit=crop&w=600&q=80" alt="Casino Lights" class="floating-image" style="width: 100%;">
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <h2 style="margin-bottom: 60px; font-size: 2.5rem;">How to Get <span style="color: var(--casino-gold);">Started</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 25px;">
            <div class="gaming-card" style="text-align: left;">
                <div class="step-indicator">01</div>
                <h4>API Key</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Register your platform and get your unique gaming API credentials.</p>
            </div>
            <div class="gaming-card" style="text-align: left;">
                <div class="step-indicator">02</div>
                <h4>Define Events</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Set triggers for wins, losses, deposits, or inactivity alerts.</p>
            </div>
            <div class="gaming-card" style="text-align: left;">
                <div class="step-indicator">03</div>
                <h4>Craft Creative</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Use our templates to write high-converting gaming content.</p>
            </div>
            <div class="gaming-card" style="text-align: left;">
                <div class="step-indicator">04</div>
                <h4>Hit Jackpot</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Watch your player engagement and lifetime value skyrocket.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div class="gaming-card" style="max-width: 800px; margin: 0 auto; background: rgba(219, 18, 18, 0.1); border: 2px solid var(--red);">
            <h3 style="font-size: 2rem; margin-bottom: 15px;">Ready for the Next Level?</h3>
            <p style="margin-bottom: 30px;">Our dedicated gaming account managers are ready to build your custom strategy.</p>
            <a href="contact.php" class="btn-nav-primary">Contact Gaming Expert</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>