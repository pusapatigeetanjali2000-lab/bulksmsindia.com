<?php include 'includes/header.php'; ?>

<?php 
  $page_title = "Bulk WhatsApp Marketing Services | BulkSMSIndia";
?>

<style>
    :root {
        --wa-green: #25D366;
        --wa-dark: #075E54;
        --glass-white: rgba(255, 255, 255, 0.05);
    }

    .whatsapp-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.9), rgba(5, 10, 21, 0.95)), 
                    url('https://images.unsplash.com/photo-1614680376593-902f74cc0d41?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-whatsapp {
        padding: 180px 4% 100px;
        text-align: center;
    }

    .wa-card {
        background: var(--glass-white);
        backdrop-filter: blur(15px);
        border: 1px solid rgba(37, 211, 102, 0.2);
        padding: 40px;
        border-radius: 30px;
        transition: all 0.3s ease;
    }

    .wa-card:hover {
        border-color: var(--wa-green);
        transform: translateY(-10px);
        box-shadow: 0 20px 40px rgba(37, 211, 102, 0.1);
    }

    .feature-icon {
        width: 50px;
        height: 50px;
        background: var(--wa-green);
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 20px;
        color: #fff;
    }

    .rich-media-list {
        list-style: none;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 15px;
        margin-top: 20px;
    }

    .rich-media-list li {
        background: rgba(255,255,255,0.05);
        padding: 10px 15px;
        border-radius: 50px;
        font-size: 0.85rem;
        display: flex;
        align-items: center;
        gap: 10px;
    }

    .step-badge {
        background: var(--wa-green);
        color: white;
        padding: 4px 12px;
        border-radius: 4px;
        font-size: 0.7rem;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 10px;
        display: inline-block;
    }
</style>

<div class="whatsapp-bg">
    <section class="hero-whatsapp">
        <div style="display: inline-flex; align-items: center; gap: 10px; padding: 8px 20px; background: rgba(37, 211, 102, 0.1); border: 1px solid var(--wa-green); border-radius: 50px; color: var(--wa-green); margin-bottom: 30px; font-weight: 600;">
            <span style="font-size: 1.2rem;">💬</span> Official WhatsApp Marketing Partner
        </div>
        <h1 style="font-size: clamp(2.5rem, 6vw, 4.5rem); font-weight: 900; line-height: 1;">
            Connect Where Your <br><span style="color: var(--wa-green);">Customers Are.</span>
        </h1>
        <p style="max-width: 800px; margin: 30px auto; color: var(--text-300); font-size: 1.2rem; line-height: 1.8;">
            Experience 10x more engagement than traditional channels. Send images, videos, PDFs, and interactive buttons directly to your customers' favorite app.
        </p>
        <div style="display: flex; gap: 20px; justify-content: center; margin-top: 40px;">
            <a href="signup.php" class="btn-nav-primary" style="background: var(--wa-green); border: none;">Get Started Free</a>
            <a href="contact.php" class="btn-nav-ghost">Schedule Demo</a>
        </div>
    </section>

    <section style="padding: 60px 4%;">
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(320px, 1fr)); gap: 30px;">
            <div class="wa-card">
                <div class="feature-icon">📸</div>
                <h3 style="color: #fff; margin-bottom: 15px;">Rich Media Support</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Don't just send text. Send high-resolution images, explainer videos, and product catalogs to drive sales.</p>
                <ul class="rich-media-list">
                    <li>✅ PDF Docs</li>
                    <li>✅ Video Ads</li>
                    <li>✅ Audio Clips</li>
                    <li>✅ Live Location</li>
                </ul>
            </div>
            <div class="wa-card">
                <div class="feature-icon">🔘</div>
                <h3 style="color: #fff; margin-bottom: 15px;">Interactive Buttons</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Add Call-to-Action buttons like "Buy Now," "Visit Website," or "Call Support" directly in the message.</p>
            </div>
            <div class="wa-card">
                <div class="feature-icon">🛡️</div>
                <h3 style="color: #fff; margin-bottom: 15px;">Verified Branding</h3>
                <p style="color: var(--text-300); font-size: 0.95rem;">Send messages with your brand name and a Green Tick to build instant trust and credibility.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; background: rgba(0,0,0,0.3);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: center;">
            <div>
                <img src="https://images.unsplash.com/photo-1557804506-669a67965ba0?auto=format&fit=crop&w=800&q=80" alt="Team Work" style="width: 100%; border-radius: 40px; box-shadow: 0 30px 60px rgba(0,0,0,0.5);">
            </div>
            <div>
                <h2 style="font-size: 2.8rem; margin-bottom: 30px;">Tailored for Your <br><span style="color: var(--red);">Business Growth</span></h2>
                <div style="display: flex; flex-direction: column; gap: 20px;">
                    <div style="padding-left: 20px; border-left: 3px solid var(--wa-green);">
                        <h4 style="color: var(--yellow);">E-commerce</h4>
                        <p style="color: var(--text-300); font-size: 0.9rem;">Send abandoned cart reminders and order tracking updates.</p>
                    </div>
                    <div style="padding-left: 20px; border-left: 3px solid var(--wa-green);">
                        <h4 style="color: var(--yellow);">Real Estate</h4>
                        <p style="color: var(--text-300); font-size: 0.9rem;">Share virtual tour videos and property brochures instantly.</p>
                    </div>
                    <div style="padding-left: 20px; border-left: 3px solid var(--wa-green);">
                        <h4 style="color: var(--yellow);">Tour & Travels</h4>
                        <p style="color: var(--text-300); font-size: 0.9rem;">Send flight tickets, hotel vouchers, and itinerary PDFs.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 70px;">Launch Your First <span style="color: var(--wa-green);">WhatsApp Campaign</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 30px;">
            <div class="wa-card" style="padding: 30px;">
                <span class="step-badge">Step 01</span>
                <h4>Create Instance</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Connect your WhatsApp number to our high-speed cloud servers.</p>
            </div>
            <div class="wa-card" style="padding: 30px;">
                <span class="step-badge">Step 02</span>
                <h4>Upload Contacts</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Import your customer numbers securely via Excel or CSV file.</p>
            </div>
            <div class="wa-card" style="padding: 30px;">
                <span class="step-badge">Step 03</span>
                <h4>Design Content</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Add your image, caption, and interactive "Click-to-Action" buttons.</p>
            </div>
            <div class="wa-card" style="padding: 30px;">
                <span class="step-badge">Step 04</span>
                <h4>Blast & Analyze</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Track real-time delivery and read reports in your dashboard.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="background: linear-gradient(135deg, var(--wa-dark), #000); padding: 60px; border-radius: 40px; border: 1px solid var(--wa-green);">
            <h2 style="margin-bottom: 20px;">Ready to reach 2 Billion users?</h2>
            <p style="margin-bottom: 40px; color: var(--text-300);">Join 500+ brands using BulkSMSIndia for their WhatsApp marketing.</p>
            <a href="signup.php" class="btn-nav-primary" style="background: var(--wa-green); border: none; padding: 18px 50px; font-size: 1.1rem;">Start My Free Trial</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>