<?php include 'includes/header.php'; ?>

<?php 
  $page_title = "Two-Way SMS Services | Interactive Messaging | BulkSMSIndia";
?>

<style>
    :root {
        --chat-bg: rgba(13, 43, 142, 0.05);
        --bubble-user: rgba(219, 18, 18, 0.15);
        --bubble-bot: rgba(253, 231, 76, 0.1);
    }

    .twoway-bg {
        background: linear-gradient(rgba(5, 10, 21, 0.85), rgba(5, 10, 21, 0.9)), 
                    url('https://images.unsplash.com/photo-1556745753-b2904692b3cd?auto=format&fit=crop&w=1600&q=80');
        background-attachment: fixed;
        background-size: cover;
        background-position: center;
        min-height: 100vh;
    }

    .hero-twoway {
        padding: 180px 4% 80px;
        text-align: center;
    }

    /* Conversation Bubble Style Cards */
    .chat-container {
        max-width: 900px;
        margin: 0 auto;
        display: flex;
        flex-direction: column;
        gap: 20px;
    }

    .chat-bubble {
        padding: 20px 30px;
        border-radius: 25px;
        max-width: 70%;
        backdrop-filter: blur(10px);
        border: 1px solid rgba(255, 255, 255, 0.1);
        position: relative;
        transition: var(--transition);
    }

    .bubble-left {
        align-self: flex-start;
        background: var(--bubble-bot);
        border-bottom-left-radius: 5px;
    }

    .bubble-right {
        align-self: flex-end;
        background: var(--bubble-user);
        border-bottom-right-radius: 5px;
        border-color: var(--red);
    }

    .feature-card {
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 20px;
        padding: 35px;
        text-align: center;
        transition: var(--transition);
    }

    .feature-card:hover {
        background: rgba(13, 43, 142, 0.3);
        border-color: var(--yellow);
        transform: translateY(-10px);
    }

    .step-card {
        padding: 30px;
        background: rgba(0,0,0,0.3);
        border-radius: 15px;
        border-left: 4px solid var(--red);
    }
</style>

<div class="twoway-bg">
    <section class="hero-twoway">
        <div style="display: inline-block; padding: 5px 15px; background: var(--red); border-radius: 5px; font-size: 0.8rem; margin-bottom: 20px; font-weight: 700;">INTERACTIVE</div>
        <h1 style="font-size: clamp(2.5rem, 5vw, 4rem); font-weight: 900; line-height: 1.2;">
            Don't Just Talk. <br><span style="color: var(--yellow);">Start a Conversation.</span>
        </h1>
        <p style="max-width: 700px; margin: 25px auto; color: var(--text-300); font-size: 1.1rem;">
            Empower your customers to talk back. Two-Way SMS allows you to receive replies, surveys, and inquiries in real-time through Shortcodes and Longcodes.
        </p>
    </section>

    <section style="padding: 40px 4%;">
        <div class="chat-container">
            <div class="chat-bubble bubble-left">
                <h4 style="color: var(--yellow);">BulkSMSIndia</h4>
                <p>Hi Rahul! Are you interested in our new Home Loan offers? Reply 'YES' to get a callback.</p>
            </div>
            <div class="chat-bubble bubble-right">
                <h4 style="color: var(--red);">Customer</h4>
                <p>YES. Please call me after 4 PM.</p>
            </div>
            <div class="chat-bubble bubble-left" style="border-color: #00ff88;">
                <h4 style="color: #00ff88;">System Alert</h4>
                <p>Lead Captured! Your team has been notified to call the customer at 4 PM.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 50px; font-size: 2.5rem;">Why Choose <span>Two-Way?</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 30px;">
            <div class="feature-card">
                <h3 style="margin-bottom: 15px; color: var(--yellow);">Real-Time Feedback</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Gather instant customer opinions, NPS scores, or service ratings without directing them to a website.</p>
            </div>
            <div class="feature-card">
                <h3 style="margin-bottom: 15px; color: var(--yellow);">Automated Opt-Outs</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Stay compliant effortlessly. Allow users to unsubscribe by replying 'STOP', keeping your list clean.</p>
            </div>
            <div class="feature-card">
                <h3 style="margin-bottom: 15px; color: var(--yellow);">Higher Engagement</h3>
                <p style="color: var(--text-300); font-size: 0.9rem;">Interactive messages see 3x higher engagement than one-way promotional blasts.</p>
            </div>
        </div>
    </section>

    <section style="padding: 80px 4%; background: rgba(13, 43, 142, 0.2);">
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 50px; align-items: center;">
            <img src="https://images.unsplash.com/photo-1516321497487-e288fb19713f?auto=format&fit=crop&w=600&q=80" alt="Customer Support" style="width: 100%; border-radius: 20px; filter: grayscale(30%) contrast(110%);">
            <div>
                <h2 style="font-size: 2.2rem; margin-bottom: 25px;">Conversations That <span style="color: var(--red);">Convert</span></h2>
                <div style="display: grid; grid-template-columns: 1fr; gap: 15px;">
                    <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 10px;">
                        <strong>Hospitality:</strong> Confirm hotel bookings or room service requests via SMS.
                    </div>
                    <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 10px;">
                        <strong>Events:</strong> Manage RSVP counts for weddings, webinars, or corporate events.
                    </div>
                    <div style="background: rgba(255,255,255,0.05); padding: 15px; border-radius: 10px;">
                        <strong>Logistics:</strong> Let customers reschedule deliveries with a simple reply.
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%;">
        <h2 style="text-align: center; margin-bottom: 60px;">Setting Up Your <span style="color: var(--yellow);">Virtual Number</span></h2>
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 20px;">
            <div class="step-card">
                <h4 style="color: var(--yellow);">1. Pick a Number</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Choose between a 10-digit Longcode or a 5-digit Shortcode.</p>
            </div>
            <div class="step-card">
                <h4 style="color: var(--yellow);">2. Set Keywords</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Define triggers like 'INFO', 'JOIN', or 'YES'.</p>
            </div>
            <div class="step-card">
                <h4 style="color: var(--yellow);">3. Auto-Reply</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Configure instant responses for each keyword received.</p>
            </div>
            <div class="step-card">
                <h4 style="color: var(--yellow);">4. Webhook Sync</h4>
                <p style="font-size: 0.85rem; color: var(--text-300); margin-top: 10px;">Push incoming data directly to your CRM or Database.</p>
            </div>
        </div>
    </section>

    <section style="padding: 100px 4%; text-align: center;">
        <div style="padding: 50px; border: 1px dashed var(--yellow); border-radius: 30px; background: rgba(253, 231, 76, 0.03);">
            <h3 style="font-size: 2rem; margin-bottom: 20px;">Ready to listen to your customers?</h3>
            <p style="margin-bottom: 30px; color: var(--text-300);">Get your dedicated Two-Way SMS channel live today.</p>
            <a href="signup.php" class="btn-nav-primary">Activate Two-Way SMS</a>
        </div>
    </section>
</div>
<?php include 'includes/footer.php'; ?>